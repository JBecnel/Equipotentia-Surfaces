package actions;         // class is part of the action package

import javax.swing.*;
import java.awt.event.*;
import java.beans.*;

                
/*    Jeremy Becnel          Applet Contest               12/9/98

   This class defines a GuiAction.  It is used to process action events
   for the graphical user interface of the equipotential surface project.
*/
        

public class GUIAction extends AbstractAction implements IAction  {


//-----------------------------FIELDS----------------------------

  private String name;          // name of the action


//---------------------------CONSTRUCTOR-------------------------

  public GUIAction (String name)  {
    /* This method creates a GUIAction and sets the name of it's field.

       Pre : given the name of the action

       Post: the field is set
    */

    super(name);                // call to AbstractAction constructor
    this.name = name;
  }


//------------------------------METHODS---------------------------


//==========================ACTIONPERFORMED=======================

  public void actionPerformed(ActionEvent e)  {
    /* This method handles action events that are performed by
       firing a property change to the actions listener.

       Pre : given the action event

       Post: the property change is fired
    */

    firePropertyChange(name, null, null);
  }


//=======================ADDPROPERTYCHANGELISTENER=====================

  public void addPropertyChangeListener(PropertyChangeListener L)  {
    /* This method adds a property change listener to the
       property change support.

       Pre : given a property change listener (L) to add

       Post: the listener is added
    */

     super.addPropertyChangeListener (L);
  }


//=======================REMOVEPROPERTYCHANGELISTENER=====================

  public void removePropertyChangeListener(PropertyChangeListener L)  {
    /* This method removes a property change listener from the
       property change support.

       Pre : given a property change listener (L) to remove

       Post: the listener is removeed
    */

    super.removePropertyChangeListener (L);
  }


//============================TOSTRING==============================

  public String toString()   {
    /* This method returns the string representation of an GUIAction.

       Pre : none

       Post: the string representation is returned
    */

    String s = "GUIAction : \n";

    s += "Name : " + name + "\n";
    s += super.toString() + "\n";

    return s;
  }

}  // end class GUIAction
