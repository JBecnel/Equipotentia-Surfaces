package actions;                   // class is part of the action package

import java.beans.*;

/*      Jeremy Becnel      Applet Contest                12/9/98

   This interface defines methods that need a to be implemented in order
   for a class to be considered a IAction.
*/


public interface IAction   {

//----------------------------METHODS------------------------------

  public void addPropertyChangeListener(PropertyChangeListener L);
  public void removePropertyChangeListener(PropertyChangeListener L);
                
}
