package actions;         // class is part of the action package
                                                  
import java.util.*;

import window.*;

                
/*  Jeremy Becnel              Applet Contest                 12/14/98

     This class defines a Actions hash table that holds various
     actions.
*/


public class Actions extends Hashtable  {


//--------------------------CONSTRUCTORS--------------------------
                                                        
  public Actions(ResourceBundle resources, WindowToCanvas windowToCanvas)  {
    /*  This constructor creates a hashtable that stores actions.

        Pre : given the resource bundle and the window to canvas for
              transformations.

        Post: the actions hashtable is created
    */

    super();            // call to hashtable constructor

    // put canvas actions on table
    put("Canvas", new CanvasAction(windowToCanvas));
    put("CanvasMotion", new CanvasMotionAction(windowToCanvas));
                                              
    StringTokenizer tk = new StringTokenizer(resources.getString("Actions"));
                // traverses possible gui actions

    while (tk.hasMoreTokens())  {
      // create each action and put it in the actions hashtable
      String actionName = tk.nextToken();
      put(actionName, new GUIAction(actionName));
    }
  }


//-----------------------------METHODS---------------------------


//============================GETACTION==========================


  public IAction getAction (String name)  {
    /* This method returns a action specified by it's name.

       Pre : given the action name

       Post: the action is returned
    */

    return (IAction) get(name);
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none

        Post: the string representation is returned
    */

    String s = "Actions Hashtable : \n";

    s += super.toString();

    return s;
  }                                               

}  // end class Actions
