package actions;         // class is part of the action package

import java.awt.event.*;
import java.beans.*;

import point.*;
import window.*;

                
/*    Jeremy Becnel          Applet Contest               12/13/98

   This class defines a CanvasAction used for canvas events in
   the simulator.
*/

                                                                                                     
public class CanvasAction extends MouseAdapter implements IAction {


//--------------------------------FIELDS------------------------------

  private transient PropertyChangeSupport sp;   // used to notify listeners of
                                                // changes
  private WindowToCanvas windowToCanvas;
                        // used to convert from the canvas coordinate system
                        // to the window coordinate system


//-----------------------------CONSTRUCTORS----------------------------

  public CanvasAction(WindowToCanvas windowToCanvas)  {
    /* This method creates the canvas action and sets it's window
       to canvas field.

       Pre : given a WindowToCanvas Object

       Post: the CanvasAction is created and the field is set
    */

    super();    // call to MouseAdapter constructor

    // set field
    this.windowToCanvas = windowToCanvas;

    // create property change support
    sp = new PropertyChangeSupport(this);
  }


//------------------------------METHODS--------------------------------


//=======================ADDPROPERTYCHANGELISTENER=====================

  public void addPropertyChangeListener(PropertyChangeListener L)  {
    /* This method adds a property change listener to the
       property change support.

       Pre : given a property change listener (L) to add

       Post: the listener is added
    */

     sp.addPropertyChangeListener (L);
  }


//=======================REMOVEPROPERTYCHANGELISTENER=====================

  public void removePropertyChangeListener(PropertyChangeListener L)  {
    /* This method removes a property change listener from the
       property change support.

       Pre : given a property change listener (L) to remove

       Post: the listener is removeed
    */

    sp.removePropertyChangeListener (L);
  }        

//============================MOUSEPRESSED===============================

  public void mousePressed(MouseEvent e)  {
    /* This method handles events that occur on the canvas when
       the mouse is pressed.  

       Pre : given the mouse event

       Post: the event is handled and a listeners are notified of
             a property change
    */

    
    // set the point field
    Point2D canvasPoint = new Point2D(e.getX(), e.getY());   // current value of p
    Point2D point = windowToCanvas.convertToWindow(canvasPoint);

    // record the type of mouse event
    String canvasActionName;
    if (e.getModifiers() == MouseEvent.BUTTON1_MASK)  
      canvasActionName =  "Canvas" + e.getClickCount();
    else
      canvasActionName = "CanvasRight";

    // notify listeners of property changes
    sp.firePropertyChange(canvasActionName, canvasPoint, point);
  }


//============================TOSTRING==============================

  public String toString()   {
    /* This method returns the string representation of an CanvasAction.

       Pre : none

       Post: the string representation is returned
    */

    String s = "CanvasAction : \n";

    s += "Property Change Support :    " + sp.toString() + "\n";
    s += super.toString() + "\n";

    return s;
  }

}  // end class CanvasAction
