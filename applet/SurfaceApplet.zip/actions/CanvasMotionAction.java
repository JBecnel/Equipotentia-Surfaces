package actions;         // class is part of the action package

import java.awt.event.*;
import java.beans.*;

import point.*;
import window.*;

                
/*    Jeremy Becnel          Applet Contest               12/17/98

   This class defines a CanvasMotionAction used for canvas events in
   the equipotential surface project.
*/

                                                                
public class CanvasMotionAction extends MouseMotionAdapter
                                                implements IAction {


//--------------------------------FIELDS------------------------------

  private transient PropertyChangeSupport sp;   // used to notify listeners of
                                                // changes
  private WindowToCanvas windowToCanvas;
                        // used to convert from the canvas coordinate system
                        // to the window coordinate system


//-----------------------------CONSTRUCTORS----------------------------

  public CanvasMotionAction(WindowToCanvas windowToCanvas)  {
    /* This method creates the canvas motion action and sets it's
       window to canvas field.

       Pre : given a WindowToCanvas Object

       Post: the CanvasAction is created and the field is set
    */

    super();    // call to MouseAdapter constructor

    // set field
    this.windowToCanvas = windowToCanvas;

    // create property change support
    sp = new PropertyChangeSupport(this);
  }


//------------------------------METHODS--------------------------------


//=======================ADDPROPERTYCHANGELISTENER=====================

  public void addPropertyChangeListener(PropertyChangeListener L)  {
    /* This method adds a property change listener to the
       property change support.

       Pre : given a property change listener (L) to add

       Post: the listener is added
    */

    sp.addPropertyChangeListener (L);
  }


//=======================REMOVEPROPERTYCHANGELISTENER=====================

  public void removePropertyChangeListener(PropertyChangeListener L)  {
    /* This method removes a property change listener from the
       property change support.

       Pre : given a property change listener (L) to remove

       Post: the listener is removeed
    */      

    sp.removePropertyChangeListener (L);
  }
    

//=========================MOUSEMOVED========================

  public void mouseMoved(MouseEvent e)  {
    /*  This method handles events that occur when the mouse is moved.

        Pre : given the mouse event which occured

        Post: the listeners are notified of the mouse event
    */

    // find the point of occurence
    Point2D canvasPoint = new Point2D(e.getX(), e.getY());
    Point2D point = windowToCanvas.convertToWindow(canvasPoint);
   
    // notify listeners of event
    sp.firePropertyChange("CanvasMotion", canvasPoint, point);
  }
  

//============================TOSTRING==============================

  public String toString()   {
    /* This method returns the string representation of an CanvasMotionAction.

       Pre : none

       Post: the string representation is returned
    */

    String s = "CanvasMotionAction : \n";

    s += "Property Change Support :    " + sp.toString() + "\n";
    s += super.toString() + "\n";

    return s;
  }

}  // end class CanvasMotionAction

