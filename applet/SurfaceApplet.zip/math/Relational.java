package math;           // class is in math package

/*      Jeremy Becnel   Applet Contest         12/19/98

  The Relational interface includes methods to represent operations
  for <, >, <=, and >=.
*/


public interface Relational     {
  public boolean lessThan (Relational y);
  public boolean greaterThan (Relational y);
  public boolean lessThanOrEqual (Relational y);
  public boolean greaterThanOrEqual (Relational y);
} 

