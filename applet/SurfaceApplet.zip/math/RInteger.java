package math;           // class is part of the math package


/* Jeremy Becnel        Applet Contest         12/19/98

  Class RInteger is a subclass of Number and implements the Relational
  interface.  This class represents Integers that also have the
  relational operations for <, >, <=, and >= on them.
*/


public class RInteger extends Number implements Relational        {

//----------------------------FIELD----------------------

  private int x;     // representation


//-------------------------CONSTRUCTOR--------------------

  public RInteger (int a) {
    /*  This constructor creates a RInteger with value a.

        Pre : given an integer for the value of the relational integer

        Post: a relational integer is created
    */

    x = a;
  }


//--------------------------METHODS---------------------------


//==========================TOSTRING===========================

  public String toString ()  {
    /*  This method returns the string representation of a RInteger.

        Pre : none

        Post: the string representation of an RInteger is returned
    */

    RInteger a = this;
    return String.valueOf(a.intValue());
  }


//===========================EQUALS============================

  public boolean equals (Object y)      {
    /*  This method determines if two RIntegers are equal.

        Pre : given a Object to compare the implicit RInteger too

        Post: true is returned if the RIntegers have equals values
    */

    RInteger a = this;
    RInteger b = (RInteger) y;
    return a.intValue() == b.intValue();
  }


//=======================SETVALUE=====================


  public void setValue(int a)  {
    /*  This method sets the x field of the RDouble.

        Pre : given the new double value (a)

        Post: the value of x field is updated
    */

    this.x = a;
  }


//==================== Implementation of Number methods ===================


/* These methods override the methods of the number class.

   Pre : none

   Post: the RInteger field is returned cast as a specific primitive number
         type.
*/

  public int intValue()   {
    return x;
  }

  public byte byteValue()   {
    return (byte) x;
  }

  public short shortValue()   {
    return (short) x;
  }

  public long longValue()   {
    return (long) x;
  }

  public float floatValue()   {
    return (float) x;
  }

  public double doubleValue()   {
    return (double) x;
  }


//================= Implementation of Relational methods =================

  /* These methods are from the relational interface. They provide the <,>,<=,
     and >= operations for a RInteger.

     Pre : given another Relational (RInteger)

     Post: the values of the RIntegers are compared and the appropriate
           boolean is returned
  */

  public boolean lessThan (Relational y) {
    RInteger a = this;
    RInteger b = (RInteger) y;
    return a.intValue() < b.intValue();
  }

  public boolean greaterThan (Relational y) {
    RInteger a = this;
    RInteger b = (RInteger) y;
    return a.intValue() > b.intValue();
  }

  public boolean lessThanOrEqual (Relational y) {
    RInteger a = this;
    RInteger b = (RInteger) y;
    return a.intValue() <= b.intValue();
  }

  public boolean greaterThanOrEqual (Relational y) {
    RInteger a = this;
    RInteger b = (RInteger) y;
    return a.intValue() >= b.intValue();
  }

} // end class RInteger
              
