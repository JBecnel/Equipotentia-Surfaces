package math;           // class is part of the math package

import java.text.*;

/*      Jeremy Becnel        Applet Contest           11/7/98

        This class defines some mathematical operations.
*/


public class MathOps  {


//--------------------------METHODS----------------------------


//============================GCD==============================

  public static int gcd(int x, int y)  {
    /* This method returns the greatest common denominator of two
       integers.

       Pre : given the two integers (x, and y);

       Post: the greatest common denominator of x and y is returned
    */

    int min = Math.min(x,y);

    for (int i = min; i > 1; i--)
      if ((x % i == 0)  && (y % i == 0))
        return i;

    // is no gcd is returned
    return 1;
  }


//====================SCIENTIFICNOTATIONFORMAT========================

  public static int scientificNotationFormat(RDouble sig)  {
    /*  This method puts the given double in scientific notation.

        Pre : given the number to be put in scientific notation

        Post: the exp is returned and the sig has the value of the
              form x.xxxxx
    */

    DecimalFormat decFormat = new DecimalFormat("0.0#####E0###");

    String value = decFormat.format(sig.doubleValue());
    int index = value.indexOf('E', 2);
    String num = value.substring(0, index);
    String exp = value.substring(index+1, value.length());

    sig.setValue(Double.valueOf(num).doubleValue());
    return Integer.valueOf(exp).intValue();
  }


//=======================FORMATDECIMALPLACE=============================

  public static double formatDecimalPlace(double value, int place)  {
    /*  This method formats a value to a certain place after the
        decimal.

        Pre : given the value to format and the decimal place to format it

        Post: the value is format and returned
    */

    // create a number format to format the value
    NumberFormat numFormat = NumberFormat.getInstance();
    numFormat.setMaximumFractionDigits(place);

    numFormat.setGroupingUsed(false);

    String number =  numFormat.format(value);

    // return the double value of the formated number
    return Double.valueOf(number).doubleValue();    
  }
        

}       // end class MathOps
