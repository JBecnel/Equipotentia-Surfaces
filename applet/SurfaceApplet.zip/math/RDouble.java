package math;                        // class is in the math package

/* Jeremy Becnel        Applet Contest         12/19/98

  Class RDouble is a subclass of Number and implements the Relational
  interface.  This class represents doubles that also have the
  relational operations for <, >, <=, and >= on them.
*/



public class RDouble extends Number implements Relational        {


//----------------------------FIELD----------------------

  private double x;     // representation


//-------------------------CONSTRUCTOR--------------------

  public RDouble (double a) {
    /*  This constructor creates a RDouble with value a.

        Pre : given an double for the value of the relational double

        Post: a relational double is created
    */

    x = a;
  }


//--------------------------METHODS---------------------------


//==========================TOSTRING===========================

  public String toString ()  {
    /*  This method returns the string representation of a RDouble.

        Pre : none

        Post: the string representation of an RDouble is returned
    */

    RDouble a = this;
    return String.valueOf(a.doubleValue());
  }


//===========================EQUALS============================

  public boolean equals (Object y)      {
    /*  This method determines if two RDoubles are equal.

        Pre : given a Object to compare the implicit RDouble too

        Post: true is returned if the RDoubles have equals values
    */

    RDouble a = this;
    RDouble b = (RDouble) y;
    return a.doubleValue() == b.doubleValue();
  }


//=======================SETVALUE=====================


  public void setValue(double a)  {
    /*  This method sets the x field of the RDouble.

        Pre : given the new double value (a)

        Post: the value of x field is updated
    */

    this.x = a;
  }


//==================== Implementation of Number methods ===================


  /* These methods override the methods of the number class.

     Pre : none

     Post: the RDouble field is returned cast as a specific primitive number
          type.
  */


  public double doubleValue()   {
    return x;
  }

  public byte byteValue()   {
    return (byte) x;
  }

  public short shortValue()   {
    return (short) x;
  }

  public int intValue()   {
    return (int) x;
  }

  public long longValue()   {
    return (long) x;
  }

  public float floatValue()   {
    return (float) x;
  }


//================= Implementation of Relational methods =================

  /* These methods are from the relational interface. They provide the <,>,<=,
     and >= operations for a RDouble.

     Pre : given another Relational (RDouble)

     Post: the values of the RDoubles are compared and the appropriate
           boolean is returned
  */

  public boolean lessThan (Relational y) {
    RDouble a = this;
    RDouble b = (RDouble) y;
    return a.doubleValue() < b.doubleValue();
  }

  public boolean greaterThan (Relational y) {
    RDouble a = this;
    RDouble b = (RDouble) y;
    return a.doubleValue() > b.doubleValue();
  }

  public boolean lessThanOrEqual (Relational y) {
    RDouble a = this;
    RDouble b = (RDouble) y;
    return a.doubleValue() <= b.doubleValue();
  }

  public boolean greaterThanOrEqual (Relational y) {
    RDouble a = this;
    RDouble b = (RDouble) y;
    return a.doubleValue() >= b.doubleValue();
  }

} // end class RDouble











