package point;                  // class is part of the point package

import java.io.*;               // contains Serializable interface

/*           Jeremy Becnel      Applet Contest               11/30/98

        This class defines a 2 dimensional point that is serializable.
*/


public class Point2D implements Serializable   {


//--------------------------FIELDS----------------------------

  public double x;      // x coordinate
  public double y;      // y coordinate


//-----------------------CONSTRUCTORS-------------------------

  public Point2D ()  {
    /* This constructor creates a Point2D object and sets it's
       fields to 0.

       Pre : none

       Post: the object is created and the fields are set
    */

    this(0, 0);
  }


  public Point2D (double x, double y)  {
    /* This constructor creates a Point2D object and sets it's
       fields to the given coordinates.

       Pre : given two doubles to set the fields to

       Post: the object is created and the fields are set
    */

    setX(x);
    setY(y);
  }


//-------------------------METHODS---------------------------


//==========================GETX=============================

  public double getX()  {
    /* This method returns the value of the x field.

       Pre : none

       Post: the x value is returned
    */

    return x;
  }


//==========================GETY=============================

  public double getY()  {
    /* This method returns the value of the y field.

       Pre : none

       Post: the y value is returned
    */

    return y;
  }


//==========================SETX=============================

  public void setX(double x)  {
    /* This method sets the value of the x field.

       Pre : given a double x 

       Post: the x value is set to the given double
    */

    this.x = x;
  }
 

//==========================SETY=============================

  public void setY(double y)  {
    /* This method sets the value of the y field.

       Pre : given a double y 

       Post: the y value is set to the given double
    */

    this.y = y;
  }


//========================MIDPOINT============================

  public static Point2D midPoint(double x0, double y0, double x1, double y1) {
    /*  This method finds the mid point between two points.

        Pre : the two points are given by four doubles
              (x0, y0) represents the first point
              (x1, y1) represents the second point]

        Post: the mid point of the given points is returned
    */

    double x = (x0 + x1)/2.0;
    double y = (y0 + y1)/2.0;

    return new Point2D(x,y);
  }


  public static Point2D midPoint(Point2D p0, Point2D p1) {
    /*  This method finds the mid point between two points.

        Pre : the two points are given 

        Post: the mid point of the given points is returned
    */

    return midPoint(p0.x, p0.y, p1.x, p1.y);
  }     


//==========================SWAP==============================

  public void swap()    {
    /* This method swaps the values of the x and y coordinates.

       Pre : given an implicit point.

       Post: the values are set
    */

    double temp = getX();
    setX(getY());
    setY(temp);
  }


//======================SETLOCATION============================

  public void setLocation(Point2D point)   {
    /* This method sets the location of a point to that of a given point.

       Pre : given two points (one implicit)

       Post: the implicit point is set to the point parameter
    */

    setX(point.getX());
    setY(point.getY());
  }


//========================SETLOCATION============================

  public void setLocation(double x, double y)   {
    /* This method sets the location of a point to that of the given
       coordinates.

       Pre : given an implicit point and values to set it's fields to

       Post: the implicit point is set to the given coordinates
    */

    setX(x);
    setY(y);
  }


//=========================TRANSLATE=================================

  public void translate(double x, double y)   {
    /* This method adds the given coordinates to the values of the
       point's fields.

       Pre : given two doubles

       Post: the fields the incremented by the given values
    */

    this.x += x;
    this.y += y;
  }


//===========================DISTANCE============================

  public double distance (Point2D destination)  {
    /*  This method returns the distance between two points.

        Pre : given the destination point

        Post: the distance between the implicit point and the
              destination is returned
    */

    return distance(destination.getX(), destination.getY());
  }


  public double distance (double x, double y)  {
    /*  This method returns the distance between two points.

        Pre : given the destination point as a x,y pair

        Post: the distance between the implicit point and the
              destination is returned
    */

    Point2D source = this;

    double deltaX = source.getX() - x;    // x0 - x1
    double deltaY = source.getY() - y;    // y0 - y1

    // return sqaure root of the difference in the x's square
    // plus the difference in the y's squared
    return Math.sqrt(deltaX * deltaX + deltaY * deltaY);
  }

//============================EQUALS============================

  public boolean equals(Object p1)  {
    /*  This method compares two points to see if they are equals.  Two
        points are equals if they have the same x and y values.

        Pre : given the point to compare it the implicit point too

        Post: true is return is the points are equals false otherwise
    */

    Point2D point = (Point2D) p1;
    return (this.x == point.x && this.y == point.y);
  }


//===========================TOSTRING============================

  public String toString() {
    /* This method returns the string representation of a point2D.

       Pre : given a implicit point

       Post: the string representaion is returned
    */

    return "( " + String.valueOf(getX()) + " , "
                + String.valueOf(getY()) + " )";
   }

}  // end class Point2D

