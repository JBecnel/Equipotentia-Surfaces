package window;

import java.awt.event.*;
import java.awt.Window;
import java.applet.Applet;

/*      Jeremy Becnel          Applet Contest                12/18/98

       This class enables frames and windows to be closed and shuts down
   the program.
*/


public class BasicWindowMonitor extends WindowAdapter {


//--------------------------FIELDS--------------------------------

  private boolean exitable;      // this determines if closing the window
                                 // will close the hole program

  private Applet applet;         // applet window to be closes when listening
                                 // to a applet window

//-----------------------CONSTRUCTOR------------------------------


  public BasicWindowMonitor()  {
    /*  This method create a basic window monitor to handle closing
        the window.

        Pre : none

        Post: the basic window monitor is created
    */

    this(true);
  }


  public BasicWindowMonitor(boolean exitable)  {
    /*  This method create a basic window monitor to handle closing
        the window.

        Pre : given a boolean representing if the closing the window
              should exit the program

        Post: the basic window monitor is created
    */

    this(null, exitable);
  }


  public BasicWindowMonitor(Applet applet)  {
    /*  This method create a basic window monitor to handle closing
        the window.

        Pre : given the applet to destroy when window is closed

        Post: the basic window monitor is created
    */

    this (applet, true);
  }


  public BasicWindowMonitor(Applet applet, boolean exitable)  {
    /*  This method create a basic window monitor to handle closing
        the window.

        Pre : given the applet to destroy when window is closed
              given a boolean representing if the closing the window
              should exit the program

        Post: the basic window monitor is created
    */

    this.applet = applet;
    this.exitable = exitable;
  }


//---------------------------METHODS---------------------------
  

//==========================SETEXITABLE========================

  public void setExitable(boolean exitable)  {
    /*  This method determines whether or not a basic window monitor
        has the ability to close the whole program.

        Pre : given the exitable value

        Post: the field is set to the new value
    */

    this.exitable = exitable;
  }

                                
//==========================ISEXITABLE========================
                                
  public boolean isExitable()  {
    /*  This method returns the exitable value of the  basic window monitor.

        Pre : none
                        
        Post: the field is returned
    */

    return exitable;
  }


//==========================GETAPPLET========================

  public Applet getApplet()  {
    /*  This method gets the applet field of the class instance.
     
        Pre : given the applet value

        Post: the field is set to the new value
    */

    return applet;
  }


//==========================SETAPPLET========================

  public void setApplet(Applet applet)  {
    /*  This method gets the applet field of the class instance.

        Pre : given the applet value

        Post: the field is set to the new value
    */

    this.applet = applet;
  }


//=========================WINDOWCLOSING=======================

  public void windowClosing (WindowEvent e) {
    /*  This method closing the window and exits the program if the
        window is an exitable window.

        Pre : given the window event

        Post: the window is closed
    */

    Window w = e.getWindow();
    w.setVisible(false);
    w.dispose();

    if (isExitable()) {
      if (applet == null)
        System.exit(0);
      else
        applet.destroy();
    }
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "BasicWindowMonitor : \n";
                
    s += super.toString();

    return s;
  }

}       // end class BasicWindowMonitor
