package window;                 // class is part of window package

import java.awt.*;
import java.awt.geom.*;
import point.Point2D;


/*      Jeremy Becnel         Applet Contest                12/1/98

        This cass defines a window to canvas object which allows
   the user to change coordinate systems.
*/


public class WindowToCanvas implements Cloneable   {


//------------------------------FIELDS----------------------------------

  public double cx1, cy1, cx2, cy2;       // old coordinate system
  public double wx1, wy1, wx2, wy2;       // new coordinate system

  private AffineTransform transform;      // current coordinate system
  private AffineTransform inverse;        // previous coordinate system


//---------------------------CONSTRUCTORS-------------------------------

  public WindowToCanvas()   {
    /* This class creates a window to canvas object and forms the
       appropriate coordinate system.

       Pre : none

       Post: the window to canvas system is made
    */

    transform = new AffineTransform();

    // set the coordinates
    wx1 = 0;  wy1 = 0; wx2 = 1; wy2 = 1;
    cx1 = 0;  cy1 = 0; cx2 = 400; cy2 = 200;

    // calculate the new transform
    calcTransform();
  }


//------------------------------METHODS---------------------------------


//=============================SETWINDOW=================================

  public void setWindow  (double x1, double y1, double x2, double y2)  {
    /* This method sets the windows coordinates.

       Pre : given the beginning and ending coordinates

       Post: the windows coordinates are set
    */

     wx1 = x1;
     wy1 = y1;
     wx2 = x2;
     wy2 = y2;

     calcTransform();           // calculate the new transform
   }


//=============================SETCANVAS=================================

  public void setCanvas (double x1, double y1, double x2, double y2)  {
    /* This method sets the canvas's coordinates.

       Pre : given the beginning and ending coordinates

       Post: the canvas's coordinates are set
    */

     cx1 = x1;
     cy1 = y1;
     cx2 = x2;
     cy2 = y2;

     calcTransform();           // calculate the new transform
   }


//============================CALCTRANSFORM=============================

  public void calcTransform()    {
    /* This method sets a new coordinate system for the current window.

       Pre : none

       Post: the new transform is calculated
    */

    transform.setToScale((cx2 - cx1)/(wx2 - wx1) , - (cy2 - cy1)/(wy2 - wy1));
    transform.translate(-wx1, -wy2);

    try {
      inverse = transform.createInverse();
    }
    catch (NoninvertibleTransformException e)     {
      System.out.println("WindowToCanvas.calcTransform exception : " + e);
      e.printStackTrace();
    }
  }


//============================GETTRANSFORM==============================

  public AffineTransform getTransform()  {
    /* This method returns the transformed coordinate system.

       Pre : none

       Post: the transformed system is returned
    */

    return transform;
  }


//=============================GETINVERSE===============================

  public AffineTransform getInverse()  {
    /* This method returns the inverted coordinate system.

       Pre : none

       Post: the inverted system is returned
    */

    return inverse;
  }


//=========================CONVERTTOWINDOW============================

  public double[] convertToWindow(double[] canvasPoint)  {
    /*  This method converts the given coordinates from canvas
        coordinates to window coordinates.
                                          
        Pre : given the canvas point in the double array

        Post: the cooresponding point on the window is returned
    */


    // cooresponding window point
    double[] p2 = new double[2];

    // find the point
    this.getInverse().transform(canvasPoint,0,p2,0,1);

    // return the window point
    return p2;
  }


  public Point2D convertToWindow(Point2D canvasPoint)  {
    /*  This method converts the given coordinates from canvas
        coordinates to window coordinates.
                                          
        Pre : given the canvas point

        Post: the cooresponding point on the window is returned
    */


    return convertToWindow(canvasPoint.getX(), canvasPoint.getY());
  }


  public Point2D convertToWindow(double x, double y)  {
    /*  This method converts the given coordinates from canvas
        coordinates to window coordinates.
                                          
        Pre : given the canvas point as a (x, y) pair

        Post: the cooresponding point on the window is returned
    */

    double[] p = {x,y};

    double[] windowPoint = convertToWindow(p);

    return new Point2D(windowPoint[0], windowPoint[1]);
  }

//=========================CONVERTTOCANVAS============================

  public double[] convertToCanvas(double[] windowPoint)  {
    /*  This method converts the given coordinates from window
        coordinates to canvas coordinates.
                                          
        Pre : given the canvas point in the double array

        Post: the cooresponding point on the canvas is returned
    */


    // cooresponding window point
    double[] p2 = new double[2];

    // find the point
    this.getTransform().transform(windowPoint,0,p2,0,1);

    // return the window point
    return p2;
  }


  public Point2D convertToCanvas(Point2D windowPoint)  {
    /*  This method converts the given coordinates from window
        coordinates to canvas coordinates.
                                          
        Pre : given the windows point 

        Post: the cooresponding point on the canvas is returned
    */

    return convertToCanvas(windowPoint.getX(), windowPoint.getY());
  }


  public Point2D convertToCanvas(double x, double y)  {
    /*  This method converts the given coordinates from window
        coordinates to canvas coordinates.
                                          
        Pre : given the windows point as a (x,y) pair

        Post: the cooresponding point on the canvas is returned
    */

    double[] p = {x, y};

    double[] canvasPoint = convertToCanvas(p);

    return new Point2D(canvasPoint[0], canvasPoint[1]);
  }


//=============================RESIZEWINDOW==============================

  public void resizeWindow  (double incWx1, double incWy1, double incWx2, double incWy2)  {
    /* This method resizes the window.

       Pre : given the increment of resization

       Post: the window is resized
    */

     wx1 += incWx1;
     wy1 += incWy1;
     wx2 += incWx2;
     wy2 += incWy2;

     calcTransform();           // calculate the new transform
   }


//================================CLONE================================

  public Object clone()  {
    /*  This method returns a clone of the window to canvas.

        Pre : none

        Post: a window to canvas object with the same parameters is
              returned
    */

    WindowToCanvas wc = new WindowToCanvas();

    wc.setWindow(this.wx1, this.wy1, this.wx2, this.wy2);
    wc.setCanvas(this.cx1, this.cy1, this.cx2, this.cy2);

    return wc;
  }

//===============================TOSTRING===============================

  public String toString()  {
    /* This method returns a string representation of a window to
       canvas object.

       Pre : none

       Post: the string representation is returned
    */

    String s = "Window Coordinates\n" +
                String.valueOf(wx1) + " " + String.valueOf(wy1) + "\n" +
                String.valueOf(wx2)  + " " + String.valueOf(wy2) + "\n" +
                "Canvas Coordinates\n"  +
                String.valueOf(cx1) + " " + String.valueOf(cy1) + "\n" +
                String.valueOf(cx2)+ " " + String.valueOf(cy2) + "\n" +
                "Transform " + transform.toString();
    return s;
  }

}   // end class WindowToCanvas

    


