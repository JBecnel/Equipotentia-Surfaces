This is the source code for the Equipotential Surfaces Applet.

The actual applet is located in the file SurfaceApplet at the root directory.
There is also a properties file (Surface.properties) that contains the resources 
the applet users.

The states subdirectory contains the state machine controller code for the applet.
The model subdirectory contains the model code used to represent the particles, equipotential surfaces, and electric field used in the project.
