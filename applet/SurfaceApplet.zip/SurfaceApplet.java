import java.awt.*;
import java.applet.*;
import java.util.*;

import icon.*;
import model.*;
import window.*;
import projectgui.*;
import actions.*;
import states.*;
import optionPane.OptionPane;


/*   Jeremy Becnel           Applet Contest                 12/12/98
                        
   This class creates the potential surface project.
*/
   

public class SurfaceApplet extends Applet  {

//------------------------------FIELDS---------------------------------
                                                
  private TextField statusView; // text field for model status
  private TextField pointView;  // text field for field coordinates
  private ParticleMenu menu;    // menu to configure particle


//------------------------------METHODS---------------------------------


//============================GETRESOUCES===============================

  private PropertyResourceBundle getResources()  {
    /*  This method gets the property resource bundle from the
        properties file.  It holds information about the project.

        Pre : none

        Post: the resource is returned
    */
    
    ProjectResource sr = new ProjectResource("Surface");
    return sr.getResources();
  }


//=============================SETWINDOW================================

  private WindowToCanvas setWindow()  {
    /* This method sets the window to canvas object for cooridnate
       transformation.

       Pre : none

       Post: the window to canvas object is returned
    */

    WindowToCanvas wc = new WindowToCanvas();  

    // transform the window to canvas
    wc.setWindow(0, 0, 100, 100);

    return wc;
  }


//=========================SETUPSOUTHPANEL============================


  private Panel setUpSouthPanel()  {
    /* This method sets up the south panel of the gui.

       Pre : none

       Post: the south panel is returned
    */


    // create the uneditable textfields
    statusView = new TextField("");
    statusView.setEditable(false);
    statusView.setBackground(Color.lightGray);
        // the status view is used to a helper to the user
        // it outputs what the program is doing

    pointView = new TextField("");
    pointView.setEditable(false);
    pointView.setBackground(Color.lightGray);
        // the point view outputs the point the mouse pointer is
        // on at any given time

    // add the pointView and the status panel to the bottom panel
    Panel bottom = new Panel();
    bottom.setLayout(new GridLayout(1,2,0,0));
    bottom.add(statusView);
    bottom.add(pointView);
    return bottom;
  }


//============================SETUPGUI================================


  private Frame setUpGui(ElectricField field, Actions actions,
                              PropertyResourceBundle resource, Icons icons) {
    /*  This method sets up the gui for the equipotential surface applet.

        Pre : given the icons and actions hashtable
              given the property resource bundle of the properties file
              also given the the field for the particles and loci

        Post: the frame containing the gui is returned
    */

    // create the particle menu to pass to states
    menu = new ParticleMenu(resource, actions);
    field.add(menu);

    // set up frame components
    ProjectMenubar menubar = new ProjectMenubar(actions, resource);
    Toolbar toolbar = new Toolbar(actions, resource, icons);    
    Panel southPanel = setUpSouthPanel();

    // create frame for views and set it's layout and size
    Frame frame = new Frame("Equipotential Surface Applet");        
    frame.setLayout(new BorderLayout());
    frame.setSize(ElectricField.WIDTH + 80, ElectricField.HEIGHT + 50);
    frame.setResizable(false);
    
    // add the frame's components
    frame.add(toolbar, "West");
    frame.setMenuBar(menubar);
    frame.add(southPanel, "South");
    frame.add(field,"Center");

    // make the frame listen to window events and key events
    frame.addWindowListener(new BasicWindowMonitor(this));
    frame.addKeyListener(field);

    // show the frame
    frame.setVisible(true);

    return frame;
  }

    
//===========================SETUPSTATES============================

  private void setUpStates(ElectricField field, Icons icons,
      PropertyResourceBundle resource, Actions actions, Frame frame)  {
    /*  This method sets up the states hashtable and initializes some of it's
        fields.

        Pre : given the electric field
              given the actions and icons hashtable
              given the frame holding the gui
              given the resource bundle of the properties filed

        Post: the states are set up
    */     

    // create the states
    States states = new States(resource, actions);

    // initalize fields of the state
    Iterator it = states.values().iterator();
    while (it.hasNext())    {
      State state = (State) it.next();
      state.setStates(states);
      state.setIcons(icons);
      state.setFrame(frame);
      state.setStatus(statusView);
      state.setPointView(pointView);
      state.setElectricField(field);
      state.setParticleMenu(menu);
    }

    // enter the main state
    MainState mainState = (MainState) states.get("MainState");
    MainState.setApplet(this);   // set applet controlled by main state
    mainState.enter();
  }


//===============================INIT==============================

  public void init()   {
    /* This method initializes the equipotential surface applet.

       Pre : none

       Post: the applet is initialized (the frame for the applet is
             created and shown)
    */

    // get the resources
    PropertyResourceBundle resource = getResources();
                                      
    // set the window
    WindowToCanvas wc = setWindow();

    // set the actions and icons hashtable
    Actions actions = new Actions(resource, wc);
    Icons icons = new Icons(resource);

    // create the electric field
    ElectricField electricField = new ElectricField(actions, wc);

    // add the views to the frame
    Frame frame = setUpGui(electricField, actions, resource, icons);

    // set the parent frame for any option panes
    OptionPane.setFrame(frame);

    // set up states and enter the main state
    setUpStates(electricField, icons, resource, actions, frame) ;
  }

}   // end class SurfaceApplet
