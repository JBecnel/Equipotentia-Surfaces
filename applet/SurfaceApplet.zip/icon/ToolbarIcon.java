package icon;         // class is part of the icon package

import javax.swing.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.awt.*;

import window.*;


/*   Jeremy Becnel           Applet Contest                 12/9/98

     This class defines a tool bar icon that paints the icons
     on the buttons.
*/



public class ToolbarIcon implements Icon  {


//--------------------------CONSTANTS--------------------------

  // constants representing the width and the height of the icon
  private static final int WIDTH = 40;
  private static final int HEIGHT = 40;


//---------------------------FIELDS---------------------------

  private ProjectIcon icon;         // icon to be drawn

  private static BufferedImage img = new BufferedImage(WIDTH, HEIGHT,
                                        BufferedImage.TYPE_INT_RGB);
                // used to draw the image and create graphics


//-------------------------CONSTRUCTORS-------------------------

  public ToolbarIcon(ProjectIcon icon)  {
    /*  This method creates a tool bar icon and intializes it's symbol
        field.

        Pre : given the project to draw

        Post: the tool bar icon is created
    */

    this.icon = icon;
  }


//---------------------------METHODS-----------------------------


//===========================GETWIDTH============================
                
  public int getIconWidth()  {
    /*  This method returns the width of the icon.

        Pre : none

        Post: the width is returned
    */

    return WIDTH;
  }


//===========================GETHEIGHT============================

  public int getIconHeight()  {
    /*  This method returns the height of the icon.

        Pre : none

        Post: the height is returned
    */

    return HEIGHT;
  }


//===========================PAINTICON==============================


  public void paintIcon(Component c, Graphics g, int x, int y) {
    /*  This method paints a icon on a component.

        Pre : given a component, a graphics object, and the x and y
              coordinates.

        Post: the icon is painted
    */

    // create a graphics object and draw the icon
    Graphics2D g2 = img.createGraphics();
    g2.setColor(Color.lightGray);        // background color
                                                                                                        
    // transform the coordinate system
    WindowToCanvas windowToCanvas = new WindowToCanvas();                                                                                                                                                                                                      
    windowToCanvas.setCanvas(0, 0, HEIGHT, WIDTH);
    windowToCanvas.setWindow(0, 0, 10, 10);              
    AffineTransform at = windowToCanvas.getTransform();
    g2.setTransform(at);

    g2.fillRect(0,0,10,10);   

    // set a default color and draw the icon
    g2.setColor(Color.black);
    icon.draw(g2);             
                                                                                                                                                                
    g.drawImage(img, 3, 3, null);
  }


//============================TOSTRING=========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none
        
        Post: the string representation is returned
    */
                
    String s = "ToolbarIcon  : ";

    s += icon.toString();

    return s;
  }

}  // end class tool bar icon
