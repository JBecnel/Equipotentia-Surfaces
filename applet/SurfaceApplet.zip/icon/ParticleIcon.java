package icon;         // class is part of the icon package

import java.awt.*;
import java.awt.geom.*;

import model.*;
import window.*;
import point.Point2D;


/*      Jeremy Becnel        Applet Contest               12/19/98
                                
     This class defines a particle icon to be used
     in the equipotential surface project.
*/


public class ParticleIcon extends ProjectIcon  {


//-----------------------------FIELDS----------------------------

  private Particle particle;    // this is the particle which is drawn
                                // as the icon
                                              
//--------------------------CONSTRUCTORS-------------------------

  public ParticleIcon()  {
    /* This method creates a particle icon.

       Pre : none

       Post: the icon is created
    */

    super();            // call to ProjectIcon constructor
  }


  public ParticleIcon(Particle particle)  {
    /* This method creates a particle icon.

       Pre : given the particle for the icon

       Post: the icon is created
    */

    this();            // call to above constructor
    this.particle = particle;
  }


//----------------------------METHODS----------------------------


//==========================GETPARTICLE==========================

  public Particle getParticle()  {
    /*  This method returns the particle field of the class.

        Pre : none

        Post: the particle field is returned
    */

    return particle;
  }


//==========================SETPARTICLE==========================

  public void setParticle(Particle particle)  {
    /*  This method sets the particle field of the class.

        Pre : given the particle 

        Post: the particle field is set
    */

    this.particle = particle;
  }


//=============================DRAW==============================
                                 
  public void draw(Graphics2D g2)  {
    /* This method draws the particle icon.

       Pre : given the graphics 2d object to be drawn upon

       Post: the icon is drawn
    */

    // record values of the particle fields
    Point2D position = particle.getPosition();
    double radius = particle.getRadius();
    particle.setPosition(new Point2D(5,5));
    particle.setRadius(5);

    // draw the particle and set it's field back to initial values
    particle.drawParticle(g2);
    particle.setRadius(radius);
    particle.setPosition(position);
  }


//============================TOSTRING=========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none
        
        Post: the string representation is returned
    */

    String s = "Particle Icon  : ";
                
    s += super.toString();

    return s;
  }

}  // end class Particle Icon
