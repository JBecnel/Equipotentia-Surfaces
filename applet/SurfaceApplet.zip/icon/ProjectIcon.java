package icon;         // class is part of the icon package

import java.awt.*;
import java.awt.geom.*;

import window.*;


/*      Jeremy Becnel         Applet Contest            12/11/98

     This class defines a icon to be used in for buttons
     faces and symbols on a canvas.
*/


public abstract class ProjectIcon   {


//-------------------------CONSTRUCTOR---------------------------

  public ProjectIcon ()  {
    /* This method creates a icon object 

       Pre : none
                                                
       Post: the object is created 
    */
  }


//---------------------------METHODS-------------------------------


//=============================DRAW=============================
                                                                        
  public abstract void draw (Graphics2D g2);
    // to be implemented by subclasses


//============================TOSTRING=========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none
        
        Post: the string representation is returned
    */

    String s = "ProjectIcon  : " ;

    return s + super.toString();
  }

}  // end class ProjectIcon
