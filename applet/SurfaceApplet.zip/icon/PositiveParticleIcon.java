package icon;         // class is part of the icon package

import java.awt.*;
import java.awt.geom.*;

import model.*;
import window.*;


/*      Jeremy Becnel        Applet Contest               12/9/98
                                
     This class defines a positive particle icon to be used
     in the equipotential surface project.
*/


public class PositiveParticleIcon extends ParticleIcon  {


//--------------------------CONSTRUCTORS-------------------------

  public PositiveParticleIcon()  {
    /* This method creates a positive particle icon.

       Pre : none

       Post: the icon is created
    */

    super();            // call to ParticleIcon constructor
  }


//----------------------------METHODS----------------------------

//=============================DRAW==============================
                                 
  public void draw(Graphics2D g2)  {
    /* This method draws the particle icon.

       Pre : given the graphics 2d object to be drawn upon

       Post: the icon is drawn
    */

    // create a a default positive particle to draw as the icon
    Particle positiveParticle = new Particle();
    this.setParticle(positiveParticle);

    super.draw(g2);
  }


//============================TOSTRING=========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none
        
        Post: the string representation is returned
    */

    String s = "Positive Particle Symbol  : ";
                
    s += super.toString();

    return s;
  }

}  // end class Positive Particle Symbol

