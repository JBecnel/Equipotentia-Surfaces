package icon;         // class is part of the icon package

import java.awt.*;
import java.awt.geom.*;

import model.*;
import window.*;


/*      Jeremy Becnel        Applet Contest               12/14/98
                                
     This class defines a locus icon to be used
     in the equipotential surface project.
*/


public class LocusIcon extends ProjectIcon  {


//--------------------------CONSTRUCTORS-------------------------

  public LocusIcon()  {
    /* This method creates a Locus icon.

       Pre : none

       Post: the icon is created
    */

    super();        // call to ProjectIcon constructor
  }


//----------------------------METHODS----------------------------


//===========================MAKEPATH============================

  private static GeneralPath makePath()  {
    /*  This method makes a path to be drawn as a locus icon.

        Pre : none

        Post: returns the made path
    */
  
    GeneralPath p = new GeneralPath();

    // draw the general path
    p.moveTo(2,0);
    p.quadTo(12, 10, 2, 10);

    return p;
  }


//=============================DRAW==============================
                                 
  public void draw(Graphics2D g2)  {
    /* This method draws the Locus icon.

       Pre : given the graphics 2d object to be drawn upon

       Post: the icon is drawn
    */

    g2.setFont(new Font("Locus Font Font", Font.BOLD, 3));
    g2.setColor(Locus.getColor());
    g2.draw(makePath());
  }


//============================TOSTRING=========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none
        
        Post: the string representation is returned
    */

    String s = "Locus Icon  : ";
                
    s += super.toString();

    return s;
  }

}  // end class Locus Icon


