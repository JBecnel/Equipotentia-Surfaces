package icon;         // class is part of the icon package

import java.awt.*;
import java.awt.geom.*;

import model.*;
import window.*;


/*      Jeremy Becnel        Applet Contest               12/5/98
                                
     This class defines a epsilon icon to be used
     in the equipotential surface project.
*/


public class EpsilonIcon extends ProjectIcon  {


//--------------------------CONSTRUCTORS-------------------------

  public EpsilonIcon()  {
    /* This method creates a Epsilon icon.

       Pre : none

       Post: the icon is created
    */

    super();            // call to ProjectIcon constructor
  }


//----------------------------METHODS----------------------------

//=============================DRAW==============================
                                 
  public void draw(Graphics2D g2)  {
    /* This method draws the Epsilon icon.

       Pre : given the graphics 2d object to be drawn upon

       Post: the icon is drawn
    */
    
    g2.setFont(new Font("Epsilon Font", Font.BOLD, 12));
    g2.setColor(Color.black);
      
    // reverse transform in order to draw string right side up
    AffineTransform at = (AffineTransform)g2.getTransform().clone();
    at.scale(1, -1);
    g2.setTransform(at);
    g2.drawString("E", 1.5F, -1.5F);
    g2.setTransform(g2.getTransform());
  }


//============================TOSTRING=========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none
        
        Post: the string representation is returned
    */

    String s = "Epsilon Icon  : ";
                
    s += super.toString();

    return s;
  }

}  // end class Epsilon Icon


