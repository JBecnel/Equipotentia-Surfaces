package icon;         // class is part of the icon package

import java.util.*;

import window.*;  


/*  Jeremy Becnel             Applet Contest            12/15/98

     This class defineds a Icons hash table that holds various
     icons.
*/


public class Icons extends Hashtable  {


//--------------------------CONSTRUCTORS--------------------------
                                                                                                        
  public Icons(ResourceBundle resources)  {
    /*  This constructor creates a hashtable that stores icons.
                                        
        Pre : given the resource bundle

        Post: the icons hashtable is created
    */

    super();            // call to hashtable constructor

    StringTokenizer tk = new StringTokenizer(resources.getString("Icons"));
                // traverses possible icons

    while (tk.hasMoreTokens())  {
      String name = tk.nextToken();
      ProjectIcon icon = null;
      try {
        // create a new instance of the icon and put it in the hashtable
        icon =(ProjectIcon) Class.forName("icon." + name + "Icon").newInstance();
        put(name, icon);
      }
      catch (Exception e) {
        System.out.println("Icons Exception : " + e);
        e.printStackTrace();
      }
    }  // end while
  }                   


//============================GETICON==========================

  public ProjectIcon getProjectIcon (String name)  {
    /* This method returns a projectIcon specified by it's name.

       Pre : given the projectIcon name

       Post: the projectIcon is returned
    */

    return (ProjectIcon) get(name);
  }


//============================TOSTRING=========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none
        
        Post: the string representation is returned
    */
                
    String s = "Icons  : ";

    s += super.toString();

    return s;
  }

}  // end class Icons
