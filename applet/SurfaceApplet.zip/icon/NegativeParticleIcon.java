package icon;         // class is part of the icon package

import java.awt.*;
import java.awt.geom.*;
import model.*;
import window.*;


/*      Jeremy Becnel        Applet Contest               12/7/98
                                
     This class defines a negative particle icon to be used
     in the equipotential surface project.
*/


public class NegativeParticleIcon extends ParticleIcon  {


//--------------------------CONSTRUCTORS-------------------------

  public NegativeParticleIcon()  {
    /* This method creates a negative particle icon.

       Pre : none

       Post: the icon is created
    */

    super();            // call to ParticleIcon constructor
  }


//----------------------------METHODS----------------------------

//=============================DRAW==============================
                                 
  public void draw(Graphics2D g2)  {
    /* This method draws the negative particle icon.

       Pre : given the graphics 2d object to be drawn upon

       Post: the icon is drawn
    */

    // create a default negative particle and draw it as the icon
    Particle negativeParticle = new Particle(5, -1);
    this.setParticle(negativeParticle);

    super.draw(g2);
  }


//============================TOSTRING=========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none
        
        Post: the string representation is returned
    */

    String s = "Negative Particle Icon  : ";
                
    s += super.toString();

    return s;
  }

}  // end class Negative Particle Icon

