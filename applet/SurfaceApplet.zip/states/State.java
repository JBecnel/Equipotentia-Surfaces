package states;          // class is part of the state package

import java.util.*;
import java.awt.*;
import java.beans.*;
import javax.swing.*;

import actions.*;
import model.*;
import icon.*;
import projectgui.*;


/*      Jeremy Becnel           Applet Contest            12/7/98

      This class defines  State  object used for determineing
      which state the potential surface project is in and what
      to do in that state.
*/


public abstract class State implements PropertyChangeListener  {


//--------------------------FIELDS--------------------------

  protected String name;               // name of the state
  protected Vector actionsListened;    // actions being listened to
  protected Actions actions;           // hashtable of actions 
  protected States states;             // states this state keeps track of
  protected Icons icons;               // icons for project parts
  protected TextField status;          // notifies user of project's status
  protected TextField pointView;       // notifies user of point position
  protected ParticleMenu particleMenu; // menu to change particle settings
  protected Frame frame;               // frame for the view
  protected ElectricField electricField;
                                       // field with particles and loci
  protected State concurrentState;

//------------------------CONSTRUCTOR------------------------

  public State() {
    /*  This method creates a state and intializes it's fields.

        Pre : none

        Post: the state is created
    */
  }


//-------------------------------METHODS-------------------------------


//==============================GETNAME============================

  public String getName()  {
    /*  This method returns the name field of the state

        Pre : none

        Post: the name field is returned
    */

    return name;
  }

                                
//==============================SETNAME============================
                
  public void setName(String name)  {
    /*  This method sets the name field of the state
                
        Pre : given the new value for the field

        Post: the name field is set
    */

    this.name = name;
  }


//========================GETACTIONSLISTENED=========================

  public Vector getActionsListened()  {
    /*  This method returns the actionsListened field of the state

        Pre : none

        Post: the actionsListened field is returned
    */

    return actionsListened;
  }

                                
//==============================SETACTIONSLISTENED============================
                
  public void setActionsListened(Vector actionsListened)  {
    /*  This method sets the actionsListened field of the state
                
        Pre : given the new value for the field

        Post: the actionsListened field is set
    */

    actionsListened =  actionsListened;
  }


//==============================GETSTATES============================

  public States getStates()  {
    /*  This method returns the states hashtable field of the state

        Pre : none

        Post: the states field is returned
    */

    return states;
  }

                                
//==============================SETSTATES============================
                
  public void setStates(States states)  {
    /*  This method sets the states field of the state
                
        Pre : given the new value for the field

        Post: the states field is set
    */

    this.states = states;
  }


//==============================GETICONS============================

  public Icons getIcons()  {
    /*  This method returns the icons field of the state

        Pre : none

        Post: the icons field is returned
    */

    return icons;
  }

                                
//==============================SETICONS============================
                
  public void setIcons(Icons icons)  {
    /*  This method sets the icons field of the state
                
        Pre : given the new value for the field

        Post: the icons field is set
    */

    this.icons = icons;
  }


//==============================GETSTATUS============================

  public TextField getStatus()  {
    /*  This method returns the status field of the state

        Pre : none

        Post: the status field is returned
    */

    return status;
  }

                                
//==============================SETSTATUS============================
                
  public void setStatus(TextField status)  {
    /*  This method sets the status field of the state
                
        Pre : given the new value for the field

        Post: the status field is set
    */

    this.status = status;
  }


//==============================GETPOINTVIEW============================

  public TextField getPointView() {
    /*  This method returns the pointView field of the state

        Pre : none

        Post: the pointView field is returned
    */

    return pointView;
  }

                                
//==============================SETPOINTVIEW============================
                
  public void setPointView(TextField pointView)  {
    /*  This method sets the pointView field of the state
                
        Pre : given the new value for the field

        Post: the pointView field is set
    */

    this.pointView = pointView;
  }


//==============================GETFRAME============================

  public Frame getFrame()  {
    /*  This method returns the frame field of the state

        Pre : none

        Post: the frame field is returned
    */

    return frame;
  }

                                
//==============================SETFRAME============================
                              
  public void setFrame(Frame frame)  {
    /*  This method sets the frame field of the state
                
        Pre : given the new value for the field

        Post: the frame field is set
    */

    this.frame = frame;
  }


//==========================GETPARTICLEMENU============================

  public ParticleMenu getParticleMenu()  {
    /*  This method returns the particleMenu field of the state

        Pre : none

        Post: the particleMenu field is returned
    */

    return particleMenu;
  }

                                
//============================SETPARTICLEMENU============================
                
  public void setParticleMenu(ParticleMenu particleMenu)  {
    /*  This method sets the particleMenu field of the state
                
        Pre : given the new value for the field

        Post: the particleMenu field is set
    */

    this.particleMenu = particleMenu;
  }


//===========================GETELECTRICFIELD=========================

  public ElectricField getElectricField()  {
    /*  This method returns the electric field of the state.

        Pre : none

        Post: the electric field is returned
    */

    return electricField;
  }

                                
//===========================SETELECTRICFIELD=========================

  public void setElectricField(ElectricField newField)  {
    /*  This method sets the electric field of the state.

        Pre : given the new electric field

        Post: the electric field is set
    */

    this.electricField = newField;
  }


//==============================SETACTIONS=============================

  public void setActions(Actions actions, PropertyResourceBundle resources) {
    /*  This method adds the actions listeners from the actions table
        to the state.
        
        Pre : given the actions and the property resource bundle

        Post: the action listeners are added
    */

    actionsListened = new Vector();

    StringTokenizer tk = new StringTokenizer(resources.getString(name));

    // go through actions and make the state a action listener of the actions
    while (tk.hasMoreTokens())  
      actionsListened.addElement(actions.getAction(tk.nextToken()));    
  } 


//==============================ENTER===================================

  public void enter()  {
    /*  This method enters a state (registers property change listeners).

        Pre : none

        Post: the state is entered
    */

    if (concurrentState != null)  {
      concurrentState.exit();
      concurrentState = this;
    }

    Iterator it = actionsListened.iterator();

    // go through and add this as a property change listener of each action
    while (it.hasNext())  {
      IAction action = (IAction) it.next();
      action.addPropertyChangeListener(this);
    }

    status.setText("");
  }


//==============================EXIT===================================

  public void exit()  {
    /*  This method exits a state (registers property change listeners).

        Pre : none

        Post: the state is exited
    */    

    Iterator it = actionsListened.iterator();

    // go through and add this as a property change listener of each action
    while (it.hasNext())  {
      IAction action = (IAction) it.next();
      action.removePropertyChangeListener(this);
    }
  }


//===========================PROPERTYCHANGE========================

  public void propertyChange(PropertyChangeEvent e) {
    // no action taken at this level; it is up to subclasses to
    // provide implementation for this method
  }


//==========================RECOMPUTE=========================

  protected void recompute()   {
    /*  This method ask the compute state to recompute after
        a particle has been added.

        Pre : none

        Post: the compute state recomputes
    */

    ComputeState state = (ComputeState) states.getState("ComputeState");
    state.recompute();
  }


//==============================TOSTRING==========================

  public String toString ()  {
    /*  This method returns the string representation of the state.

        Pre : none
        
        Post: the string representation is returned
    */

    String s = "State : " + name + "\n";
    s += "  ActionsListened : " + actionsListened + "\n";
    s += "  Status          : " + status.getText() + "\n";

    return s;
  }

}  // end class State
