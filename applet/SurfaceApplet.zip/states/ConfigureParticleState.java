package states;          // class is part of the state package

import java.beans.*;

import model.*;
import actions.*;   
import point.Point2D;
import optionPane.*;
import window.*;


/*      Jeremy Becnel          Applet contest            12/10/98
                                
        This class defines the ConfigureParticleState which is a used to
        change the fields of particles.
*/
                        
                                                                
public class ConfigureParticleState extends State  {


//------------------------------FIELDS----------------------------------

  private Point2D position;             // position of menu
  private Particle particle;            // particle that is being configured

//----------------------------CONSTRUCTOR----------------------------------

  public ConfigureParticleState()  {
    /*  This constructor creates a default add particle state.

        Pre : none

        Post: the state is created
    */

    super();            // call to state constructor
  }


//-------------------------------METHODS-----------------------------------


//================================ENTER====================================

  public void enter()  {
    /*  This method takes the appriproate actions when the state is entered

        Pre : none

        Post: the state is entered
    */

    super.enter();      // registers states as property change listener

    // set the status bar and show particle popup menu
    status.setText("Configure a Particle");
    showParticleMenu();                    
  }


//==========================SHOWPPARTICLEMENU==============================

  public void showParticleMenu()  {
    /*  This method shows a pop up menu for the particle with relative
        position equal to the position field of this state.

        Pre : none

        Post: if a particle has the same position as the position field
              a pop up menu is shown for it.
    */

    NParticle nParticle = electricField.getNParticle();
    this.particle = nParticle.findParticleWithPosition(position);

    // if a particle is found show the pop up menu
    if (particle != null) {
      WindowToCanvas wc = electricField.getWindowToCanvas();
      Point2D menuPosition = wc.convertToCanvas(position);
      particleMenu.show(electricField,
                        (int) menuPosition.getX(), (int) menuPosition.getY());
    }
  }



//===========================GETPARTICLE===============================

  public Particle getParticle() {
    /*  This method returns the particle field of the state.

        Pre : none

        Post: the particle field is returned
    */

    return particle;
  }
                                                            

//===========================GETPOSITION===============================

  public Point2D getPosition() {
    /*  This method returns the position field of the state.

        Pre : none

        Post: the position field is returned
    */

    return position;
  }

                                
//===========================SETPOSITION===============================

  public void setPosition(Point2D position) {
    /*  This method sets the position field of the state.

        Pre : given the new position

        Post: the position field is set
    */

    this.position = position;
  }


//==========================CONFIGUREPOSITION==============================

  public void configurePosition()  {
    /*  This method configures the position of a particle.

        Pre : none

        Post: the position is configured (changed) in accordance with
              the user input
    */

    status.setText(status.getText() + "'s Position");

    // create and show an option pane to get new position
    ParticlePositionOptionPane optionPane =
                               new ParticlePositionOptionPane(this.particle);
    optionPane.editParticle();

    recompute();        // recompute any changes to existing loci
  }         


//==========================REMOVEPARTICLE===========================

  public void removeParticle()  {
    /*  This method removes a particle from the field (and the nparticle
        object).

        Pre : none

        Post: the particle is removed
    */

    NParticle nParticle = electricField.getNParticle();

    // remove the particle from the nParticle vector and repaint the canvas
    nParticle.removeParticle(particle);
    electricField.repaint();

    // if there are no particles in the field clear all the loci
    if (nParticle.isEmpty())   
      electricField.getNLocus().clear();
    else 
      recompute();        // recompute any changes made to existing loci
  }


//==========================CONFIGURECHARGE==============================

  public void configureCharge()  {
    /*  This method configures the charge of a particle.

        Pre : none

        Post: the charge is configured (changed) in accordance with
              the user input
    */

    // create and show an option pane to get the new particle charge
    ParticleChargeOptionPane optionPane =
                                    new ParticleChargeOptionPane(particle);
    optionPane.editParticle();

    recompute();        // recompute any changes made to existing loci
  }




//==========================CONFIGURERADIUS==============================

  public void configureRadius()  {
    /*  This method configures the radius of a particle.

        Pre : none

        Post: the radius is configured (changed) in accordance with
              the user input
    */

    ParticleRadiusOptionPane optionPane
                                = new ParticleRadiusOptionPane(particle);
    optionPane.editParticle();

    status.setText("");
  }                    


//==========================CONFIGURECOLORS==============================

  public void configureColors()  {
    /*  This method configures the colors of a particle.

        Pre : none

        Post: the colors is configured (changed) in accordance with
              the user input
    */

    // create and show an option pane to get the new particle colors
    ParticleColorOptionPane optionPane = new ParticleColorOptionPane(particle);
    optionPane.editParticle();

    status.setText("");
  }


//=========================PROPERTYCHANGE=============================

  public void propertyChange(PropertyChangeEvent e)   {
    /*  This method takes the appropriate action when a property change
        occurs.

        Pre : given the property change event e

        Post: the appropriate action is taken
    */
    
    // if the mouse was clicked once
    String eventName = e.getPropertyName();

    if (eventName.equals("Move"))     
      configurePosition();
    else if (eventName.equals("Remove"))
      removeParticle();
    else  {
      status.setText(status.getText() +  "'s " + eventName);

      if (eventName.equals("Charge"))
        configureCharge();
      else if (eventName.equals("Radius"))
        configureRadius();
      else if (eventName.equals("Colors"))
        configureColors();
    }

    electricField.repaint();
  }                                 


//==============================TOSTRING==========================

  public String toString ()  {                                          
    /*  This method returns the string representation of the a
        ConfigureParticle state.

        Pre : none                              
        
        Post: the string representation is returned
    */

    String s = "ConfigureParticle State : \n";
                        
    s += super.toString();

    return s;
 }                                  

}   // end class ConfigureParticleState
