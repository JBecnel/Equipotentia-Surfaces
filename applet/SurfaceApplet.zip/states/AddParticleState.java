package states;          // class is part of the state package

import java.beans.*;

import model.*;
import point.Point2D;
import optionPane.*;


/*      Jeremy Becnel          Applet contest            12/8/98
                                
        This class defines the AddParticleState which is a used to
        add particles of different charges to the Canvas.
*/
                        
                                                                
public class AddParticleState extends State  {


//-------------------------------FIELDS------------------------------------

  private String particleType;    // type of the particle to add
                                  // determines charge of particle (+ or -)
  
//----------------------------CONSTRUCTOR----------------------------------

  public AddParticleState()  {
    /*  This constructor creates a default add element state.

        Pre : none

        Post: the state is created
    */

    super();            // call to state constructor
  }


//-------------------------------METHODS-----------------------------------


//===========================SETPARTICLETYPE==============================

  public void setParticleType (String particleType)  {
    /*  This method sets the particle type field of the state.

        Pre : given the particle type

        Post: the field is updated
    */

    this.particleType = particleType;
  }


//================================ENTER====================================

  public void enter()  {
    /*  This method takes the appropriate actions when the state is entered

        Pre : none

        Post: the state is entered
    */

    super.enter();      // registers state as property change listener


    StringBuffer type =  new StringBuffer(particleType);
    if (particleType.endsWith("At"))  {
      particleType = particleType.substring(0, particleType.length() - 2);
      type = type.delete(type.length() -2, type.length());

      status.setText("Add a " + type.insert(8, ' '));

      addParticleAtPoint(particleType);

      status.setText("");
    }
    else
      status.setText("Add a " + type.insert(8, ' '));

  }


//==========================PROPERTYCHANGE==================================

  public void propertyChange(PropertyChangeEvent e)   {
    /*  This method takes the appropriate action when a property change
        occurs.

        Pre : given the property change event e

        Post: the appropriated action is taken
    */

    // get the property name and where it occured
    String eventName = e.getPropertyName();
    Point2D particlePosition = (Point2D) e.getNewValue();

    // if the mouse was clicked once
    if (eventName.equals("Canvas1"))  
      addParticle(particlePosition);
  }


//=========================ADDPARTICLE========================

  private void addParticle(Point2D particlePosition)  {
    /*  This method adds a charged particle to the field.

        Pre : given the particle's position

        Post: the particle is added to the field
    */    

    // create a new particle and call a option pane to set it's fields
    Particle particle = new Particle();
    StandardParticleOptionPane optionPane
                = new StandardParticleOptionPane(particleType, getIcons());
    int option = optionPane.getData(particle);
    particle.setPosition(particlePosition);

    // add the particle to the field
    NParticle nParticle = electricField.getNParticle();
    if (option == OptionPane.OK)  {
      nParticle.addParticle(particle);
      electricField.repaint();
      recompute();              // recompute any loci
    }                     

    StringBuffer type =  new StringBuffer(particleType);
    status.setText("Add a " + type.insert(8, ' '));

    electricField.repaint();
  }


//=========================ADDPARTICLEATPOINT=======================

  public void addParticleAtPoint(String particleType)  {
    /* This method adds a particular (+ or -) type of particle at a
       point.

       Pre : given the type of particle

       Post: the particle is added to the nParticle vector and
             the canvas is repainted
    */

    // stop listening to canvas actions
    this.exit();

    // create a new particle and configure it with
    // data retrieved using the optionPane
    Particle particle = new Particle();
    FullParticleOptionPane optionPane
                 = new FullParticleOptionPane(particleType, getIcons());
    int option = optionPane.getData(particle);

    // add the particle to the field and repaint
    NParticle nParticle = electricField.getNParticle();
    if (option == OptionPane.OK)  {
      nParticle.addParticle(particle);
      electricField.repaint();
      recompute();      // recompute the change to any existing loci
    }
  }

//==============================TOSTRING==========================

  public String toString ()  {                                  
    /*  This method returns the string representation of the a
        AddParticle state.

        Pre : none                              
        
        Post: the string representation is returned
    */

    String s = "AddParticle State : \n";
                        
    s += "ParticleType " + particleType + "\n";
    s += super.toString();

    return s;
  }

}   // end class AddParticleState

