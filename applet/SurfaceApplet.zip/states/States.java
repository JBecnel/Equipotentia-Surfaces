package states;          // class is part of the state package

import javax.swing.*;
import java.util.*;
import actions.*;


/*      Jeremy Becnel         Applet Contest           12/9/98
                        
      This class defines a hashtable for States which are used to in
      the equipontenal surfaces project.
*/


public class States extends Hashtable    {


//-----------------------------CONSTRUCTOR---------------------------------


  public States (PropertyResourceBundle resources, Actions actions)  {
    /*  This constructor creates a states table which contains
        the all the states the model can be in.

        Pre : given the resource to look in and the actions hashtable

        Post: the states object is created
    */

    StringTokenizer tk = new StringTokenizer(resources.getString("States"));

    // go through states
    while (tk.hasMoreTokens())  {
      String name = tk.nextToken();

      State state = null;

      try {
        // create an instance of the appropriate class
        state = (State)  Class.forName("states." + name).newInstance();

        // intialize the fields of the state
        state.setName(name);                               
        state.setActions(actions, resources);

        // put the state on the table
        put (name, state);           
      }
      catch (Exception e)  {
        System.out.println("States Exception : "  + e);
        e.printStackTrace();
      }
    }  // end while
  }


//============================GETSTATE==========================


  public State getState(String name)  {
    /* This method returns a state specified by it's name.

       Pre : given the state name

       Post: the state is returned
    */

    return (State) get(name);
  }



//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "States Hashtable : \n";

    s += super.toString();

    return s;
  }
                     

}  // end class States

