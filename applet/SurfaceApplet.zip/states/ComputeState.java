package states;          // class is part of the state package

import java.beans.*;
import java.util.*;
import java.awt.geom.*;

import model.*;
import point.Point2D;
import optionPane.*;
import window.WindowToCanvas;


/*      Jeremy Becnel          Applet contest            12/12/98
                                
        This class defines the ComputeState which is a used to
        compute the potential at a point, find a point with a given
        potential, and find a locus of points with the same potential.        
*/
                        
                                                                
public class ComputeState extends State  {


//-------------------------------FIELDS------------------------------------

  private String value;           // name of the value to compute
  public static double EPSILON;   // margain of error
                                
//----------------------------CONSTRUCTOR----------------------------------

  public ComputeState()  {
    /*  This constructor creates a default compute element state.

        Pre : none

        Post: the state is created
    */

    super();            // call to state constructor
    EPSILON = 0.0001;   // default margain of error
  }


//-------------------------------METHODS-----------------------------------
                     

//=============================SETVALUE==============================

  public void setValue (String value)  {
    /*  This method sets the value field of the state.

        Pre : given the name of the value to find

        Post: the field is updated
    */

    this.value = value;
  }
                                       

//================================ENTER====================================

  public void enter()  {
    /*  This method takes the appropriate actions when the state is entered.

        Pre : none

        Post: the state is entered
    */

    if (value.equals("Potential") || value.equals("Locus")) {
      super.enter();      // registers states as property change listener
      status.setText("Find the " + value);
    }
    else {
      if (value.equals("Point"))
        findPoint();
      else {
        if (value.endsWith("At"))  {
          value = value.substring(0, value.length() - 2);

          if (value.equals("Potential"))
            computePotential();
          if (value.equals("Locus"))
            findLocus();
        }
      }  // end else
      status.setText("");
    }  // end else
  }


//==========================FINDPOINTOPTIONS=========================
 
  private Point2D[] findPointOptions(Point2D start, Point2D next)   {
    /* This method finds the next point to go to when searching the points
       for a certain potential.

       Pre : given the point started at the next point checked

       Post: the next points to check are found and returned
    */

    WindowToCanvas wc = electricField.getWindowToCanvas();
    NParticle nParticle = electricField.getNParticle();

    start = wc.convertToCanvas(start);
    next = wc.convertToCanvas(next);

    // find the distance between the x and y values of coordinates
    double x = next.getX();
    double y = next.getY();
    byte deltaX = (byte)Math.round(x - start.getX());
    byte deltaY = (byte)Math.round(y - start.getY());

    Point2D[] p = new Point2D[3];   // next 3 points to check

    // if the difference in the y's is 0 go left or right (in the x direction)
    if (deltaY == 0)  {
      p[0] = wc.convertToWindow(x + deltaX, y + 1);
      p[1] = wc.convertToWindow(x + deltaX, y);
      p[2] = wc.convertToWindow(x + deltaX, y - 1);
    }
    // if the difference in the x's is 0 go up or down (in the y direction)
    else if (deltaX == 0)  {
      p[0] = wc.convertToWindow(x - 1, y + deltaY);
      p[1] = wc.convertToWindow(x, y + deltaY);
      p[2] = wc.convertToWindow(x + 1, y + deltaY);
    }
    // if a corner point continue in that direction
    else {
      p[0] = wc.convertToWindow(x + deltaX, y + deltaY);
      p[1] = wc.convertToWindow(x, y + deltaY);
      p[2] = wc.convertToWindow(x + deltaX, y);
    }

    return p;
  }

//===========================FINDNEXTSEARCHPOINT===========================

  private Point2D findNextSearchPoint(Point2D start, Point2D next, Locus locus)   {
    /* This method finds the next point to go to when searching the points
       for a certain potential.

       Pre : given the point started at the next point checked

       Post: the next point is found and returned
    */

    NParticle nParticle = electricField.getNParticle();
    Point2D[] p = findPointOptions(start,next);   // next 3 points to check

    // return the point with potential closest to the potential of the locus
    return locus.nextPoint(p, nParticle);
  }     


//===========================FINDNEXTLOCUSPOINTS========================

  private Point2D findNextLocusPoint(Point2D start, Point2D next, Locus locus)   {
    /* This method finds the next point to go to when searching the points
       for a certain potential.

       Pre : given the point started at and the next point checked

       Post: the next locus point is found and returned
    */

    NParticle nParticle = electricField.getNParticle();
    Point2D[] p = findPointOptions(start,next);   // next 3 points to check

    // return the point closest to the potential of the locus
    return locus.nextPoint(p, nParticle);
  }     

//============================SEARCHPOINTS===============================

  private Point2D searchPoints(Point2D start, Point2D next,
                                Locus locus, double startPotential) {
    /*  This method searches the point of the window in order to find
        a point with the same potential as the given point.  It finds
        the initial point for the locus.

        Pre : given the starting point the next point to go to and
              the locus to find the initial point for
              also given the value of the potential at the starting point
              in order to prevent it from having to be computed twice
              (once as the start point and again as the next point)

        Post: the initial point of the locus is returned if it is found
              in the current window. The method will return null 
              if it starts to search outside the current window or
              is not getting any closer to finding the initial point
              for the locus.
    */

    NParticle nParticle = electricField.getNParticle();
    WindowToCanvas wc = electricField.getWindowToCanvas();
    double potential = locus.getPotential();

    double x = start.getX();
    double y = start.getY();

    
    // if the point is outside the range of the window return null
    // (i.e. there is no initial point in this window)
    // null is also returned if the maximum amout of points is checked
    if (x < wc.wx1 || x > wc.wx2 || y < wc.wy1 || y > wc.wy2 )  {
      return null;
    }
    else {

      // if the potential at the starting point is equal (with margain of
      // error epislon) to that of the locus return the starting point
      // (i.e. the starting point is the initial point)

      double startValue = Math.abs(potential - startPotential);
      if (startValue <= EPSILON)
        return start;
      // otherwise keep searching for initial point
      else {
        // find the potential at the next search point
        double nextPotential = nParticle.findPotential(next);
        double nextValue = Math.abs(potential - nextPotential);

        // return null if no progress is being made
        // (i.e. if the nextValue if 0.001 units further away from
        // the desired potenital than the start value.
        // Note: start and next Value tell how close the potential at
        // a point is to the closest point

        if (startValue - nextValue >= 0.001)
          return null;
        else {                                                     
          // keep searching by find the next point which has 
          // potential closest to that of the loci potential
          Point2D closest = findNextSearchPoint(start, next, locus);
          return searchPoints(next, closest, locus, nextPotential);
        }   // end else
      }  // end else
    } // end else
  } // end method


  public Point2D searchPoints(Point2D start, Point2D next, Locus locus) {
    /*  This method searches the point of the window in order to find
        a point with the same potential as the given point.  It finds
        the initial point for the locus.

        Pre : given the starting point the next point to go to and
              the locus to find the initial points for

        Post: the initial point of the locus is returned if it is found
              in the current window
    */

    NParticle nParticle = electricField.getNParticle();

    // the potential is found for the starting point so that it does
    // not have to be found again when it becomes the "next" point
    double potential = nParticle.findPotential(start);
    return searchPoints(start, next, locus, potential);
  }


//============================SETINITIALPOINT===========================

  private void setInitialPoint(Locus locus,
                                Point2D initialPoint, Point2D start)  {
    /*  This method sets the initial point field of the locus if
        the initial point is not null, otherwise (i.e. the point is null)
        the user is asked if they would like to perform another search.

        Pre : given the locus and initial point
              also given the starting point for another search

        Post: the initial point field is set or the user is notified that
              no point is found and asked if they desire to perform another
              search if the point is null
    */

    NLocus nLocus = electricField.getNLocus();
    WindowToCanvas wc = electricField.getWindowToCanvas();

    if (initialPoint != null) {
      // set the initial point of the locus, add it to the nlocus vector
      // and repaint the canvas
      locus.setInitialPoint(wc.convertToCanvas(initialPoint));
      nLocus.addLocus(locus);
      electricField.repaint();
    }
    else {
      // see if the user wants to perform another search
      NoPointOptionPane optionPane = new NoPointOptionPane();
      int option = optionPane.getData();
      if (option == OptionPane.YES)
        findPoint(locus.getPotential(), start);
    }
  }


//========================FINDSURROUNDINGPOINTS==========================

  private Point2D[] findSurroundingPoints(Point2D center)  {
    /*  This method returns a array holding the 8 points
        surrounding a center point.

        Pre : given the center point in window coordinates

        Post: the 8 surrounding points are returned in an array
    */

    // retrieve the x and y canvas coordinates
    WindowToCanvas wc = electricField.getWindowToCanvas();
    Point2D canvasPoint = wc.convertToCanvas(center);
    double x = canvasPoint.getX();
    double y = canvasPoint.getY();

    // find the 8 surronding points
    Point2D[] p = new Point2D[8];
    p[0] = wc.convertToWindow(x-1, y+1);
    p[1] = wc.convertToWindow(x-1, y);
    p[2] = wc.convertToWindow(x-1, y-1);
    p[3] = wc.convertToWindow(x, y+1);
    p[4] = wc.convertToWindow(x, y-1);
    p[5] = wc.convertToWindow(x+1, y+1);
    p[6] = wc.convertToWindow(x+1, y);
    p[7] = wc.convertToWindow(x+1, y-1);

    // return the array
    return p;
  }


//=======================FINDPOINTWITHPOTENTIAL==========================

  public void findPointWithPotential(double potential, Point2D start)  {
    /*  This method finds a point with a given potential.

        Pre : given the potential of the point to find

        Post: the potential of the point is found if it is
              located inside the frame
    */

    // get the necessary objects from the field
    NParticle nParticle = electricField.getNParticle();
    NLocus nLocus = electricField.getNLocus();

    // find the 8 surrounding points
    Point2D[] p = findSurroundingPoints(start);

    // create a new locus with the given potential
    Locus locus = new Locus();    
    locus.setPotential(potential);

    // find the next point to go to and start the search
    Point2D nextPoint = locus.nextPoint(p, nParticle);  
    Point2D initialPoint = searchPoints(start, nextPoint, locus);

    setInitialPoint(locus, initialPoint, start);
  }

//=============================FINDPOINT=================================

  public void findPoint()  {
    /*  This method finds a point with a potential given by the user.

        Pre : none

        Post: the point with the given potential is found (if exist)
    */

    status.setText("Find the Point with given potential.");    

    WindowToCanvas wc = electricField.getWindowToCanvas();

    // start defaultly at the midpoint
    Point2D midPoint = Point2D.midPoint(wc.wx1, wc.wy1, wc.wx2, wc.wy2);

    findPoint(1.0, midPoint);
  }


  public void findPoint(double potential, Point2D start)  {
    /*  This method finds a point with a potential given by the user.

        Pre : given the potentail and starting point as default values
              of the option pane

        Post: the point with the given potential is found (if exist)
    */

    // show option pane and get data for potential and
    // starting location
    PotentialOptionPane optionPane =
                        new PotentialOptionPane(getIcons(), potential, start);
    int option = optionPane.getData();
    potential = optionPane.getPotential();
    start = optionPane.getStartingPoint();

    // find the point
    if (option == OptionPane.OK)  
      findPointWithPotential(potential, start);
  }


//==========================CREATELOCUS=============================

  public Locus createLocus(Point2D initialPoint)  {
    /*  This method handles the creation of a locus at a point.

        Pre : given the initial point of the locus

        Post: the locus is created with the given point
              as it's initial point and potential as the
              potential at that point
    */

    WindowToCanvas wc = electricField.getWindowToCanvas();

    // create a new locus with the initial point
    Point2D point = wc.convertToCanvas(initialPoint);
    Locus locus = new Locus(point);

    NParticle nParticle = electricField.getNParticle();

    // find the potential at the initial point
    double potential = nParticle.findPotential(initialPoint);

    // set the potential for locus 
    locus.setPotential(potential);

    return locus;
  }                  


//=========================COMPUTEPOTENTIAL==============================

  public void computePotential()  {
    /*  This methods finds the point to compute the potential at
        and computes the potential at that point.

        Pre : none

        Post: the potential is computed
    */

    status.setText("Find the " + value);    

    // get the point and compute the potential there
    PotentialAtOptionPane optionPane = new PotentialAtOptionPane(getIcons());
    Point2D point = new Point2D();
    optionPane.setPoint(point);
    int option = optionPane.editPoint();

    if (option == OptionPane.OK)
      computePotential(point);
  }
                                                        

//=========================COMPUTEPOTENTIAL==============================

  public void computePotential(Point2D point)  {
    /*  This methods computes the potential at the given point.

        Pre : given the point for the new singleton locus and potential

        Post: the potential is computed
    */

    NLocus nLocus = electricField.getNLocus();
    nLocus.addLocus(createLocus(point));
    electricField.repaint();
  }
                     

//==========================FINDLOCUSPOINTS=============================

  private void findLocusPoints(Point2D start, Point2D next, Locus locus) {
    /*  This method searches the point of the window in order to find
        a point with the same potential as the given point.

        Pre : given the starting point the next point to go to and
              the locus to find locus points for

        Post: the initial point of the locus is returned if it is found
              in the current window. The method will return null if
              it gets detects a infinite recursion or it starts to search
              outside the current window.
    */

    NParticle nParticle = electricField.getNParticle();
    WindowToCanvas wc = electricField.getWindowToCanvas();
    double potential = locus.getPotential();

    double x = start.getX();
    double y = start.getY();
    
    Point2D closest = findNextLocusPoint(start, next, locus);
    Point2D c= wc.convertToCanvas(closest);
    Point2D i= locus.getInitialPoint();


    // find points until the locus returns to the initial point
    if (!(Math.round(c.getX()) == Math.round(i.getX())
                && Math.round(c.getY()) == Math.round(i.getY())))  {

      // add the point to the locus and find the next point
      locus.addPoint(c);        
      findLocusPoints(next, closest, locus);
    }
 
  } // end method

               
  private void findLocusPoints(Locus locus)  {
    /*  This method finds a locus of points with same potential to the
        left of the given locus.

        Pre : given the locus to find points for

        Post: the locus points to the left of the given locus are found
    */
    
    // get the necessary objects from the field
    WindowToCanvas wc = electricField.getWindowToCanvas();
    NParticle nParticle = electricField.getNParticle();
    NLocus nLocus = electricField.getNLocus();

    // get the corresponding canvas point
    Point2D[] surroundingPoints =
        findSurroundingPoints(wc.convertToWindow(locus.getInitialPoint()));

    // retrieve the next point to go to
    Point2D nextPoint = locus.nextPoint(surroundingPoints, nParticle);

    // add the point to the locus and find the other locus points
    locus.addPoint(wc.convertToCanvas(nextPoint));
    findLocusPoints(wc.convertToWindow(locus.getInitialPoint()), nextPoint, locus);
  }


//===========================FINDLOCUS===============================

  public void findLocus()   {
    /*  This method finds a locus of points with the same potential
        as a point entered in by the user.

        Pre : none

        Post: the locus with around the entered point is found
    */         

    status.setText("Find the " + value);
    NLocus nLocus = electricField.getNLocus();
    
    // create the option pane, get the point, and find the locus there
    Point2D point = new Point2D();
    LocusOptionPane optionPane = new LocusOptionPane(point, getIcons());
    int option = optionPane.editPoint();

    // create the new locus add it to the field and repaint
    if (option == OptionPane.OK) {
      Locus locus = createLocus(point);
      nLocus.addLocus(locus);
      findLocusPoints(locus);
      electricField.repaint();
    }                                          
  }            


//============================FINDLOCUSAT================================

  public void findLocusAt(Point2D point)   {
    /*  This method finds a locus of points with the same potential
        as the given point.

        Pre : given the point to find to start the locus at

        Post: the locus is found and the canvas is redrawn with the new
              locus
     */

     NLocus nLocus = electricField.getNLocus();
     WindowToCanvas wc = electricField.getWindowToCanvas();

     // find the locus at the given point
     Locus locus = nLocus.findLocusWithInitialPoint(point,wc);

     // if there is no existing locus at the given point create one
     // add it to the nLocus vector and find its points
     if (locus == null)  {
       locus = createLocus(point);
       nLocus.addLocus(locus);
     }

     if (locus.isSingle()) 
       findLocusPoints(locus);

     electricField.repaint();
   }


//=========================RECOMPUTELOCUSAT================================

  private Locus recomputeLocusAt(Point2D point)   {
    /*  This method finds a locus of points with the same potential
        as the given point.  Used to recompute locus values when a
        change occurs

        Pre : given the point to find the locus around

        Post: the locus is found 
     */                 

     Locus locus = createLocus(point);

     findLocusPoints(locus);
     return locus;
   }


//========================RECOMPUTELOCUS=================================

  private Locus recomputeLocus(Locus locus)  {
    /*  This method recomputes a locus when a change occurs.

        Pre : given the locus to recompute

        Post: the locus is recomputed
    */

    WindowToCanvas wc = electricField.getWindowToCanvas();
    NParticle nParticle = electricField.getNParticle();

    Point2D initialPoint = locus.getInitialPoint();
    Locus newLocus;

    // if the locus had points recompue them
    if (!locus.isSingle()) 
      newLocus = recomputeLocusAt(wc.convertToWindow(initialPoint));    
    else {
      // if locus is only made up of initial point just
      // recompute potential for the locus
      newLocus = new Locus (locus.getInitialPoint());      
      newLocus.setPotential(nParticle.findPotential(wc.convertToWindow(initialPoint)));
    }

    return newLocus;
  }


//============================RECOMPUTE=================================

  public void recompute()  {
    /*  This method recomputes all the loci to correspond with
        a change made (example: a particle added, removed, or moved).

        Pre : none

        Post: the loci are recomputed with the correct value
              (corresponding to the change made)
    */

    status.setText("Recomputing Loci");

    // set the nLocus object from the electric field
    NLocus nLocus = electricField.getNLocus();

    Iterator it = nLocus.getLoci().iterator();

    Vector loci = new Vector();

    while (it.hasNext()) {
      Locus locus = (Locus) it.next();
      Point2D initialPoint = locus.getInitialPoint();

      // recomput each locus
      loci.addElement(recomputeLocus(locus));

      // update the status bar
      status.setText(status.getText() + "..");
    }  // end while

    // set the new value for the loci vector
    nLocus.setLoci(loci);
    electricField.repaint();

    status.setText("");
  }


//==========================PROPERTYCHANGE===============================

  public void propertyChange(PropertyChangeEvent e)   {
    /*  This method takes the appropriate action when a property change
        occurs.

        Pre : given the property change event e

        Post: the appropiated action is taken
    */
    
    // if the mouse was clicked once
    String eventName = e.getPropertyName();
    Point2D point = (Point2D) e.getNewValue();

    if (eventName.equals("Canvas1"))  {
      if (value.equals("Potential"))
        computePotential(point);
      else if (value.equals("Locus")) 
        findLocusAt(point);                     
    }
    
  }

      
//==============================TOSTRING==========================

  public String toString ()  {                                  
    /*  This method returns the string representation of the a compute state.

        Pre : none                              
        
        Post: the string representation is returned
    */

    String s = "Compute State : \n";
                        
    s += " Value " + value + "\n";
    s += super.toString();

    return s;
 }                         

}   // end class ComputeState

