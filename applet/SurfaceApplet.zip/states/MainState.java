package states;          // class is part of the state package

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import java.beans.*;
import java.applet.Applet;

import model.*;
import point.Point2D;
import window.*;
import optionPane.*;

/*      Jeremy Becnel          Applet Contest            12/9/98

        This class defines the MainState used to handle the events
        that occur on the project.
*/


public class MainState extends State  {


//-------------------------------FIELDS------------------------------------

  private State concurrentState;    // state that is running at the same time
                                    // as (concurrently wiht) the main state
  private boolean listenToCanvas1;  // lets the canvas know if it has to
                                    // handle canvas1 actions

  private static Applet applet;     // applet state is controlling
                                                                        

//-----------------------------CONSTRUCTOR----------------------------------

  public MainState  ()  {
    /* This method created a main state by calling the super class.

       Pre : none

       Post: the main state is created
    */

    super();            // call to state constructor
  }


//-----------------------------METHODS---------------------------------


//============================SETAPPLET===============================

  public static void setApplet(Applet applet)  {
    /*  This method sets the applet field of the class.

        Pre : given the applet the main state controls

        Post: the applet is set
    */

    MainState.applet = applet;
  }
                                    

//============================CLEARACTION================================

  public void clearAction() {
    /*  This method creates the appearance of a new canvas to work on.

        Pre : none

        Post: the new action is handled
    */

    status.setText("");
    
    electricField.setNParticle(new NParticle());
    electricField.setNLocus(new NLocus());
    electricField.repaint();

    frame.setTitle("New Field");
  }                                    


//===========================EXITACTION====================================

  public void exitAction()  {
    /*  This method exits the applet normally when called.

        Pre : none

        Post: the applet is exited
    */
                                

    Frame frame = getFrame();
    frame.dispose();
    applet.stop();
    applet.destroy();
  }
  

//=============================FILEACTION==============================

  public void fileAction(String command)  {
    /*  This method delegates the command to the appropriate method
        when a item is clicked on in the file menu.

        Pre : given the command choosen

        Post: the action is delegated in accordance with the command
    */

    // exit any concurrent state
    if(concurrentState != null)
      concurrentState.exit();

    if (command.equals("Clear"))
      clearAction();
    else if (command.equals("Exit"))
      exitAction();

    status.setText("");
  }


//============================ADDPARTICLE====================================

  public void addParticle (String particleType)  {
    /*  This method moves the state to the addParticle state.

        Pre : given the type of particle to enter the state with

        Post: the addParticle state is entered
    */
        
    // get the add element state and set it's element type
    AddParticleState state = (AddParticleState) states.getState("AddParticleState");
    state.setParticleType(particleType);

    // exit any concurrent state
    if(concurrentState != null)
      concurrentState.exit();

    // enter state and make it the concurrent state
    state.enter();
    concurrentState = state;
  }


//==============================COMPUTE=================================

  public void compute(String data)  {
    /*  This method moves the concurrent state to the compute state.

        Pre : given the data or value to compute

        Post: the compute state is entered
    */
        
    // get the add element state and set it's element type
    ComputeState state = (ComputeState) states.getState("ComputeState");
    state.setValue(data);

    // exit any concurrent state
    if(concurrentState != null)
      concurrentState.exit();

    // enter state and make it the concurrent state
    state.enter();
    concurrentState = state;
  }


//============================DISPLAYABOUT============================

  public void displayAbout()  {
    /*  This method displays the about dialog for the help menu.

        Pre : none

        Post: the about dialog is displayed
    */

    status.setText("");
    AboutDialog about = new AboutDialog();
    about.show();
  }       


//=============================HELPACTION=============================
   
  public void helpAction(String choice)   {
    /* This method takes the appropriate action when a command from
       the help menu is choosen.

       Pre : given the help menu choice

       Post: the appropriate help action is taken
    */

    // exit any concurrent state
    if(concurrentState != null)
      concurrentState.exit();

    if(choice.equals("About"))
      displayAbout();
  }


//=============================AXISOPTION==============================

  public void axisOption()  {
    /*  This method opens a option pane to configure the axis of the
        electric field.

        Pre : none

        Post: the axis is configured
    */

    status.setText("Configure the axis");
    AxisOptionPane optionPane = new AxisOptionPane();
    optionPane.editAxis(electricField);
    status.setText("");
  }


//=========================CHANGEFIELDWIDTH===========================

  public void changeFieldWidth()  {
    /*  This method opens a option pane to configure the width of a field.

        Pre : none

        Post: the field parameters are changed
    */

    // create a field option pane and get the data
    WindowToCanvas wc = electricField.getWindowToCanvas();
    FieldOptionPane optionPane = new FieldOptionPane(wc.wx1, wc.wx2);
    int option = optionPane.editField();
    Point2D width = optionPane.getPoint();

    // set the field width in accordance with the data
    electricField.setFieldWidth(width.getX(), width.getY());    
  }


//=========================CHANGEFIELDHEIGHT===========================

  public void changeFieldHeight()  {
    /*  This method opens a option pane to configure the height of a field.

        Pre : none

        Post: the field parameters are changed
    */

    // create a field option pane and get the data
    WindowToCanvas wc = electricField.getWindowToCanvas();
    FieldOptionPane optionPane = new FieldOptionPane(wc.wy1, wc.wy2);
    int option = optionPane.editField();
    Point2D height = optionPane.getPoint();

    // set the field in accordance with the data
    electricField.setFieldHeight(height.getX(), height.getY());
  }


//=========================CHANGELOCUSCOLOR============================

  public void changeLocusColor()  {
    /*  This method changes the color used for loci of points.

        Pre : none

        Post: the locus color is updated to the users choice
    */

    LocusColorOptionPane optionPane = new LocusColorOptionPane(getIcons());
    optionPane.editColor();
  }


//=======================CHANGEPARTICLECOLOR=========================

  public void changeParticleColor(String particleType)  {
    /*  This method changes the default particle colors and
        applyies those changes to all particles if requested by the
        user.

        Pre : given the type of particle

        Post: the default color is changed
    */

    ParticleColorOptionPane optionPane =
                        new ParticleColorOptionPane(particleType,getIcons());
    optionPane.getData(electricField.getNParticle());
  }

//==========================CHANGEEPSILON==============================

  public void changeEpsilon()  {
    /*  This method configures the epsilon (margain of error allowed) used
        in computations.

        Pre : none

        Post: the epsilon value is changed to a value entered by the user
    */

    status.setText("Change Epsilon (Margain of Error).");
    EpsilonOptionPane optionPane = new EpsilonOptionPane();
    optionPane.editEpsilon();
  }


//===========================CHANGEOPTION==============================

  public void changeOption(String option)  {
    /*  This method delegate the option command to the appropriate
        method.

        Pre : given the option to configure

        Post: the appropriate method is called
    */

    // exit any concurrent state
    if(concurrentState != null)
      concurrentState.exit();

    StringBuffer buffer = new StringBuffer(option);
    if (option.equals("Axis"))  
      axisOption();
    else if (option.equals("Epsilon"))
      changeEpsilon();
    else if (option.equals("FieldHeight"))  {
      buffer = buffer.insert(buffer.length() - 6, ' ');
      status.setText("Change the " + buffer.toString());
      changeFieldHeight();
    }
    else {
      buffer = buffer.insert(buffer.length() - 5, ' ');
      status.setText("Change the " + buffer.toString());

      if (option.equals("FieldWidth"))
        changeFieldWidth();
      else if (option.equals("SurfaceColor"))
        changeLocusColor();
      else
        changeParticleColor(option);
    }

    frame.repaint();
    electricField.repaint();
    status.setText("");
  }


//==========================DISPLAYLOCUS==============================

  public void displayLocus(Point2D location)  {
    /*  This method displays a locus in order to view it's points
        and potential.

        Pre : none

        Post: the locus points and potential are displayed in a frame
    */                                       

    status.setText("Formulating locus display");

    NLocus nLocus = electricField.getNLocus();
    WindowToCanvas wc = electricField.getWindowToCanvas();

    // find the locus to be displayed
    Locus locus = nLocus.findLocusWithInitialPoint(location, wc);

    // if locus is found creat a view for the locus
    if (locus != null)
      new LocusView(locus, wc);

    status.setText("");
  }


//============================POPUPMENU================================

  public void popupMenu(Point2D point)  {
    /*  This method enters the configure particle state when called.

        Pre : given the point right clicked upon

        Post: the popupMenu state is entered
    */

    // get the add element state and set it's element type
    ConfigureParticleState state = (ConfigureParticleState)
                                states.getState("ConfigureParticleState");
    state.setPosition(point);

    // exit any concurrent state
    if(concurrentState != null)
      concurrentState.exit();

    // enter state and make it the concurrent state
    state.enter();
    concurrentState = state;     
  }


//==========================PROPERTYCHANGE==================================

  public void propertyChange(PropertyChangeEvent e)   {
    /*  This method takes the appropriate action when a property change
        occurs.

        Pre : given the property change event e

        Post: the appropiated action is taken
    */

    // retrieve the action name and where it occurred
    String action = e.getPropertyName();
    Point2D point = (Point2D) e.getNewValue();

    String command = new String(action);
    if (command.endsWith("At"))
      command = command.substring(0,command.length() - 2);
       
    // delegate the command to the appropriate method
    if (command.equals("CanvasMotion"))
      pointView.setText(point.toString());
    else if (command.endsWith("Particle"))
      addParticle(action);    
    else if (command.equals("Potential") ||
             command.equals("Locus") || command.equals("Point"))  {
      NParticle nParticle = electricField.getNParticle();
      if (!nParticle.isEmpty())
        compute(action);
      else
        new CannotComputeDialog();
    }
    else if (command.equals("CanvasRight"))
      popupMenu(point);
    else if (command.equals("Clear")  || command.equals("Exit"))
      fileAction(action);
    else if (command.equals("About"))
      helpAction(action);
    else if (command.endsWith("Color") || command.startsWith("Field") ||
            command.equals("Axis") || command.equals("Epsilon"))
      changeOption(action);
    else if (command.equals("DisplayLocus")) {

      status.setText("Select locus to display");

      if (concurrentState != null)
        concurrentState.exit();

      listenToCanvas1 = true;
    }
    else if (command.equals("Canvas1") && listenToCanvas1)  {
      displayLocus(point);
      listenToCanvas1 = false;
    }  // end if

  }   // end propertyChange
                                                                                             

//==============================TOSTRING==========================

  public String toString ()  {
    /*  This method returns the string representation of the a main state.

        Pre : none                              
        
        Post: the string representation is returned
    */

    String s = "Main State : \n";

    s += "ConcurrentState : "  + concurrentState + "\n";

    return s;
  } 

}   // end class Main State
