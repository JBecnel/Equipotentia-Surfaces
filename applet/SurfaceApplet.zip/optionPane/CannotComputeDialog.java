package optionPane;         // class is part of the option pane package

import javax.swing.*;
import java.awt.*;


/*   Jeremy Becnel            Applet Contest            3/2/99

     This class defines a option pane to notify the user that a
     computation can not be made.
*/


public class CannotComputeDialog extends OptionPane  {


//-----------------------------CONSTRUCTOR------------------------------


  public CannotComputeDialog()   {
    /*  This contructor creats a dialog for a notification prompt.

        Pre : none

        Post: the option pane is created
    */
    
    objects = new Object[1];
    objects[0] = new Label("Cannot compute potential or surfaces when no" +
                           " particles are placed on field.");

    options = new Object[1];
    options[0] = "OK";

    setTitle("Error");

    int option = super.getData();
  }


//-----------------------------METHODS---------------------------------


//=============================TOSTRING===========================

  public String toString()  {                           
    /*  This method returns the string representation of the save
        option pane.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "CannotCompute Dialog : \n";
                
    s += super.toString();

    return s;
  }


}   // end class CannotComputeDialog
