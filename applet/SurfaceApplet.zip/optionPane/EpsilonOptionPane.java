package optionPane;         // class is part of the option pane package

import java.awt.*;
import states.*;
import icon.*;


/*   Jeremy Becnel            Applet Contest            12/28/98

     This class defines a option pane for a the epsilon value of the
     compute state.
*/


public class EpsilonOptionPane extends OptionPane  {


//-----------------------------CONSTRUCTOR------------------------------
                
  public EpsilonOptionPane( )   {
    /*  This method creates an option pane for a epsilon value.

        Pre : none

        Post: the option pane is created
    */
    
    super();   // call to OptionPane constructor

    objects = new Object[2];

    objects[0] = new Label("Margin of Error (Epsilon) : ");
    objects[1] = new EpsilonPanel(ComputeState.EPSILON);

    setIcon(new ToolbarIcon(new EpsilonIcon()));
    setTitle("Enter Value for Epsilon");
  }


//-----------------------------METHODS---------------------------------
                                                  
//==========================EDITEPSILON=================================

  public void editEpsilon()   {
    /*  This method defines a retrives  data from a option pane
        and sets the s fields appropriately.

        Pre : none 

        Post: the option pane data is retrieved and the appropriate fields
              are set
    */

    // create the option pane 
    int option = super.getData();

    // retrieve the data
    double epsilon = ((EpsilonPanel)objects[1]).getEpsilon();

    // set the fields of the Compute State
    if (option != OptionPane.CANCEL) 
      ComputeState.EPSILON = epsilon;
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the
        Epsilon option pane.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "Epsilon Option Pane : \n";
                
    s += super.toString();

    return s;
  }


}   // end class EpsilonOptionPane


