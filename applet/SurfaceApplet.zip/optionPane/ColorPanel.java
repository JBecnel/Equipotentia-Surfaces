package optionPane;             // class is part of the option pane package

import java.awt.*;
import javax.swing.event.*;
import javax.swing.colorchooser.*;
import javax.swing.*;


/*   Jeremy Becnel              Applet Contest                  12/11/98

     This class defines a color panel to select a specific color.
*/


public class ColorPanel extends Panel implements ChangeListener {

//------------------------FIELDS-----------------------                                                                       

  private Color color;                // color choosen
  private ColorSelectionModel colorSelector;

//---------------------CONSTRUCTORS---------------------

  public ColorPanel ()  {
    /*  This constructor creates a color panel in order to a color
        choice.

        Pre : none

        Post: the panel is created
    */


    JColorChooser colorChooser = new JColorChooser();
    
    AbstractColorChooserPanel[] colorPanels = colorChooser.getChooserPanels();
                                        
    colorSelector = colorPanels[0].getColorSelectionModel();
    colorSelector.addChangeListener(this);
    this.add(colorPanels[0]);
  }


//-----------------------------METHODS---------------------------

//============================GETCOLOR===========================

  public Color getColor()  {
    /*  This method returns the color field of the class.

        Pre : none

        Post: the color field is returned
    */

    return color;
  }
              

//======================STATECHANGED=========================
    
  public void stateChanged(ChangeEvent e)  {
    /*  This method is notified when one of the colored blocks is
        clicked upon.  It finds the choice of color.

        Pre : given the change event which occurs

        Post: the color clicked on is found 
              
    */

    color = colorSelector.getSelectedColor();
  }                                

  
} // end class ColorPanel

