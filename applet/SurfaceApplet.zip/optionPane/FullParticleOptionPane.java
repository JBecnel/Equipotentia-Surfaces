package optionPane;         // class is part of the option pane package

import java.awt.*;

import model.*;
import icon.*;


/*   Jeremy Becnel            Applet Contest            12/9/98

        This class defines a option pane for a particle
        in order to retrieve particle data.
*/


public class FullParticleOptionPane extends ParticleOptionPane  {


//-----------------------------CONSTRUCTOR------------------------------


  public FullParticleOptionPane()   {
    /*  This contructor creats a default option pane for a particle.
        It assumes a particleType of Positive.

        Pre : none

        Post: a option pane (for a positive particle) is created
    */

    super();
  }

  public FullParticleOptionPane(String type, Icons icons)   {
    /*  This method creates an option pane for a particle.

        Pre : given the type of particle and a hashtable of
              icons to choose from

        Post: the option pane is created
    */

    super(type, icons);   // call to particle option pane constructor
    
    // create the labels needed
    labels = new Label[4];
    labels[0] = new Label("Position X : ");
    labels[1] = new Label("Position Y : ");
    labels[2] = new Label("Radius : ");
    labels[3] = new Label("Charge : ");

    // create the text fields needed
    components = new Object[4];
    components[0] = new TextField("0");
    components[1] = new TextField("0");
    components[2] = new TextField("5");

    double charge = Math.pow(10, -10);
    if (type.startsWith("Negative"))
      components[3] = new ChargePanel(-charge);
    else
      components[3] = new ChargePanel(charge);      

    // set the objects for the option pane
    setObjects();
    setTitle("Configure Particle's Fields");
  }


//-----------------------------METHODS---------------------------------


//=============================GETDATA===================================

  public int getData(Particle particle)   {
    /*  This method defines a retrieves particle data from a option pane
        and sets the particles fields appropriately.

        Pre : given the particle the data is retrieved for

        Post: the option pane data is retrieved and the appropriate fields
              are set
    */


    // create the option pane 
    int option = super.getData();

    // retrieve the data
    double x = Double.valueOf(((TextField) objects[1]).getText()).doubleValue();
    double y = Double.valueOf(((TextField) objects[3]).getText()).doubleValue();
    double radius = Double.valueOf(((TextField) objects[5]).getText()).doubleValue();
    double charge = ((ChargePanel)components[3]).getCharge();  

    // set the fields of the particle
    particle.setPosition(x,y);
    particle.setRadius(radius);
    particle.setCharge(charge);

    // set the color with respect to the charge
    if (charge < 0)  {
      particle.setPrimaryColor(Particle.getNegativePrimaryColorDefault());
      particle.setSecondaryColor(Particle.getNegativeSecondaryColorDefault());
    }
    else {
      particle.setPrimaryColor(Particle.getPositivePrimaryColorDefault());
      particle.setSecondaryColor(Particle.getPositiveSecondaryColorDefault());
    }

    return option;
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "Full Particle Option Pane : \n";
                
    s += super.toString();

    return s;
  }


}   // end class FullParticleOptionPane
