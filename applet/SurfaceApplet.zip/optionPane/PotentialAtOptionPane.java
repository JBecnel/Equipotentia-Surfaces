package optionPane;         // class is part of the option pane package

import java.awt.*;

import model.*;
import icon.*;
import point.*;


/*   Jeremy Becnel            Applet Contest            12/17/98

        This class defines a option pane for a computing the potential
        at a point.
*/


public class PotentialAtOptionPane extends PointOptionPane  {


//-----------------------------CONSTRUCTOR------------------------------

  public PotentialAtOptionPane()   {
    /*  This method creates an option pane for a computing Potential.

        Pre : none

        Post: the option pane is created
    */

    super();
  }


  public PotentialAtOptionPane(Icons icons)   {
    /*  This method creates an option pane for a computing Potential at
        a point.

        Pre : given a hashtable of icons to choose from

        Post: the option pane is created
    */

    this();

    ProjectIcon icon = icons.getProjectIcon("Potential");
    setIcon(new ToolbarIcon(icon));
    setTitle("Enter Point at Which to Find Potential");
  }


}   // end class PotentialAtOptionPane
