package optionPane;         // class is part of the option pane package

import java.awt.*;

import model.*;
import icon.*;


/*   Jeremy Becnel            Applet Contest            12/9/98

        This class defines a option pane for a particle
        in order to retrieve particle data.
*/


public class ParticleOptionPane extends OptionPane  {


//-------------------------------FIELDS---------------------------------

  protected String particleType;   //  type of the particle
  protected Particle particle;     //  particle being edited

  protected Label[] labels;      // labels used in option pane
  protected Object[] components; // components used in option pane

//-----------------------------CONSTRUCTOR------------------------------


  public ParticleOptionPane()   {
    /*  This contructor creats a default option pane for a particle.
        It assumes a particleType of Positive.

        Pre : none

        Post: a option pane (for a positive particle) is created
    */

    super();
    setTitle("Configure Particle");
  }

  public ParticleOptionPane(String type, Icons icons)   {
    /*  This method creates an option pane for a particle.

        Pre : none

        Post: the option pane is created
    */

    this();

    // record the type of particle
    particleType = type;

    // set the type of icon for option pane
    setIcon(icons);
  }


  public ParticleOptionPane(Particle particle)   {
    /*  This method creates an option pane for a particle.

        Pre : given the particle to open the option pane for

        Post: the option pane is created
    */

    this();

    this.particle = particle;

    // set the type of icon for option pane
    setIcon();
  }

//-----------------------------METHODS---------------------------------


//===========================SETOBJECTS===========================

  protected void setObjects() {
    /*  This method sets the object field of the option pane.

        Pre : given the labels and componenents to use
              the number of labels and components must be the same

        Post: the objects to be included in the pane are set
    */

    objects = new Object[labels.length + components.length];

    for (int i = 0; i < labels.length; i++)  {
      objects[2*i] = labels[i];
      objects[2*i + 1] = components[i];
    }
  }


//=============================SETICON============================

  private void setIcon(Icons icons) {
    /*  This method sets the icon field of the option pane. It
        determines which icon to use by looking at the type of
        particle.

        Pre : given a hashtable of icons to find the icon from

        Post: the appropriate icon is set
    */

    ProjectIcon icon;
    if (particleType.startsWith("Positive"))
      icon = (ProjectIcon) icons.getProjectIcon("PositiveParticle");
    else
      icon = (ProjectIcon) icons.getProjectIcon("NegativeParticle");
    setIcon(new ToolbarIcon(icon));
  }


//=============================SETICON============================

  private void setIcon() {
    /*  This method sets the icon field of the option pane. The
        particle given is used as the icon.

        Pre : given the particle for to use as the icon

        Post: the appropriate icon is set
    */

    ParticleIcon icon = new ParticleIcon(particle);    
    setIcon(new ToolbarIcon(icon));
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "Particle Option Pane : \n";
                
    s += super.toString();

    return s;
  }


}   // end class ParticleOptionPane
