package optionPane;         // class is part of the option pane package

import java.awt.*;

import model.*;
import icon.*;


/*   Jeremy Becnel            Applet Contest            12/9/98

     This class defines a option pane for a particle
     in order to retrieve particle data.
*/


public class ParticlePositionOptionPane extends ParticleOptionPane  {


//-----------------------------CONSTRUCTOR------------------------------

  public ParticlePositionOptionPane()   {
    /*  This contructor creats a default option pane for a particle.
        It assumes a particleType of Positive.

        Pre : none

        Post: a option pane (for a positive particle) is created
    */

    super();
  }

  public ParticlePositionOptionPane(Particle particle)   {
    /*  This method creates an option pane for a particle.

        Pre : given the particle to open the option pane for

        Post: the option pane is created
    */
    
    super(particle);   // call to ParticleOptionPane constructor
    setTitle("Configure Particle's Position");
  }


//-----------------------------METHODS---------------------------------

                                
//==========================EDITPARTICLE=================================

  public void editParticle()   {
    /*  This method retrieves the particle position from an option pane
        and sets the particle's position appropriately.

        Pre : given the particle

        Post: the option pane data is retrieved and the appropriate fields
              are set
    */

    PointOptionPane optionPane = new PointOptionPane(particle.getPosition());
    optionPane.setIcon(this.getIcon());
    optionPane.editPoint();
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the
        position option pane.

        Pre : none

        Post: the string representation is returned             
    */
                
    String s = "Particle Position Option Pane : \n";
                
    s += super.toString();

    return s;
  }     

}   // end class ParticleOptionPane
