package optionPane;         // class is part of the option pane package
 
import java.awt.*;

import model.*;
import icon.*;
 
/*   Jeremy Becnel            Applet Contest            12/11/98

      This class defines a option pane for a Locus's color
      in order to change it if desired.
*/


public class LocusColorOptionPane extends OptionPane   {


//-------------------------------FIELDS---------------------------------

  private ColorPanel colorPanel;

//-----------------------------CONSTRUCTOR------------------------------

  public LocusColorOptionPane(Icons icons)  {
    /*  This method creates a option pane to select a color.

        Pre : none

        Post: the option pane is created
    */

    super();   // call to optionPane constructor

    // set the objects needed
    objects = new Object[2];
    objects[0] = new Label("Locus Color: ");
    colorPanel = new ColorPanel();
    objects[1] = colorPanel;

    options = new Object[1];
    options[0] = "Apply";    

    ProjectIcon icon = (ProjectIcon) icons.getProjectIcon("Locus");
    setIcon(new ToolbarIcon(icon));

    setTitle("Select Locus Color");
  }



//-----------------------------METHODS---------------------------------

//============================EDITCOLOR===================================

  public void editColor()   {
    /*  This method defines a retrives locus data from a option pane
        and sets the Locus color field appropriately.

        Pre : none

        Post: the option pane data is retrieved and the appropriate fields
              are set
    */

    // create the option pane 
    int option = super.getData();

    Color choice = colorPanel.getColor();

    // set the color if not canceled
    if (option != OptionPane.CANCEL && choice != null)
      Locus.setColor(choice);
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "Locus Color Option Pane : \n";
                
    s += super.toString();

    return s;
  }               

}   // end class LocusColorOptionPane




