package optionPane;             // class is part of the option pane package

import java.awt.*;
import math.*;

/*   Jeremy Becnel              Applet Contest                  12/22/98

     This class defines a exponential panel in order to read
     a number in scientific notation.
*/


public class ExponentialPanel extends Panel   {

//------------------------FIELDS-----------------------

  private TextField exponent;           // text field for the exponent
  private TextField significand;        // text field for the signicand


//---------------------CONSTRUCTORS---------------------

  public ExponentialPanel ()  {
    /*  This constructor creates a exponential panel in order to a read in
        a number to the power of ten.

        Pre : none

        Post: the panel is created
    */

    this(1);
  }

  
  public ExponentialPanel (double currentNumber)  {
    /*  This constructor creates a exponential panel in order to a read in
        a number to the power of ten (i.e. in scienticfic notation).

        Pre : given the current number to be displayed in the textfields.

        Post: the panel is created
    */

    super();    // call to panel constructor

    RDouble number = new RDouble(currentNumber);
    int exp = MathOps.scientificNotationFormat(number);
                     
    // create the text fields and Labels for the ExponentialPanel
    Label sigLabel = new Label("Sig:");
    significand = new TextField(number.toString(), 12);
    Label expLabel = new Label("Exp: 10^");
    exponent = new TextField(String.valueOf(exp), 6);

    // add the component to the panel
    this.add(sigLabel);
    this.add(significand);
    this.add(expLabel);
    this.add(exponent);
  }



//-----------------------------METHODS---------------------------

              
//===========================GETSIGNIFICAND======================

  public double getSignificand()  {
    /*  This method returns the double value retrieved from the
        significand text field.

        Pre : none

        Post: the significand value is returned
    */
              
    String sig = significand.getText();

    return Double.valueOf(sig).doubleValue();
  }


//===========================GETEXPONENT======================

  public int getExponent()  {
    /*  This method returns the double value retrieved from the
        exponent text field.

        Pre : none

        Post: the exponent value is returned
    */
              
    String exp = exponent.getText();

    return Integer.valueOf(exp).intValue();
  }

//============================GETVALUE=========================

  public double getValue()  {
    /*  This method returns the actual double value of the significand
        multiplied by 10 to the power of the exponent.

        Pre : none

        Post: the actual double value of the significand multiplied
              by 10 to the power of the exponent is returned
    */

    return getSignificand() * Math.pow(10, getExponent());
  }


//==============================TOSTRING===============================

  public String toString()  {
    /*  This method returns the string representation of the Exponential
        Panel.

        Pre : none

        Post: the ExponentialPanel's string representation is returned
    */

    String s = "ExponentialPanel: \n";

    s += "  Significand: " + getSignificand();
    s += "  Exponent:    " + getExponent();
    s += "  Value:       " + getValue();

    return s;
  }

} // end class ExponentialPanel

