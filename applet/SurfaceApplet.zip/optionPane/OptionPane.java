package optionPane;         // class is part of the optionPane package

import javax.swing.*;
import java.awt.*;


/*   Jeremy Becnel            Applet Contest                 12/9/98

     This class defines an optionPane to get retrieve data.
*/


public class OptionPane   {


//-----------------------------FIELDS------------------------------------

  protected Object[] objects;             // objects put in the dialog
  protected Object[] options = {"OK"};    // given standard ok option

  protected Icon icon;                  // option pane icon
  protected String title;               // title of optionPane

  private static Frame frame;           // frame for the option panes

//----------------------------CONSTANTS--------------------------------

  //  constants for option choice
  public static final int OK = 0;
  public static final int APPLY = 1;
  public static final int YES = 0;
  public static final int NO = 1;
  public static final int CANCEL = -1;


//---------------------------CONSTRUCTORS---------------------------------

  public OptionPane()  {
    /* This method creates an option pane to retrieve data.
       

       Pre : none

       Post: the optionPane is created
    */

    this("Project Editor",null);
  }


  public OptionPane(Icon icon)  {
    /* This method creates an option pane to retrieve data.

       Pre : given the icon to use in the option pane

       Post: the optionPane is created
    */

    this ("Project Editor", icon);
  }


  public OptionPane(String title)  {
    /* This method creates an option pane to retrieve data.

       Pre : given the title of the option Pane

       Post: the optionPane is created
    */

    this (title, null);
  }

  public OptionPane(String title, Icon icon)  {
    /* This method creates an option pane to retrieve data.

       Pre : given the title of the option Pane
             given the icon to use in the option pane

       Post: the optionPane is created
    */

    this.title = title;
    this.icon = icon;
  }


//-----------------------------METHODS----------------------------------
                                 

//============================GETICON================================

  public Icon getIcon()  {
    /* This method returns the icon field of an option pane.

       Pre : given an implicit option pane

       Post: the icon of the pane is returned
    */

    return icon;
  }


//============================SETICON================================

  public void setIcon(Icon icon)  {
    /* This method sets the icon field of a option pane.

       Pre : given an implicit option pane

       Post: the icon of the pane is updated
    */

    this.icon = icon;
  }


//============================GETFRAME================================

  public static Frame getFrame()  {
    /* This method returns the frame field of an option pane.

       Pre : given an implicit option pane

       Post: the frame of the pane is returned
    */

    return frame;
  }


//============================SETFRAME================================

  public static void setFrame(Frame frame)  {
    /* This method sets the frame field of a option pane.

       Pre : given an implicit option pane

       Post: the frame of the pane is updated
    */

    OptionPane.frame = frame;
  }


//============================GETTITLE================================

  public String getTitle()  {
    /* This method returns the title field of an option pane.

       Pre : given an implicit option pane

       Post: the title of the pane is returned
    */

    return title;
  }


//============================SETTITLE================================

  public void setTitle(String title)  {
    /* This method sets the title field of a option pane.

       Pre : given an implicit option pane

       Post: the title of the pane is updated
    */

    this.title = title;
  }


//============================GETDATA==================================

  public int getData()  {
    /*  This method creates the editable box to enter and/or read 
        information.

        Pre : none

        Post: the box is created and the user's choice is returned
    */

    int option = JOptionPane.showOptionDialog(frame, objects,  title,    
                 JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                 icon, options, options[0]);

    return option;
  }


//==============================TOSTRING==============================

  public String toString()  {
    /*  This method returns the string representation of a option pane.

        Pre : none

        Post: the string is returned
    */

    String s = "Option Pane : ";

    s += "\n  Title "  + title;
    s += "\n  Objects " + objects;
    s += "\n  Options " + options;

    return s;
  }

}  // end class OptionPane
   
