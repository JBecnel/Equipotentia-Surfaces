package optionPane;         // class is part of the option pane package

import java.awt.*;

import model.*;
import icon.*;


/*   Jeremy Becnel            Applet Contest            12/9/98

        This class defines a option pane for a particle
        in order to retrieve particle data.
*/


public class StandardParticleOptionPane extends ParticleOptionPane  {


//-----------------------------CONSTRUCTOR------------------------------


  public StandardParticleOptionPane()   {
    /*  This contructor creats a default option pane for a particle.

        Pre : none

        Post: a option pane is created
    */

    super();
  }

  public StandardParticleOptionPane(String type, Icons icons)   {
    /*  This method creates an option pane for a particle.

        Pre : given the type of particle and a hashtable of icons
              to choose from

        Post: the option pane is created
    */


    super(type, icons);   // call to ParticleOptionPane constructor

    // set the labels and text fields needed
    labels = new Label[2];
    labels[0] = new Label("Radius : ");
    labels[1] = new Label("Charge : ");

    components = new Object[2];
    components[0] = new TextField("5");
    if (type.startsWith("Negative"))
      components[1] = new ChargePanel(-Math.pow(10,-10));
    else
      components[1] = new ChargePanel(Math.pow(10,-10));      

    setObjects();

    setTitle("Configure Particle's Fields");
  }


//-----------------------------METHODS---------------------------------


//=============================GETDATA===================================

  public int getData(Particle particle)   {
    /*  This method retrieves particle data from a option pane
        and sets the particles fields appropriately.

        Pre : given the particle to edit

        Post: the option pane data is retrieved and the appropriate fields
              are set
    */                                  

    // create the option pane
    int option = super.getData();

    // retrieve the data
    double radius = Double.valueOf(((TextField) objects[1]).getText()).doubleValue();
    double charge = ((ChargePanel) objects[3]).getCharge();
                                        
    // set the fields of the particle                           
    particle.setRadius(radius);
    particle.setCharge(charge);

    // set the color with respect to the charge
    if (charge < 0)  {
      particle.setPrimaryColor(Particle.getNegativePrimaryColorDefault());
      particle.setSecondaryColor(Particle.getNegativeSecondaryColorDefault());
    }
    else {
      particle.setPrimaryColor(Particle.getPositivePrimaryColorDefault());
      particle.setSecondaryColor(Particle.getPositiveSecondaryColorDefault());
    }

    return option;
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "Standard Particle Option Pane : \n";
                
    s += super.toString();

    return s;
  }


}   // end class StandardParticleOptionPane
