package optionPane;         // class is part of the option pane package

import javax.swing.*;
import java.awt.*;


/*   Jeremy Becnel            Applet Contest            12/28/98

     This class defines a option pane to notify the user that
     no point was found on this window.
*/


public class NoPointOptionPane extends OptionPane  {


//-----------------------------CONSTRUCTOR------------------------------


  public NoPointOptionPane()   {
    /*  This contructor creats a option pane for a user notification.

        Pre : none

        Post: the option pane is created
    */
    
    objects = new Object[3];
    objects[0] = new Label("No point with given potential "  +
                            "was found in this window.");
    objects[1] = new Label();
    objects[2] = new Label("         Would you like to try another search?");

    setTitle("No Point Found");
  }


//-----------------------------METHODS---------------------------------


//=============================GETDATA==================================

  public int getData()   {
    /*  This method defines a retrieves particle data from a option pane
        and sets the particles fields appropriately.

        Pre : none

        Post: the option pane choice is retrieved and returned
    */

    // create the option pane and return the option choosen
    int option = JOptionPane.showConfirmDialog(OptionPane.getFrame(), objects,
                      "No Point Found", JOptionPane.YES_NO_OPTION);

    return option;
  }


//=============================TOSTRING===========================

  public String toString()  {                           
    /*  This method returns the string representation of the no point message
        option pane.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "No Point OptionPane : \n";
                
    s += super.toString();

    return s;
  }                    

}   // end class NoPointOptionPane
