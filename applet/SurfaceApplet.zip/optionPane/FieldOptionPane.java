package optionPane;         // class is part of the option pane package

import java.awt.*;

import model.*;
import point.*;


/*   Jeremy Becnel            Applet Contest            12/21/98

        This class defines a option pane for a finding the
        two values representing the width or height of a field.
*/


public class FieldOptionPane extends PointOptionPane  {


//--------------------------CONSTRUCTORS---------------------------


  public FieldOptionPane()   {
    /*  This method creates an option pane for a field.

        Pre : none

        Post: the option pane is created
    */

    this(0,0);
  }


  public FieldOptionPane(double min, double max)   {
    /*  This method creates an option pane for a field.

        Pre : none

        Post: the option pane is created
    */

    super(new Point2D(min, max));

    objects[0] = new Label("Min : ");
    objects[2] = new Label("Max : ");

    setTitle("Enter New Field Values");
  }


//-----------------------------METHODS---------------------------------


//============================EDITFIELD===================================

  public int editField()   {
    /*  This method defines a retrieves field data from a option pane.

        Pre : none

        Post: the option pane data is retrieved and the user choice
              is returned
    */                             

    // create the option pane 
    int option = super.editPoint();

    return option;
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "Point Option Pane : \n";
                
    s += super.toString();

    return s;
  }


}   // end class PointOptionPane
