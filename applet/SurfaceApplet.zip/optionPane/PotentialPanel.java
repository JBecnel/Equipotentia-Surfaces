package optionPane;             // class is part of the option pane package

import java.awt.*;

/*   Jeremy Becnel              Applet Contest                  12/22/98

     This class defines a potential panel in order to retrieve the
     potential of a particle.     
*/


public class PotentialPanel extends ExponentialPanel   {


//---------------------CONSTRUCTORS---------------------

  public PotentialPanel ()  {
    /*  This constructor creates a Potential panel in order to a read in
        a particles potential.

        Pre : none

        Post: the panel is created
    */

    this(1);
  }

  
  public PotentialPanel (double currentPotential)  {
    /*  This constructor creates a Potential panel in order to a read in
        a potential.

        Pre : given the current potential to be displayed as the initial
              value

        Post: the panel is created
    */

    super(currentPotential);    // call to exponential panel constructor
  }

//-----------------------------METHODS-----------------------------


//===========================GETPOTENTIAL=========================

  public double getPotential()  {
    /*  This method returns the potential entered by the user.

        Pre : none

        Post: the potential is returned
    */

    return super.getValue();
  }


//==============================TOSTRING========================

  public String toString()  {
    /*  This method returns the string representation of the PotentialPanel.

        Pre : none

        Post: the string representation of the class is returned
    */

    String s = "PotentialPanel: \n";

    s += "  Potential: " + getPotential();

    return s;
  }       

}       // end class PotentialPanel
