package optionPane;         // class is part of the option pane package

import java.awt.*;

import model.*;


/*   Jeremy Becnel            Applet Contest            12/22/98

     This class defines a option pane for the axis of the electric field.
*/


public class AxisOptionPane extends OptionPane  {


//-----------------------------CONSTRUCTOR------------------------------


  public AxisOptionPane()   {
    /*  This contructor creats a default option pane for a axis.

        Pre : none

        Post: a option pane is created
    */

    // set the objects needed
    objects = new Object[3];

    objects[0] = new AxisPanel();
    objects[1] = new Label("Axis Color: ");
    objects[2] = new ColorPanel();

    setTitle("Configure Axis");
  }


//-----------------------------METHODS---------------------------------
                                                  
//============================EDITAXIS=================================

  public void editAxis(ElectricField electricField)   {
    /*  This method retrieves the visibility choice
        for the axis and the axis's color of choice from the user
        and sets the values appropriately.

        Pre : given the axis owner (the electricField)

        Post: the option pane data is retrieved and the corresponding
              fields are set
    */

    // create the option pane 
    int option = super.getData();
    
    if (option == OK)  {
      // set the axis's visiblity
      boolean state = ((AxisPanel) objects[0]).isVisible();
      electricField.setAxisVisible(state);

      // set the axis's color
      Color axisColor = ((ColorPanel) objects[2]).getColor();
      if (axisColor != null)
        electricField.setAxisColor(axisColor);
    }
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the Axis option pane.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = " Axis Option Pane : \n";
                
    s += super.toString();

    return s;
  }             

}   // end class AxisOptionPane


