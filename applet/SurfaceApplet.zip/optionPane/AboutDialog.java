package optionPane;                  // class is part of the help package

import java.awt.*;


/*    Jeremy Becnel             Applet Contest                  12/22/98

   This class defines the about dialog for the equiponetial surface
   project.
*/


public class AboutDialog extends OptionPane  {


//----------------------------CONSTRUCTORS------------------------------

  public AboutDialog()  {
    /*  This constructor creates a about dialog.

        Pre : none

        Post: the about dialog is created
    */

    super();

    // set the message to display
    Label projectName = new Label("Equipotential Surface Applet", Label.CENTER);
    projectName.setFont(new Font("Project Font", Font.BOLD, 15));
    Label by = new Label ("by", Label.CENTER);
    by.setFont(new Font("By Font", Font.PLAIN, 10));
    Label name = new Label("Jeremy Becnel", Label.CENTER);
    name.setFont(new Font("Name Font",Font.ITALIC, 12));

    objects = new Object[3];
    objects[0] = projectName;
    objects[1] = by;
    objects[2] = name;

    setTitle("About");
  }


//--------------------------------METHODS--------------------------------

//===============================SHOW===============================

  public void show()  {
    /*  This method shows the about dialog.

        Pre : none

        Post: the about dialog is displayed
    */

    int option = super.getData();
  }


//===============================TOSTRING===============================

  public String toString()  {
    /*  This method returns the string representation of the AboutDialog.

        Pre : none

        Post: the about dialog is string representation is returned
    */

    String s = "About Dialog";

    return s + super.toString();
  }

}  // end class About Dialog
