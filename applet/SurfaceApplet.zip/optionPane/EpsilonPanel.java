package optionPane;             // class is part of the option pane package

import java.awt.*;

/*   Jeremy Becnel              Applet Contest                  12/28/98

     This class defines a epsilon panel in order to retrieve the
     epsilon for the compute state.
*/


public class EpsilonPanel extends ExponentialPanel   {



//---------------------CONSTRUCTORS---------------------

  public EpsilonPanel ()  {
    /*  This constructor creates a Epsilon panel in order to a read in
        a epsilon value.

        Pre : none

        Post: the panel is created
    */

    this(1);
  }

  
  public EpsilonPanel (double currentEpsilon)  {
    /*  This constructor creates a Epsilon panel in order to a read in
        a particles epsilon.

        Pre : given the current epsilon to be displayed as the initial
              value

        Post: the panel is created
    */

    super(currentEpsilon);    // call to exponential panel constructor
  }



//-----------------------------METHODS---------------------------              


//============================GETEPSILON=========================

  public double getEpsilon()  {
    /*  This method returns the epsilon entered by the user.

        Pre : none

        Post: the epsilon is returned
    */

    return super.getValue();
  }


//==============================TOSTRING========================

  public String toString()  {
    /*  This method returns the string representation of the EpsilonPanel.

        Pre : none

        Post: the string representation of the class is returned
    */

    String s = "EpsilonPanel: \n";

    s += "  Epsilon: " + getEpsilon();

    return s;
  }

} // end class EpsilonPanel

