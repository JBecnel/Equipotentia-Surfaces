package optionPane;             // class is part of the option pane package

import java.awt.*;

/*   Jeremy Becnel              Applet Contest                  12/22/98

     This class defines a axis panel to select a specific color.
*/


public class AxisPanel extends Panel   {

//------------------------FIELDS-----------------------

  private Choice state;         // choice for state of the axis

//---------------------CONSTRUCTORS---------------------

  
  public AxisPanel ()  {
    /*  This constructor creates a Axis panel in order to a read in
        a particles Axis.

        Pre : given the current Axis to be displayed as the initial
              value

        Post: the panel is created
    */

    super();    // call to panel constructor

    this.add(new Label("Axis: "));
    state = new Choice();
    state.add("On");
    state.add("Off");
    this.add(state);
  }



//-----------------------------METHODS---------------------------

//============================ISVISIBLE==========================

  public boolean isVisible()  {
    /*  This method returns a boolean to determine if the user requested
        the axis to be visible.

        Pre : none

        Post: the boolean for axis visiblity is returned
    */

    String choice = state.getSelectedItem();

    return choice.equals("On");
  }


//============================TOSTRING============================

  public String toString()  {
    /*  This method returns the string representation of the Axis Panel.

        Pre : none

        Post: the string representation of the Axis Panel is returned
    */

    String s = "Axis Panel \n";

    s += "  Choice " + state.toString();
    s += super.toString();

    return s;
  }

} // end class AxisPanel

