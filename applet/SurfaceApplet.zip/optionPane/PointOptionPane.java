package optionPane;         // class is part of the option pane package

import java.awt.*;

import model.*;
import icon.*;
import point.*;


/*   Jeremy Becnel            Applet Contest            12/17/98

        This class defines a option pane for a point
        in order to retrieve the x and y values of a point.
*/


public class PointOptionPane extends OptionPane  {

//-------------------------------FIELDS--------------------------------

  private Point2D point;        // point being edited


//-----------------------------CONSTRUCTOR------------------------------

  public PointOptionPane()   {
    /*  This method creates an option pane for a point.

        Pre : none

        Post: the option pane is created
    */

    this (new Point2D());
  }

  public PointOptionPane(Point2D point)   {
    /*  This method creates an option pane for a point.

        Pre : given the point to edit

        Post: the option pane is created
    */

    super();
    this.point = point;
    objects = new Object[4];

    // set the objects needed
    objects[0] = new Label("X : ");
    objects[1] = new TextField(String.valueOf(point.getX()));
    objects[2] = new Label("Y : ");
    objects[3] = new TextField(String.valueOf(point.getY()));

    setTitle("Enter Point");
  }


//-----------------------------METHODS---------------------------------


//============================GETPOINT================================

  public Point2D getPoint()  {
    /*  This method returns the point field of the class.

        Pre : none

        Post: the point field is returned
    */

    return point;
  }


//============================SETPOINT================================

  public void setPoint(Point2D point)  {
    /*  This method sets the point field of the class.

        Pre : given the new point

        Post: the point field is returned
    */

    this.point = point;
  }


//============================EDITPOINT===================================

  public int editPoint()   {
    /*  This method retrieves point coordinates from a option pane
        and sets the fields appropriately.

        Pre : particle

        Post: the option pane data is retrieved and the appropriate fields
              are set
    */


    // create the option pane 
    int option = super.getData();

    // retrieve the data
    double x = Double.valueOf(((TextField) objects[1]).getText()).doubleValue();
    double y = Double.valueOf(((TextField) objects[3]).getText()).doubleValue();

    // set the fields of the point
    if (option != OptionPane.CANCEL)
      point.setLocation(x,y);

    return option;
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "Point Option Pane : \n";
                
    s += super.toString();

    return s;
  }


}   // end class PointOptionPane
