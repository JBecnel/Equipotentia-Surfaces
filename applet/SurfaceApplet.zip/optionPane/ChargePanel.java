package optionPane;             // class is part of the option pane package

import java.awt.*;

/*   Jeremy Becnel              Applet Contest                  12/23/98

     This class defines a charge panel in order to retrieve the
     charge of a particle.     
*/


public class ChargePanel extends ExponentialPanel   {



//---------------------CONSTRUCTORS---------------------

  public ChargePanel ()  {
    /*  This constructor creates a Charge panel in order to a read in
        a particles charge.

        Pre : none

        Post: the panel is created
    */

    this(0.0000000001);         // default charge
  }

  
  public ChargePanel (double currentCharge)  {
    /*  This constructor creates a Charge panel in order to a read in
        a particles charge.

        Pre : given the current charge to be displayed as the initial
              value

        Post: the panel is created
    */

    super(currentCharge);    // call to exponential panel constructor
  }



//-----------------------------METHODS---------------------------              


//============================GETCHARGE=========================

  public double getCharge()  {
    /*  This method returns the charge entered by the user.

        Pre : none

        Post: the charge is returned
    */

    return super.getValue();
  }


//==============================TOSTRING========================

  public String toString()  {
    /*  This method returns the string representatio of the ChargePanel.

        Pre : none

        Post: the string representation of the class is returned
    */

    String s = "ChargePanel: \n";

    s += "  Charge: " + getCharge();

    return s;
  }

} // end class ChargePanel

