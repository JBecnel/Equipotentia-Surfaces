�7package optionPane;         // class is part of the option pane package
 
import java.awt.*;

import model.*;
import icon.*;
 
/*   Jeremy Becnel            Applet Contest            12/19/98

      This class defines a option pane for a Particle's color
      in order to changer it if desired.
*/


public class ParticleColorOptionPane extends ParticleOptionPane   {
                                                           

//-------------------------------FIELDS---------------------------------

  // the colors chosen
  private Color primary;
  private Color secondary;

  // the panels with the colors
  private ColorPanel primaryPanel;
  private ColorPanel secondaryPanel;


//-----------------------------CONSTRUCTOR------------------------------

  public ParticleColorOptionPane()  {
    /*  This method creates a option pane to select a color.

        Pre : none

        Post: the option pane is created

    */

    super();   // call to optionPane constructor
  }

  public ParticleColorOptionPane(String type, Icons icons)   {
    /*  This method creates an option pane for a colors.

        Pre : given the label for the color panel

        Post: the option pane is created
    */
    
    super(type, icons);

    initializeColors(type);         // initialize the color fields

    primaryPanel = new ColorPanel();
    secondaryPanel = new ColorPanel();

    // set the objects needed
    components = new Object[2];
    components[0] = primaryPanel;
    components[1] = secondaryPanel;

    labels = new Label[2];
    labels[0] = new Label("Primary Color:");
    labels[1] = new Label("Secondary Color:");

    // set the user options
    options = new Object[2];
    options[0] = "OK";
    options[1] = "Apply";

    setObjects();
    setTitle("Change Particle's Colors");
  }


  public ParticleColorOptionPane(Particle particle)   {
    /*  This method creates an option pane for a colors.

        Pre : given the particle for the color panel

        Post: the option pane is created
    */
    
    super(particle);

    initializeColors(particle);         // initialize the color fields

    primaryPanel = new ColorPanel();
    secondaryPanel = new ColorPanel();

    // set the objects needed
    components = new Object[2];
    components[0] = primaryPanel;
    components[1] = secondaryPanel;

    labels = new Label[2];
    labels[0] = new Label("Primary Color:");
    labels[1] = new Label("Secondary Color:");

    // set the user options
    options = new Object[1];
    options[0] = "OK";

    setObjects();
    setTitle("Change Particle's Colors");
  }


//-----------------------------METHODS---------------------------------


//========================INITIALIZECOLORS==========================

  private void initializeColors(String particleType)  {
    /*  This method initializes the color fields of the class.

        Pre : given the type of the particle

        Post: the color fields are initialized
    */

    if (particleType.startsWith("Negative"))  {
      primary = Particle.getNegativePrimaryColorDefault();
      secondary = Particle.getNegativeSecondaryColorDefault();
    }
    else  {
      primary = Particle.getPositivePrimaryColorDefault();
      secondary = Particle.getPositiveSecondaryColorDefault();
    }
  }


  private void initializeColors(Particle particle)  {
    /*  This method initializes the color fields of the class.

        Pre : given the particle

        Post: the color fields are initialized
    */

    primary = particle.getPrimaryColor();
    secondary = particle.getSecondaryColor();
  }

//===========================GETPRIMARY=============================

  public Color getPrimary()  {
    /*  This method returns the primary color selected.

        Pre : none

        Post: the primary color is returned
    */

    return primary;
  }
                                
//===========================SETPRIMARY=============================

  public void setPrimary(Color primary)  {
    /*  This method sets the primary color selected.

        Pre : given the new primary color

        Post: the primary color is set
    */

    if (primary != null) 
      this.primary = primary;
  }


//===========================GETSECONDARY=============================

  public Color getSecondary()  {
    /*  This method returns the secondary color selected.

        Pre : none

        Post: the secondary color is returned
    */

    return secondary;
  }


//===========================SETSECONDARY=============================

  public void setSecondary(Color secondary)  {
    /*  This method sets the secondary color selected.

        Pre : given the new secondary color

        Post: the secondary color is set
    */

    if (secondary != null) 
      this.secondary = secondary;
  }


//========================CHANGEDEFAULTS========================

  private void changeDefaults()  {
    /*  This method changes the default color for particles.

        Pre : none

        Post: the default colors are changed
    */

    if (particleType.startsWith("Negative")) {
      Particle.setNegativePrimaryColorDefault(primary);
      Particle.setNegativeSecondaryColorDefault(secondary);
      }
    else  {
      Particle.setPositivePrimaryColorDefault(primary);
      Particle.setPositiveSecondaryColorDefault(secondary);
    }
  }


//============================APPLY=============================

  private void apply(NParticle nParticle)  {
    /*  This method applies the color change to all particles.

        Pre : none

        Post: the color change is applied to all particles
    */

     if (particleType.startsWith("Negative"))
        nParticle.applyNegativeParticleColors(primary, secondary);
     else
        nParticle.applyPositiveParticleColors(primary, secondary);
  }


//=============================GETDATA===================================

  public void getData(NParticle nParticle)   {
    /*  This method retrieves particle data from a option pane
        and sets the particles fields appropriately.

        Pre : given the particle

        Post: the option pane data is retrieved and the appropriate fields
              are set
    */

    // create the option pane 
    int option = super.getData();

    if (option != OptionPane.CANCEL) {
      setPrimary(primaryPanel.getColor());
      setSecondary(secondaryPanel.getColor());

      // change the color defaults
      changeDefaults();

      // if apply was chosen apply to all particles
      if (option == OptionPane.APPLY)
        apply(nParticle);      
    }           
  }


//==========================EDITPARTICLE===============================

  public void editParticle()   {
    /*  This method retrieves particle data from a option pane
        and sets the particles fields appropriately.

        Pre : none

        Post: the option pane data is retrieved and the appropriate fields
              are set
    */

    // create the option pane 
    int option = super.getData();

    if (option != OptionPane.CANCEL) {
      setPrimary(primaryPanel.getColor());
      setSecondary(secondaryPanel.getColor());

      particle.setPrimaryColor(getPrimary());
      particle.setSecondaryColor(getSecondary());
    }           
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "Color Option Pane : \n";

    s += " Primary Color " + primary;
    s += " Secondary Color " + secondary;
    s += super.toString();

    return s;
  }


}   // end class ParticleColorOptionPane


