package optionPane;         // class is part of the option pane package

import java.awt.*;
import model.*;

import icon.*;


/*   Jeremy Becnel            Applet Contest            12/9/98

     This class defines a option pane for a particle
     in order to retrieve particle charge data.
*/


public class ParticleChargeOptionPane extends ParticleOptionPane  {


//-----------------------------CONSTRUCTOR------------------------------


  public ParticleChargeOptionPane()   {
    /*  This contructor creats a default option pane for a particle's charge.

        Pre : none

        Post: a option pane is created
    */

    super();
  }

  public ParticleChargeOptionPane(Particle particle)   {
    /*  This method creates an option pane for a particle.

        Pre : given the particle to open the option pane for

        Post: the option pane is created
    */
    
    super(particle);   // call to ParticleOptionPane constructor

    // set the objects needed
    labels = new Label[1];
    labels[0] = new Label("Charge : ");

    components = new Object[1];                         
    components[0] =  new ChargePanel(particle.getCharge());

    setObjects();
    setTitle("Configure Particle's Charge");
  }


//-----------------------------METHODS---------------------------------
                                                  
//==========================EDITPARTICLE=================================

  public void editParticle()   {
    /*  This method retrieves particle charge data from a option pane
        and sets the particle's charge field appropriately.

        Pre : given the particle

        Post: the option pane data is retrieved and the appropriate fields
              are set
    */

    // create the option pane 
    int option = super.getData();

    // retrieve the data
    double charge = ((ChargePanel)components[0]).getCharge();

    // set the charge field of the particle
    if (option != OptionPane.CANCEL) 
      particle.setCharge(charge);
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the
        Particle Charge option pane.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "Particle Charge Option Pane : \n";
                
    s += super.toString();

    return s;
  }


}   // end class ParticleChargeOptionPane


