package optionPane;         // class is part of the option pane package

import java.awt.*;

import point.Point2D;
import icon.*;


/*   Jeremy Becnel            Applet Contest            12/24/98

     This class defines a option pane for a retrieveing a potential
     for a point.
*/

public class PotentialOptionPane extends OptionPane  {


//-------------------------------FIELDS---------------------------------

  private double potential;      // potential entered by user
  private Point2D start;         // starting point to look for potential

//-----------------------------CONSTRUCTOR------------------------------


  public PotentialOptionPane(double potential, Point2D start)   {
    /*  This method creates an option pane fing a point with a given
        potential.

        Pre : given the initial value for the point field of the
              option pane for

        Post: the option pane is created
    */
    
    super();   // call to OptionPane constructor

    // initialize field
    this.potential = potential;
    this.start = start;

    // set the objects needed
    objects = new Object[6];
    objects[0] = new Label("Potential: ");
    objects[1] = new PotentialPanel(potential);
    objects[2] = new Label("Start X: ");
    objects[3] = new TextField(String.valueOf(start.getX()));
    objects[4] = new Label("Start Y: ");
    objects[5] = new TextField(String.valueOf(start.getY()));

    setTitle("Enter Potential To Find");
  }


  public PotentialOptionPane(Icons icons, double potential, Point2D start)   {
    /*  This method creates an option pane for a retrieveing the potential.

        Pre : given a icons hashtable to choose an icon from
              given the starting or default potential
              and given the point to start the search at

        Post: the option pane is created
    */

    this(potential,start);

    // set the icon
    ProjectIcon icon = icons.getProjectIcon("Point");
    setIcon(new ToolbarIcon(icon));
  }


//-----------------------------METHODS---------------------------


//=============================GETDATA================================

  public int getData()   {
    /*  This method retrieves potenial data from a option pane.

        Pre : none

        Post: the option pane data is retrieved 
    */

    // create the option pane 
    int option = super.getData();

    // retrieve the data
    potential = ((PotentialPanel)objects[1]).getPotential();
    Double x = Double.valueOf(((TextField)objects[3]).getText());
    Double y = Double.valueOf(((TextField)objects[5]).getText());

    start = new Point2D(x.doubleValue(), y.doubleValue());
    
    return option;
  }


//===========================GETPOTENTIAL===========================

  public double getPotential() {
    /*  This method returns the potential field. (representing the
        potential entered by the user.

        Pre : none

        Post: the potential is returned
    */

    return potential;
  }


//===========================GETSTARTINGPOINT===========================

  public Point2D getStartingPoint() {
    /*  This method returns the start field. (representing the
        starting point to search for the potential.)

        Pre : none

        Post: the starting point is returned
    */

    return start;
  }


//=============================TOSTRING===========================

  public String toString()  {                                   
    /*  This method returns the string representation of the
        Potential option pane.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = " Potential Option Pane : \n";
    s +=  "  potential: " + potential;
    s +=  "  start:     " + start;
    s += super.toString();

    return s;
  }


}   // end class PotentailOptionPane


