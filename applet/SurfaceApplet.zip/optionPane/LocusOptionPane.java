package optionPane;         // class is part of the option pane package

import java.awt.*;

import icon.*;
import point.*;


/*   Jeremy Becnel            Applet Contest            12/22/98

     This class defines a option pane for a locus point
     in order to retrieve the x and y values of a point.
*/


public class LocusOptionPane extends PointOptionPane  {



//-----------------------------CONSTRUCTOR------------------------------

  public LocusOptionPane()   {
    /*  This method creates an option pane for a Locus.

        Pre : none

        Post: the option pane is created
    */

    super (new Point2D());
  }

  public LocusOptionPane(Point2D point)   {
    /*  This method creates an option pane for a Locus.

        Pre : given the point to edit

        Post: the option pane is created
    */

    super(point);
  }

  public LocusOptionPane(Point2D point, Icons icons)   {
    /*  This method creates an option pane for a Locus.

        Pre : given the point to edit and the icons to choose from

        Post: the option pane is created
    */

    super(point);

    ProjectIcon icon = icons.getProjectIcon("Locus");
    setIcon(new ToolbarIcon(icon));

    setTitle("Enter Locus's Initial Point");
  }


//-----------------------------METHODS---------------------------------
                                                  

//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "Locus Option Pane : \n";
                
    s += super.toString();

    return s;
  }

}   // end class LocusOptionPane
