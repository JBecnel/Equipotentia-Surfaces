package optionPane;         // class is part of the option pane package

import java.awt.*;

import model.*;
import icon.*;


/*   Jeremy Becnel            Applet Contest            12/9/98

     This class defines a option pane for a particle
     in order to retrieve the radius for a particle.
*/


public class ParticleRadiusOptionPane extends ParticleOptionPane  {


//-----------------------------CONSTRUCTOR------------------------------
      
  public ParticleRadiusOptionPane()   {
    /*  This contructor creats a default option pane for a particle's radius.

        Pre : none

        Post: a option pane is created
    */

    super();
  }

  public ParticleRadiusOptionPane(Particle particle)   {
    /*  This method creates an option pane for a particle.

        Pre : given the particle to open the option pane for

        Post: the option pane is created
    */
    
    super(particle);   // call to ParticleOptionPane constructor

    // set the objects needed
    labels = new Label[1];
    labels[0] = new Label("Radius : ");

    components = new Object[1];
    components[0] = new TextField(String.valueOf(particle.getRadius()));

    setObjects();
    setTitle("Configure Particle's Radius");
  }


//-----------------------------METHODS---------------------------------

                                
//==========================EDITPARTICLE=================================

  public void editParticle()   {
    /*  This method  retrieves particle radius data from a option pane
        and sets the particles fields appropriately.

        Pre : given the particle

        Post: the option pane data is retrieved and the appropriate fields
              are set
    */

    // create the option pane 
    int option = super.getData();

    // retrieve the data
    double radius = Double.valueOf(((TextField) objects[1]).getText()).doubleValue();

    // set the fields of the particle
    if (option != OptionPane.CANCEL)
      particle.setRadius(radius);
  }


//=============================TOSTRING===========================

  public String toString()  {                                   
    /*  This method returns the string representation of the
        radius option pane.

        Pre : none

        Post: the string representation is returned
    */
                
    String s = "Particle Radius Option Pane : \n";
                
    s += super.toString();

    return s;
  }     

}   // end class ParticleRadiusOptionPane
