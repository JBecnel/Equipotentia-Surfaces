package model;               // class is part of package model

import java.beans.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;

import point.Point2D;
import window.*;
import actions.*;


/*      Jeremy Becnel        Applet Contest                 12/9/98

   This is class Electric Field.  It handles the painting of the
   particles and loci on the canvas.  The class also listens to
   zoom in and zoom out keyevents. It keeps track of a x-y axis and
   resizes the shown coordinate system when needed.
*/


public class ElectricField extends Canvas implements KeyListener  {


//------------------------------FIELDS-------------------------------

  private NParticle nParticle;             // particles to be on canvas
  private NLocus  nLocus;                  // loci on the canvas
  private AffineTransform at;              // used to change coordinate system
  private WindowToCanvas windowToCanvas;   // responsible for resizing window
  private boolean axisVisible;             // determines if the axis is
                                           // placed on the canvas
  private Color axisColor;                 // color for the axis

  private static GeneralPath axis;
                    // a path representing the x and y axis

//-----------------------------CONSTANTS-------------------------------

  public static final int HEIGHT = 501;
                        // constant represent height of canvas

  public static final int WIDTH = 714;
                        // constant represent width of canvas
  

//----------------------------CONSTRUCTORS-----------------------------

  public ElectricField (Actions actions, WindowToCanvas windowToCanvas)    {
    /* This constructor creates a particle view canvas, intializes it's
       fields, creates the new coordinate system.

       Pre : given a hashtable of actions, and a  windowToCanvas object

       Post: the Electric Field is created
    */

    super();            // call to super canvas constructor
    setSize (WIDTH, HEIGHT);
    setBackground(Color.white);

    // set fields 
    this.nParticle = new NParticle();
    this.nLocus = new NLocus();
    axisVisible = true;
    axisColor = Color.black;
    setWindowToCanvas(windowToCanvas);   // sets coordinate systems
    axis = makeAxis();
                                                                  
    // retrieve the canvas action and canvas motion action
    // from the actions hashtable
    CanvasAction canvasAction = (CanvasAction) actions.get("Canvas");
    CanvasMotionAction canvasMotionAction =
                        (CanvasMotionAction) actions.get("CanvasMotion");

    // resgiter this canvas as a listener to the canvasAction,
    // the canvas motion action, and key actions (namely + and -)
    this.addMouseListener(canvasAction);
    this.addMouseMotionListener(canvasMotionAction);
    this.addKeyListener(this);
  }


//-----------------------------METHODS---------------------------------


//============================MAKEAXIS================================

  private GeneralPath makeAxis()  {
    /*  This method creates the x and y axis for the canvas.

        Pre : none

        Post: the x and y axis are created for the canvas
    */

    Point2D origin = windowToCanvas.convertToCanvas(0.0,0.0);
                // canvas point for origin

    Point2D end    =
       windowToCanvas.convertToCanvas(windowToCanvas.wx2, windowToCanvas.wy2);
                // canvas point for top right corner point

    // draw the axis
    GeneralPath path = new GeneralPath();
    path.moveTo((float)(origin.x - 50.0), (float)origin.y);
    path.lineTo((float)(end.x -200), (float)origin.y);
    path.moveTo((float)origin.x, (float)(origin.y + 50.0));
    path.lineTo((float)origin.x, (float)(end.y + 100));
                                        
    return path;
  }

//========================GETWINDOWTOCANVAS===========================

  public WindowToCanvas getWindowToCanvas()   {
    /*  This method returns the windowToCanvas field.

        Pre : none

        Post: the window to canvas field is returned
    */

    return windowToCanvas;
  }

//========================SETWINDOWTOCANVAS===========================

  public void setWindowToCanvas(WindowToCanvas windowToCanvas)  {
    /*  This method updates the windowToCanvas field.

        Pre : given the new windowToCanvas object

        Post: the windowToCanvas field is updated
    */

    // keep width and height in appropriate ratio
    final double ratio =   ((double)HEIGHT)/((double)WIDTH);
    final double fieldWidth = 250;
    final double fieldHeight =  ratio * fieldWidth;

    // set begining and end points for both coordinate systems
    windowToCanvas.setWindow(-50, -50, fieldWidth, fieldHeight);
    windowToCanvas.setCanvas(0, 0, WIDTH, HEIGHT);

    this.windowToCanvas = windowToCanvas;
  }
                                      

//=============================SETFIELDWIDTH========================

  public void setFieldWidth(double min, double max)  {
    /*  This method sets the width of the window.  It also
        changes the height in order for the window to stay
        in the same ratio as the canvas.

        Pre : given the new width coordinates

        Post: the width and height are changed accordinly
    */

    // find ratio of height and width
    final double ratio =   ((double)HEIGHT)/((double)WIDTH);
    final double fieldWidth = max - min;
    final double fieldHeight =  ratio * fieldWidth;

    WindowToCanvas old = (WindowToCanvas) windowToCanvas.clone();
    
    // set begining and end points for both coordinate systems
    windowToCanvas.setWindow(min, min, max, min + fieldHeight);
    axis = makeAxis();

    // move the loci in accordance with the new window to canvas
    nLocus.move(old, windowToCanvas);  // move the loci in accordance
  }

                                        
//=============================SETFIELDHEIGHT========================

  public void setFieldHeight(double min, double max)  {
    /*  This method sets the height of the window.  It also
        changes the width in order for the window to stay
        in the same ratio as the canvas.

        Pre : given the new height coordinates

        Post: the width and height are changed accordingly
    */

    // keep the widht and height in the same relative ratio
    final double ratio =   ((double)WIDTH)/((double)HEIGHT);
    final double fieldHeight = max - min;
    final double fieldWidth =  ratio * fieldHeight;

    WindowToCanvas old = (WindowToCanvas) windowToCanvas.clone();

    // set begining and end points for both coordinate systems
    windowToCanvas.setWindow(min, min, min + fieldWidth, max);
    axis = makeAxis();

    // move the loci in accordance with the new window to canvas
    nLocus.move(old, windowToCanvas);  // move the loci in accordance
  }


//=========================GETNPARTICLE===========================

  public NParticle getNParticle()    {
    /* This method returns the nparticle field.

       Pre : none

       Post: the field is returned
    */

    return nParticle;
  }

//=========================SETNPARTICLE===========================

  public void setNParticle(NParticle nParticle)    {
    /* This method sets the nparticle model field.

       Pre : given a nparticle to set the field to

       Post: the field is set
    */

    this.nParticle = nParticle;
  }
                                   

//==========================GETNLOCUS=============================

  public NLocus getNLocus()  {
    /*  This method returns a nlocus holding all the point loci
        on the canvas.

        Pre : none

        Post: the nLocus field is returned is returned
    */

    return nLocus;
  }

                        
//==========================SETNLOCUS=============================

  public void setNLocus(NLocus nLocus)  {
    /*  This method sets the nLocus field of the canvas.

        Pre : none

        Post: the nLocus field is set
    */

    this.nLocus = nLocus;
  }


//==========================GETAXISVISIBLE=============================

  public boolean getAxisVisible()  {
    /*  This method returns the boolean determining if the
        axis is shown or not.

        Pre : none

        Post: the axisVisible field is returned 
    */

    return axisVisible;
  }

                        
//==========================SETAXISVISIBLE=============================

  public void setAxisVisible(boolean axisVisible)  {
    /*  This method sets the axisVisible field of the canvas.

        Pre : none

        Post: the axisVisible field is set
    */

    this.axisVisible = axisVisible;
  }


//==========================GETAXISCOLOR=============================

  public Color getAxisColor()  {
    /*  This method returns a axis color field.

        Pre : none

        Post: the axisColor field is returned 
    */

    return axisColor;
  }

                        
//==========================SETAXISCOLOR=============================

  public void setAxisColor(Color axisColor)  {
    /*  This method sets the axisColor field of the canvas.

        Pre : none

        Post: the axisColor field is set
    */

    this.axisColor = axisColor;
  }
                     

//==============================PAINT===================================

  public void paint (Graphics g)    {
    /* This method paints the nParticle and nLocus on the canvas when called.

       Pre : given a graphics object

       Post: the nParticle and nLocus is painted
    */

    Graphics2D g2D = (Graphics2D) g;

    // draw the locus labels
    nLocus.drawLocusLabels(g, windowToCanvas);

    // draw the loci
    nLocus.drawNLocus(g2D);
         
    // draw the axis
    if (getAxisVisible()) {
      g2D.setColor(axisColor);
      g2D.draw(axis);
    }
     
    // transform the coordinate system
    g2D.transform(windowToCanvas.getTransform());

    // draw the particles
    nParticle.drawNParticle(g2D);
  }

//============================KEYPRESSED===============================

  public void keyPressed (KeyEvent e)   {
    /* This method handles key events and resizes the window accordingly.

       Pre : given an key event

       Post: the window is resized and the canvas is repainted
    */

    // ratio of height to width of canvas
    final double ratio =   ((double)HEIGHT)/((double)WIDTH);

    final int inc = 15;         // increment of window resizing
    final double heightInc = inc * ratio;

    int key = e.getKeyCode();   // integer representing key that is pressed

    WindowToCanvas old = (WindowToCanvas) windowToCanvas.clone();

    switch (key) {
      // if plus (+) zoom in
      case KeyEvent.VK_ADD :
        windowToCanvas.resizeWindow(inc, heightInc, -inc, -heightInc);
        break;
      // if subtract (-) zoom out
      case KeyEvent.VK_SUBTRACT :
        windowToCanvas.resizeWindow(-inc, -heightInc, inc, heightInc);
        break;
     }

     nLocus.move(old, windowToCanvas);  // move the loci in accordance

     axis = makeAxis();     // create the new axis

     repaint();  // repaint the paritcles and loci
  }


//=============================KEYTYPED=================================

  public void keyTyped (KeyEvent e)   {
    // unused therefore no implementation needed
  }


//============================KEYRELEASED===============================

  public void keyReleased (KeyEvent e)   {
    // unused therefore no implementation needed
  }

                               
//=============================TOSTRING=================================

  public String toString()    {
    /* This method returns a string representing a Electric Field.

       Pre : none

       Post: a string is representation of a Electric Field is retuerned
    */

    String s = "ElectricField : \n" +
               "NParticle: " + nParticle.toString() +
               "Loci: " + nLocus.toString();

    return s;
  }

}  // end class ElectricField

    


