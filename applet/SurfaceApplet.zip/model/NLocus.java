package model;               // class is part of the model package

import java.beans.*;
import java.io.*;
import java.awt.*;
import java.util.*;

import window.*;
import point.Point2D;


/*    Jeremy Becnel         Applet Contest             12/9/98

    This class defines a NLocus holding up to n loci using a vector (list)
    of loci.  
*/


public class NLocus implements Serializable      {


//----------------------------FIELDS------------------------------

  private Vector loci;       // holds all loci on the Field


//---------------------------CONSTRUCTORS--------------------------

  public NLocus ()  {
    /* This constructor creates a NLocus by intializing it's fields.

       Pre : none

       Post: the NLocus is created
    */

    loci = new Vector();
  }


//-----------------------------METHODS----------------------------


//===========================GETLOCI=========================

  public Vector getLoci()   {
    /* This method returns the vector containing the loci.

       Pre : none

       Post: the loci are returned
    */

    return loci;
  }


//===========================SETLOCI=========================

  public void setLoci(Vector loci)   {
    /* This method sets the vector containing the loci.

       Pre : given the new vector of loci

       Post: the loci are set
    */

    this.loci = loci;
  }

//===========================GETLOCUS==========================

  public Locus getLocus (int i)    {
    /* This method returns a specific locus model when given it's position.

       Pre : given the position of the locus

       Post: the locus is returned
    */

    return (Locus) loci.elementAt(i);
  }


//===========================ADDLOCUS===========================

  public void addLocus (Locus locus)   {
    /* This method adds a locus model to the list of models in the vector.

       Pre : given a locus

       Post: the locus is added to the vector
    */

    loci.addElement(locus);
  }


//=========================REMOVELOCUS===========================

  public void removeLocus (Locus locus)   {
    /* This method removes a locus model to the list of models in the vector.

       Pre : given a locus

       Post: the locus is removed from the vector
    */

    loci.removeElement(locus);
  }        
    

//=========================CLEAR===========================

  public void clear ()   {
    /* This method clears the NLocus of all loci.

       Pre : none

       Post: the locus vector has no elements
    */

    loci.clear();
  }        


//=========================DRAWNLOCUS============================

  public void drawNLocus(Graphics2D g2D) {
    /*  This method draws the nlocus on the graphics object.

        Pre : given the graphics object to draw upon

        Post: the nLocus is drawn
    */

    g2D.setColor(Locus.getColor());

    // go through locus vector and draw
    // each locus on graphics object
    Iterator it = this.getLoci().iterator();

    Locus locus;  
    while (it.hasNext())  {
      // retrieve the next locus and draw it on the graphics object
      locus = (Locus) it.next();
      locus.drawLocus(g2D);
    }
  }


//=========================DRAWLOCUSLABELS===========================

  public void drawLocusLabels(Graphics g2D, WindowToCanvas wc)  {
    /*  This method draws the necessary strings of a locus drawing.

        Pre : given a graphics object to draw upon and a window to canvas
              object

        Post: the strings of a locus drawing are drawn on the graphics object
    */

    g2D.setColor(Locus.getColor());
    g2D.setFont(new Font("Locus Font", Font.PLAIN, 12));

    // for each locus draw strings for the initial point and potential
    Iterator it = this.getLoci().iterator();
    Locus locus;  
    while (it.hasNext())  {
      locus = (Locus) it.next();
      locus.drawInitialPoint(g2D, wc);
      locus.drawPotential(g2D);
    }
  }


//======================APPLYLOCUSCOLOR====================

  public void applyLocusColors(Color locusColor) {
    /*  This method applys the given colors to all loci.

        Pre : given the color for positive particles

        Post: the loci are changed in color
    */

    Locus.setColor(locusColor);
  }


//=======================FINDLOCUSWITHINITIALPOINT======================

  public Locus findLocusWithInitialPoint
                            (Point2D coordinate, WindowToCanvas wc)  {
    /* This method finds the locus within the a certain range of
       the given position.

       Pre : given the coordinate to search for and the range of error
             to allow

       Post: the locus with the given relative position is returned
    */                                    

    Point2D start = new Point2D(wc.wx1, wc.wy1);
    final double range = start.distance(wc.wx2, wc.wy2)/40;
              // range (or margain) of error allowed;
    
    Iterator it = this.getLoci().iterator();
                        // goes through loci

    while (it.hasNext())  {
      Locus locus = (Locus) it.next();                
                        
      Point2D point = locus.getInitialPoint();  // locus's initial point
      point = wc.convertToWindow(point);

      // see is locus is at coordinate in question
      if (point.distance(coordinate) <= range)
        return locus;                         
    }

    // if no locus found with given position
    return null;
  }


//==============================MOVE=============================

  public void move(WindowToCanvas old, WindowToCanvas newWC)  {
    /*  This method converts the points in all loci in accordance with
        the change to the window to canvas object.

        Pre : given the old window to canvas transform and the new
              window to canvas transform

        Post: the coordinates of all the loci are moved accordingly
    */

    Iterator it = loci.iterator();
    Vector newLoci = new Vector();
    while (it.hasNext())  {
      // retrieve the old locus and move its points
      Locus oldLocus = (Locus) it.next();
      Locus newLocus = oldLocus.move(old, newWC);
      newLoci.addElement(newLocus);
    }

    // set the new locus vector
    this.loci = newLoci;
  }


//============================WRITEOBJECT=============================

  private void writeObject (ObjectOutputStream stream) throws IOException {
    /* This method is from the Serializalbe interface.  It allows the
       nlocus to be written.

       Pre  : given an ObjectOutputStream

       Post : the nlocus is written across the stream

       Excep: IOException may be thrown
    */

    stream.defaultWriteObject();
  }                                                                
   

//============================READOBJECT=============================

  private  void readObject (ObjectInputStream stream) throws IOException,
                                                ClassNotFoundException {
    /* This method is from the Serializalbe interface.  It allows the
       nlocus model to be read.

       Pre  : given an ObjectInputStream

       Post : the nlocus is read from the stream

       Excep: IOException and ClassNotFoundException may be thrown
    */

    try {     
      stream.defaultReadObject();
    }
    catch (Exception e)  {
      System.out.println("NLocus.ReadObjectException " + e);
      e.printStackTrace();
    }
  }


//============================TOSTRING===============================

  public String toString()  {
    /* This method returns a string representing a NLocus.

       Pre : none

       Post: a string representation of a locus is returned
    */

    String s = "NLocus : \n";

    s += "  Loci : " + loci;

    return s;
  }

}  // end class NLocus
