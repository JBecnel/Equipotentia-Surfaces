package model;                // class is part of the model package

import java.awt.*;
import java.beans.*;

import window.*;                                

/*  Jeremy Becnel              Applet Contest                 1/2/99

    This class defines a LocusView to view the locus points
    and potential.
*/

                                        
public class LocusView extends Frame {


//----------------------------FIELDS-----------------------------

  private Locus locus;         // locus being viewed
  private WindowToCanvas wc;   // window to Canvas object for coordinate
                               // transformations
  private TextArea textArea;   // where locus is written


//---------------------------CONSTANTS---------------------------

  // constants representing the width and height of the locus view
  public static final int WIDTH = 375;
  public static final int HEIGHT = 500;


//-------------------------CONSTRUCTOR---------------------------

  public LocusView ()   {
    /* This method creates the view for an locus
                
       Pre : none

       Post: the view is created
    */
                        
    super("Locus View");    // call to Frame constructor

    // create text area
    textArea = new TextArea(15,25);     // 15 rows 25 columns
    textArea.setEditable(false);

    // create a scroll bar and add the text area to it
    ScrollPane scrollPane = new ScrollPane();
    scrollPane.add(textArea);
    add(scrollPane, "Center");

    // add an unexitable window listener, set the size of the frame
    this.addWindowListener(new BasicWindowMonitor(false));
    this.setSize(WIDTH, HEIGHT);
  }

  public LocusView (Locus locus, WindowToCanvas wc)   {
    /* This method creates the view for an locus
                
       Pre : given the locus to view

       Post: the view is created
    */
                        
    this();    // call to above constructor
    this.wc = wc;
    setLocus(locus);
  }

//-----------------------------METHODS-----------------------------

                                                
//===========================GETLOCUS==========================

  public Locus getLocus ()  {
    /* This method returns a Locus representing the viewed locus.

       Pre : none

       Post: the Locus is returned
    */

    return locus;
  }


//===========================SETLOCUS==========================
                                
  public void setLocus (Locus locus)  {
    /* This method sets a locus field representing the locus being viewed.       

       Pre : given a locus to set the field to

       Post: the locus is set and the it is written on the text area
    */

    this.locus = locus;

    // get the string representatio of the initial point and other points
    String initialPoint =
          "InitialPoint: " + wc.convertToWindow(locus.getInitialPoint());
    String points = locus.convertPointsToString(wc);

    // set the text area to the locus information
    textArea.setText(locus.toString() + initialPoint + "\n" + points);
    this.setVisible(true);      
  }


//===========================GETWINDOWTOCANVAS==========================

  public WindowToCanvas getWindowToCanvas ()  {
    /* This method returns a WindowToCanvas representing the viewed
       windowToCanvas.

       Pre : none

       Post: the WindowToCanvas is returned
    */

    return wc;
  }


//===========================SETWINDOWTOCANVASS==========================
                                
  public void setWindowToCanvas (WindowToCanvas wc)  {
    /* This method sets a windowToCanvas field representing the
       windowToCanvas being viewed.

       Pre : given a windowToCanvas to set the field to

       Post: the windowToCanvas is set and the it is written on the text area
    */

    this.wc = wc;
    setLocus(locus);
  }

  
//============================TOSTRING=============================

  public String toString()  {
    /* This method returns the string representation of the locus view.

       Pre : none

       Post: the string representation is returned.
    */

    String s = "Locus View : /n";
    s += "Locus : " + locus.toString();

    return s;
  }


}  // end class LocusView
