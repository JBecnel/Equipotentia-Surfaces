package model;               // class is part of the model package

import java.beans.*;
import java.io.*;
import java.awt.*;
import java.util.*;

import point.Point2D;


/*        Jeremy Becnel         Applet Contest             12/9/98

   This class defines a NParticle which holds up to n charged particles
   useing a vector (list). 

*/


public class NParticle implements Serializable      {


//----------------------------FIELDS------------------------------

  private Vector particles;       // holds all particles on the Field

   
//---------------------------CONSTRUCTORS--------------------------

  public NParticle ()  {
    /* This constructor creates a NParticle by intializing it's fields.

       Pre : none

       Post: the NParticle is created
    */

    particles = new Vector();
  }


//-----------------------------METHODS----------------------------


//===========================GETPARTICLES=========================

  public Vector getParticles()   {
    /* This method returns the vector containing the particles.

       Pre : none

       Post: the particles are returned
    */

    return particles;
  }


//===========================GETPARTICLE==========================

  public Particle getParticle (int i)    {
    /* This method returns a specific particle model when given it's
       position in the vector.

       Pre : given the position of the particle

       Post: the particle is returned
    */

    return (Particle) particles.elementAt(i);
  }


//===========================ADDPARTICLE===========================

  public void addParticle (Particle particle)   {
    /* This method adds a particle model to the list of models in the vector.

       Pre : given a particle

       Post: the particle is added to the vector
    */

    particles.addElement(particle);
  }


//=========================DRAWNPARTICLE============================

  public void drawNParticle(Graphics2D g2D) {
    /*  This method draws the nparticle on the graphics object.

        Pre : given the graphics object to draw upon

        Post: the nParticle is drawn
    */

    // used to go through particle vector
    Iterator it = this.getParticles().iterator();

    
    // draw each particle on graphics object
    Particle particle;  
    while (it.hasNext())  {
      // retrieve the next particle and draw it on the graphics object
      particle = (Particle) it.next();
      particle.drawParticle(g2D);
    }
  }

//=========================REMOVEPARTICLE===========================

  public void removeParticle (Particle particle)   {
    /* This method removes a particle from the vector of particles.

       Pre : given a particle

       Post: the particle is removed from the vector
    */

    particles.removeElement(particle);
  }
          

//===========================FINDPOTENTIAL============================

  public double findPotential(Point2D point)  {
    /*  This method computes the potential at a point.

        Pre : given the point to find the potential at

        Post: the potential at the given point is returned
    */

    
    final double K = 1/(4 * Math.PI * (8.85 * Math.pow(10, -12)));
                                // constant used in finding potential

    // used to traverse particles
    Iterator it = this.getParticles().iterator();

    // used to keep track of current particle and particle info
    Particle particle;
    double radius;
    double charge;
    double potential = 0;

    // traverse particles and find total potential
    while (it.hasNext())  {
      particle = (Particle) it.next();
      charge = particle.getCharge();
      radius = point.distance(particle.getPosition());
      potential += charge/radius;
    }                                             

    return K * potential;
  }

//======================APPLYNEGATIVEPARTICLECOLORS====================

  public void applyNegativeParticleColors(Color primary, Color secondary) {
    /*  This method applys the given colors to all negative particles.

        Pre : given the new primary and secondary colors
              for negative paritcles

        Post: the negative particles are changed in color
    */

    Iterator it = this.getParticles().iterator();

    Particle particle;

    // iterate through particles
    while (it.hasNext())  {
      // retrieve the next particle
      particle = (Particle) it.next();

      // if particle is negative change color
      if (particle.getCharge() < 0)  {
        particle.setPrimaryColor(primary);
        particle.setSecondaryColor(secondary);
      }
    }   // end while
  }


//======================APPLYPOSITIVEPARTICLECOLORS====================

  public void applyPositiveParticleColors(Color primary, Color secondary) {
    /*  This method applys the given colors to all positive particles.

        Pre : given the new primary and secondary colors
              for positive paritcles

        Post: the positive particles are changed in color
    */

    Iterator it = this.getParticles().iterator();

    Particle particle;

    // traverse particles
    while (it.hasNext())  {
      // retrieve the next particle
      particle = (Particle) it.next();

      // if particle is postively charged change colors
      if (particle.getCharge() > 0)  {
        particle.setPrimaryColor(primary);
        particle.setSecondaryColor(secondary);
      }
    }    // end while
  }


//=======================FINDPARTICLEWITHPOSITION======================

  public Particle findParticleWithPosition(Point2D coordinate)  {
    /* This method finds the particle within the radius range of
       the given position.

       Pre : given the coordinate to search for

       Post: the particle with the given relative position is returned
    */                                    

    Iterator it = this.getParticles().iterator();
                        // goes through particles

    while (it.hasNext())  {
      Particle particle = (Particle) it.next();                
                        
      Point2D position = particle.getPosition();  // particles position
      double radius = particle.getRadius();       // radius of particle

      // see is particle is at coordinate in question
      if (position.distance(coordinate) <= radius)
        return particle;                         
    }

    // if no particle found with given position
    return null;
  }


//==============================ISEMPTY==============================

  public boolean isEmpty()  {
    /*  This method determines if the nParticle vector contains particles.

        Pre : none

        Post: true is returned is there are no particles in the nParticle
              object and false is returned otherwise
    */

    return (particles.size() == 0);
  }

//============================WRITEOBJECT=============================

  private void writeObject (ObjectOutputStream stream) throws IOException {
    /* This method is from the Serializable interface.  It allows the
       particle model to be written.

       Pre  : given an ObjectOutputStream

       Post : the particle is written across the stream

       Excep: IOException may be thrown
    */

    stream.defaultWriteObject();
  }                                                                
   

//============================READOBJECT=============================

  private  void readObject (ObjectInputStream stream) throws IOException,
                                                ClassNotFoundException {
    /* This method is from the Serializable interface.  It allows the
       paritcle model to be read.

       Pre  : given an ObjectInputStream

       Post : the particle is read from the stream

       Excep: IOException and ClassNotFoundException may be thrown
    */

    try {     
      stream.defaultReadObject();
    }
    catch (Exception e)  {
      System.out.println("NParticle.ReadObjectException: " + e);
      e.printStackTrace();
    }
  }


//============================TOSTRING===============================

  public String toString()  {
    /* This method returns a string representing a NParticle.

       Pre : none

       Post: a string representation for the nparticle is returned
    */

    return particles.toString();
  }

}  // end class NParticle
