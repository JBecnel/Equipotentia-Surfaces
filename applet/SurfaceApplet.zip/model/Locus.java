package model;               // class is part of the model package

import java.util.*;
import java.text.*;
import java.awt.*;
import java.awt.geom.*;
import java.io.*;

import math.*;
import window.*;
import point.Point2D;


/*  Jeremy Becnel               Applet Contest                  12/10/98

    This is the Locus class.  It store and manipulates a locus of points
    with the same potential as a given intial point.
*/


public class Locus extends Vector implements Serializable {


//-----------------------------FIELDS-----------------------------

  private Point2D initialPoint;    // initail point which has the same
                                   // potenial as all points on the surface

  private double potential;        // value of the potential for this
                                   // locus of points
                                   
  private GeneralPath path;   // path of locus (used to draw surface)
                             
  private static Color color = Color.black;   // color of loci


//--------------------------CONSTRUCTORS--------------------------

  public Locus()  {
    /*  This method creates a locus with default values.

        Pre : none

        Post: the default locus is created
    */

    super();
    potential = 0;
    path = new GeneralPath();
    this.initialPoint = new Point2D();
  }

  public Locus(Point2D initialPoint)  {
    /*  This method creates a locus with the given initialPoint.

        Pre : given the initialPoint of the locus

        Post: the locus is created
    */

    this();
    setInitialPoint(initialPoint);
  }


//----------------------------METHODS-----------------------------


//========================GETINITIALPOINT=========================

  public Point2D getInitialPoint()  {
    /*  This method returns the inital point of the surface or locus.

        Pre : none

        Post: the initial point field is returned
    */

    return initialPoint;
  }


//========================SETINITIALPOINT=========================

  public void setInitialPoint(Point2D initialPoint)  {
    /*  This method sets the inital point of the surface or locus.

        Pre : given the new initial point

        Post: the initial point field is set
    */

    this.initialPoint = initialPoint;
    path = new GeneralPath();
    path.moveTo((float)initialPoint.getX(),(float)initialPoint.getY());
    addPoint(initialPoint);
  }                          


//========================GETPOTENTIAL=========================

  public double getPotential()  {
    /*  This method returns the potential of the surface or locus.

        Pre : none

        Post: the potential field is returned
    */

    return potential;
  }


//========================SETPOTENTIAL=========================

  public void setPotential(double potential)  {
    /*  This method sets the potential of the surface or locus.

        Pre : given the new potential

        Post: the potential field is set
    */

    this.potential = potential;
  }                          


//========================GETCOLOR=========================

  public static Color getColor()  {
    /*  This method returns the color of a locus.

        Pre : none

        Post: the color of the locus class is returned
    */

    return color;
  }


//========================SETCOLOR=========================

  public static void setColor(Color color)  {
    /*  This method sets the color of a surface or locus.

        Pre : given the new locus color 

        Post: the color field is set
    */

    Locus.color = color;
  }             


//=========================GETPATH===========================

  public GeneralPath getPath()  {
    /*  This method returns the general path field of the locus class.

        Pre : none

        Post: the locus path is returned
    */

    return path;
  }

//===========================ADDPOINT=============================

  public void addPoint(Point2D locusPoint)  {
    /*  This method adds a point to the locus.

        Pre : given the new locus point

        Post: the point is added the locus
    */

    path.lineTo((float)locusPoint.getX(), (float)locusPoint.getY());
    addElement(locusPoint);
  }


//==========================LASTPOINT============================

  public Point2D lastPoint() {
    /*  This method returns the last point in the locus.

        Pre : none

        Post: the last point in the locus is returned
    */

    return (Point2D) lastElement();
  }


//==========================CLEARLOCUS=============================

  public void clearLocus()  {
    /* This method clears the whole locus of points.

       Pre : none

       Post: the locus is reset with no points
    */

    removeAllElements();
  }
        

//==========================NEXTPOINT============================

  public Point2D nextPoint(Point2D[] p, NParticle nParticle)  {
    /*  This method traveres the array of points and finds the point closest
        to the potential of the locus and returns the point.

        Pre : given a non empty array of points and the
              particles to compute the particle for

        Post: the point closest ot the potential of the locus is returned
    */

    // assume the first point is closest to the potential of the locus
    Point2D point = p[0];

    double min = Math.abs(potential - nParticle.findPotential(p[0]));
                // min difference in potential

    // see if another point is closer than the first point
    double next;        // potential for next point
    for (int i = 1; i < p.length; i++) {
      next = Math.abs(potential - nParticle.findPotential(p[i]));
      
      if (next < min) {
        point = p[i];    // closest point seen thus far
        min = next;
      }
    }

    return point;   // return the closest point in array
  }                 
      



//======================RECOMPUTEPOTENTIAL=========================

  public void recomputePotential(NParticle nParticle)  {
    /*  This method recomputes the potential for the locus using
        the nParticle.

        Pre : given the nParticle object holding the values of the
              particle positions and charges

        Post: the potential for the locus is recomputed and set
    */

    potential = nParticle.findPotential(this.getInitialPoint());
    setPotential(potential);
  }


//=======================DRAWINITIALPOINT===========================

  public void drawInitialPoint(Graphics g2D, WindowToCanvas wc)  {
    /*  This method draws the locus's initial point on a graphics object.

        Pre: given the graphcis object to drawn on and the window to
             canvas object for conversion of coordinates

        Post: the locus's initial point is drawn on the graphics object
    */


    Point2D windowPoint = wc.convertToWindow(initialPoint);

    // format the cordinates to 5 places after the decimal
    double x = MathOps.formatDecimalPlace(windowPoint.getX(), 5);
    double y = MathOps.formatDecimalPlace(windowPoint.getY(), 5);

    Point2D point = new Point2D(x,y);

    g2D.drawString(point.toString(), (int)initialPoint.getX(), (int)initialPoint.getY());
  }


//=======================DRAWPOTENTIAL===========================

  public void drawPotential(Graphics g2D)  {
    /*  This method draws the locus's potential label on a graphics object.

        Pre: given the graphcis object to drawn on and the window to
             canvas object for conversion of coordinates

        Post: the locus's potential label is drawn on the graphics object
    */   

    Point2D lastPoint = lastPoint();

    // format the potential to 5 places after the decimal
    double V = MathOps.formatDecimalPlace(getPotential(), 5);

    g2D.drawString("V = " + V, (int)lastPoint.getX() - 10 ,
                                        (int)lastPoint.getY()- 12);
  }


//========================DRAWLOCUS=============================

  public void drawLocus(Graphics2D g2D)  {
    /*  This method draws the general path representing a locus of
        points with equivalent potential.

        Pre : given the graphics objects to draw on

        Post: the general path representing the locus is drawn
    */

    g2D.draw(path);
  }


//========================REDRAWPATH==============================

  private void redrawPath()   {
    /*  This method redraws the general path for the locus.

        Pre : none

        Post: the general path is redrawn
    */

    Iterator it = this.iterator();

    // start at initial point
    path.moveTo((float)initialPoint.getX(), (float)initialPoint.getY());

    // traverse point and connect them in the path
    Point2D point;
    while(it.hasNext()) {
      point = (Point2D) it.next();
      path.lineTo((float) point.getX(), (float) point.getY());
                // draw a line to the next point
    }
  }


//============================WRITEOBJECT=============================

  private void writeObject (ObjectOutputStream stream) throws IOException {
    /* This method is from the Serializalbe interface.  It allows the
       locus to be written.

       Pre  : given an ObjectOutputStream

       Post : the locus is written across the stream

       Excep: IOException may be thrown
    */

    try {
      stream.writeObject(getInitialPoint());
      stream.writeObject(new Double(getPotential()));
      stream.writeObject(getColor());
    }
    catch (Exception e)  {
      e.printStackTrace();
      System.out.println("Particle.writeObject Excpetion : " + e.getMessage());
    }
  }
   

//============================READOBJECT=============================

  private void readObject (ObjectInputStream stream) throws IOException,
                                                ClassNotFoundException {
    /* This method is from the Serializable interface.  It allows the
       locus to be read.

       Pre  : given an ObjectInputStream

       Post : the locus is read from the stream

       Excep: IOException and ClassNotFoundException may be thrown
    */

    try {
      // read in the locus fields and redraw the path
      setInitialPoint((Point2D) stream.readObject());
      setPotential(((Double) stream.readObject()).doubleValue());
      setColor((Color)stream.readObject());
      redrawPath();
    }
    catch (Exception e) {
      System.out.println("ParticleModel.ReadObjectException " + e);
      e.printStackTrace();
    }                    
  }
    

//===========================ISSINGLE============================

  public boolean isSingle()  {
    /*  This method returns true if the locus is a singleton vector with
        only a initial point or false if it has more than just a initial
        point.

        Pre : none

        Post: a boolean representing if the locus consist of only a
              single initial point
     */

     return (this.size() == 1);
   }


//=====================CONVERTPOINTSTOSTRING=====================

  public String convertPointsToString(WindowToCanvas wc)  {
    /*  This method converts the Vectors comoponents (points) to strings.

        Pre : none

        Post: the points of the vector are converted to a string so
              they can be written out
    */

    Iterator it = this.iterator();

    String s = "\n Points:\n";
    while (it.hasNext())  {
      Point2D next = wc.convertToWindow((Point2D) it.next());
      s += next.toString() + "\n";
    }

    return s;
  }


//==============================MOVE=============================

  public Locus move (WindowToCanvas old, WindowToCanvas newWC)  {
    /*  This method converts the locus points in accordance with
        the change to the window to canvas object.

        Pre : given the old window to canvas transform and the new
              window to canvas transform

        Post: the coordinates of all the loci are moved accordingly
    */
    
    Point2D initialPoint = old.convertToWindow(this.initialPoint);
    Locus newLocus = new Locus(newWC.convertToCanvas(initialPoint));
    newLocus.setPotential(this.getPotential());

    if (!this.isSingle()) {

      Iterator it = this.iterator();

      while (it.hasNext())  {
        Point2D point = (Point2D) it.next();
        point = old.convertToWindow(point);
        newLocus.addPoint(newWC.convertToCanvas(point));
      }
    }

    return newLocus;
  }


//===========================TOSTRING============================

  public String toString()  {
    /*  This method returns the string representation of a locus.

        Pre : none

        Post: the string represetation of a locus is return
    */

    String s = "Potential : " + potential;
    s += "\nTotal Points  : " + size() + "\n";

    return s;
  }

}  // end class Locus

    
