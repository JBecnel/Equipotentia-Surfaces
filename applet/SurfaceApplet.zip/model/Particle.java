package model;               // class is part of model package

import java.io.*;
import java.awt.geom.*;
import java.awt.*;

import point.Point2D;


/*       Jeremy Becnel          Applet Contest                12/9/98

   This class defines a particle used in finding equipotential surfaces.
*/


public class Particle implements Serializable    {

//-------------------------FIELDS--------------------------

  private Point2D position;
       // position of the particle

  private double radius;  // the radius of the particle
  private double charge;  // the positive or negative charge of the particle

  private Color primaryColor;   // the primary color of the particle
  private Color secondaryColor; // the second shade of the particle

  // default colors for the negatively charged particles
  private static Color negativePrimaryColorDefault = Color.red;
  private static Color negativeSecondaryColorDefault = Color.orange;

  // default colors for the positively charged particles
  private static Color positivePrimaryColorDefault = Color.blue;
  private static Color positiveSecondaryColorDefault = Color.yellow;


//===========================CONSTANTS=========================

  // constants for the default positive and negative paritcles
  public static final Particle POSITIVE_PARTICLE = new Particle();
  public static final Particle NEGATIVE_PARTICLE = new Particle(5,-1);


//-----------------------CONSTRUCTORS-------------------------

  public Particle ()    {
    /* This method creates a particle object.

       Pre : none

       Post: an object particle model is made.
    */

    this(5, 1);
  }

  public Particle(double radius, double charge)  {
    /*  This constructor creates a particle.

        Pre : given the particles radius and the charge of the particle

        Post: the particle is created
    */

    // set the radius and charge of the particle
    this.radius = radius;
    this.charge = charge;

    // set the color in accordance with the particle's charge
    if (charge > 0)   {
      primaryColor = positivePrimaryColorDefault;
      secondaryColor = positiveSecondaryColorDefault;
    }
    else  {
      primaryColor = negativePrimaryColorDefault;
      secondaryColor = negativeSecondaryColorDefault;
    }

    // intialize position 
    position = new Point2D(100, 100);
  }


//-------------------------METHODS---------------------------

//=======================GETPOSITION========================

  public Point2D getPosition() {
    /* This method returns the objects position.

       Pre : none

       Post: the position is returned
    */

    return position;
  }


//==========================SETPOSITION=============================

  public void setPosition(Point2D position)  {
    /* This method sets the particles position.

       Pre : given a Point2D for the new position

       Post: the position is set to the given point
    */

    this.position = position;
  }

  public void setPosition(double x, double y)  {
    /* This method sets the particles position.

       Pre : given a x and y representing the coordinates for the new
             position

       Post: the position is set to the given (x,y);
    */

    this.position.x = x;
    this.position.y = y;
  }                  

//==========================GETRADIUS============================

  public double getRadius() {
    /* This method returns the objects radius.

       Pre : none

       Post: the radius is returned
    */

    return radius;
  }


//==========================SETRADIUS=============================

  public void setRadius(double radius)  {
    /* This method sets the particles radius.

       Pre : given a double for the new radius

       Post: the radius is set to the given double
    */

    this.radius = radius;
  }


//==========================GETCHARGE========================

  public double getCharge() {
    /* This method returns the objects charge.

       Pre : none

       Post: the charge is returned
    */

    return charge;
  }


//======================CONVERTTOPOSITIVE=========================

  private void convertToPositive()  {
    /*  This method converts the colors a particle to positive
        defaults.

        Pre : the particle must be using negative default colors

        Post: the positive defaults are set
    */

    if (getPrimaryColor().equals(getNegativePrimaryColorDefault())  &&
        getSecondaryColor().equals(getNegativeSecondaryColorDefault()))  {
      setPrimaryColor(getPositivePrimaryColorDefault());
      setSecondaryColor(getPositiveSecondaryColorDefault());
    }
  }    


//======================CONVERTTONEGATIVE=========================

  private void convertToNegative()  {
    /*  This method converts the colors a particle to Negative
        defaults.

        Pre : the particle must be using positive default colors

        Post: the Negative defaults are set
    */

    if (getPrimaryColor().equals(getPositivePrimaryColorDefault())  &&
        getSecondaryColor().equals(getPositiveSecondaryColorDefault()))  {
      setPrimaryColor(getNegativePrimaryColorDefault());
      setSecondaryColor(getNegativeSecondaryColorDefault());
    }
  }    

//==========================SETCHARGE=============================

  public void setCharge(double charge)  {
    /* This method sets the particles charge.  It also checks if
       the change in charge with affect the color of the particle.

       Pre : given a double for the new charge

       Post: the charge is set to the given double and the colors of
             the particle are set appropriately;
    */
    
    if (this.charge < 0 && charge > 0)
      convertToPositive();
    else if (this.charge > 0 && charge < 0)
      convertToNegative();

    this.charge = charge;
  }                                    


//========================GETPRIMARYCOLOR======================

  public Color getPrimaryColor()  {
    /*  This method returns the primary color of the particle.

        Pre : none

        Post: the primary color is returned
    */

    return primaryColor;
  }


//========================SETPRIMARYCOLOR======================

  public void setPrimaryColor(Color primaryColor)  {
    /*  This method sets the primary color of the particle.

        Pre : given the new primaryColor

        Post: the primary color is updated
    */

    this.primaryColor = primaryColor;
  }


//========================GETSECONDARYCOLOR======================

  public Color getSecondaryColor()  {
    /*  This method returns the secondary color of the particle.

        Pre : none

        Post: the secondary color is returned
    */

    return secondaryColor;
  }


//========================SETSECONDARYCOLOR======================

  public void setSecondaryColor(Color secondaryColor)  {
    /*  This method sets the secondary color of the particle.

        Pre : given the new secondary Color

        Post: the secondary color is returned
    */

    this.secondaryColor = secondaryColor;
  }
                                      

//=================GETPOSITIVEPRIMARYCOLORDEFAULT==================

  public static Color getPositivePrimaryColorDefault()  {
    /*  This method returns the the default primary color for
        a particle.

        Pre : none

        Post: the positive primary color default is returned
    */

    return positivePrimaryColorDefault;
  }


//==================SETPOSITIVEPRIMARYCOLORDEFAULT==================

  public static void setPositivePrimaryColorDefault(Color newDefault)  {
    /*  This method sets the positive primary color default of the particle.

        Pre : given the new default color

        Post: the positive primary color default is updated
    */

    positivePrimaryColorDefault = newDefault;
  }                                        


//=================GETPOSITIVESECONDARYCOLORDEFAULT==================

  public static Color getPositiveSecondaryColorDefault()  {
    /*  This method returns the the default secondary color for
        a particle.

        Pre : none

        Post: the positive secondary default is returned
    */

    return positiveSecondaryColorDefault;
  }


//==================SETPOSITIVESECONDARYCOLORDEFAULT==================

  public static void setPositiveSecondaryColorDefault(Color newDefault)  {
    /*  This method sets the positive secondary color default of the particle.

        Pre : given the new default color

        Post: the secondary color is returned
    */

    positiveSecondaryColorDefault = newDefault;
  }                                  
                                      

//=================GETNEGATIVEPRIMARYCOLORDEFAULT==================

  public static Color getNegativePrimaryColorDefault()  {
    /*  This method returns the the default primary color for
        a particle.

        Pre : none

        Post: the negative primary color default is returned
    */

    return negativePrimaryColorDefault;
  }


//==================SETNEGATIVEPRIMARYCOLORDEFAULT==================

  public static void setNegativePrimaryColorDefault(Color newDefault)  {
    /*  This method sets the negative primary color default of the particle.

        Pre : given the new new default color

        Post: the negative primary color default is updated
    */

    negativePrimaryColorDefault = newDefault;
  }                                        


//=================GETNEGATIVESECONDARYCOLORDEFAULT==================

  public static Color getNegativeSecondaryColorDefault()  {
    /*  This method returns the the default secondary color for
        a particle.

        Pre : none

        Post: the negative secondary default is returned
    */

    return negativeSecondaryColorDefault;
  }


//==================SETNEGATIVESECONDARYCOLORDEFAULT==================

  public static void setNegativeSecondaryColorDefault(Color newDefault)  {
    /*  This method sets the negative secondary color default of the particle.

        Pre : given the new default color

        Post: the secondary color is returned
    */

    negativeSecondaryColorDefault = newDefault;
  }
                     

//============================WRITEOBJECT=============================

  private void writeObject (ObjectOutputStream stream) throws IOException {
    /* This method is from the Serializable interface.  It allows the
       particle to be written.

       Pre  : given an ObjectOutputStream

       Post : the particle is writen across the stream

       Excep: IOException may be thrown
    */

    try {
      stream.defaultWriteObject();

      stream.writeObject(getPositivePrimaryColorDefault());
      stream.writeObject(getPositiveSecondaryColorDefault());
      stream.writeObject(getNegativePrimaryColorDefault());
      stream.writeObject(getNegativeSecondaryColorDefault());
    }
    catch (Exception e)  {
      e.printStackTrace();
      System.out.println("Particle.writeObject Exception : " + e.getMessage());
    }
  }
   

//============================READOBJECT=============================

  private void readObject (ObjectInputStream stream) throws IOException,
                                                ClassNotFoundException {
    /* This method is from the Serializalbe interface.  It allows the
       particle to be read.

       Pre  : given an ObjectInputStream

       Post : the particle is read from the stream

       Excep: IOException and ClassNotFoundException may be thrown
    */

    try {     
      stream.defaultReadObject();

      setPositivePrimaryColorDefault((Color)stream.readObject());
      setPositiveSecondaryColorDefault((Color)stream.readObject());
      setNegativePrimaryColorDefault((Color)stream.readObject());
      setNegativeSecondaryColorDefault((Color)stream.readObject());
    }
    catch (Exception e) {
      System.out.println("ParticleModel.ReadObjectException " + e);
      e.printStackTrace();
    }
  }
    

//===============================DRAWPARTICLE=========================

  public void drawParticle(Graphics2D g2D) {
    /* This method draws an ellipse representing the particle on the Field.

       Pre : given an graphics2D object

       Post: the particle is drawn
    */
             
    Point2D position = getPosition();
    double radius = getRadius();

    double h = 2 * radius;
    double y = position.y - radius;

    // set the colors for the particle
    g2D.setPaint(new GradientPaint((float) position.x,
          (float) (position.y - 2 * radius), getPrimaryColor(),
          (float) (position.x + 2 * radius),(float) position.y,
           getSecondaryColor()));      

    // fill the ellipse representing the particle
    Ellipse2D.Float particleShape = new Ellipse2D.Float();
    particleShape.setFrame(position.x - radius, y, h ,h);
    g2D.fill(particleShape);
  }


//===========================TOSTRING========================

  public String toString()   {
    /* This method returns a string representing the particle.

       Pre : given an implicit particle 

       Post: the particles string representation is returned 
    */

    String s =
       "Particle Model : "
     + "\n    Position = " + getPosition()
     + "\n    Radius = " + getRadius() 
     + "\n    Charge = " + getCharge();

     return s;
  }

} // end class Particle

