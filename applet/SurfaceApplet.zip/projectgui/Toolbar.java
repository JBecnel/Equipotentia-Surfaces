package projectgui;       // class is part of the graphical user interface 
                          // package for the potential surface project

import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.plaf.*;

import actions.*;
import icon.*;


/*  Jeremy Becnel               Applet Contest                12/8/98
                                                
    This class defines a toolbar that holds buttons for
    the equipotential surfaces project.
*/

                                       
public class Toolbar extends JToolBar {


//--------------------------------FIELDS---------------------------------

  private Actions actions;              // actions for the tool items
  private PropertyResourceBundle resources;
                        // holds the resources from the resource file
  private Icons icons;              // symbols (icons) that appear on
                                    // buttons
                                                                                                                                                                    


//-----------------------------CONSTRUCTORS------------------------------

  public Toolbar (Actions actions, PropertyResourceBundle resources,
                                                Icons icons)  {
    /*  This constructor creates a tool bar with buttons received from
        a resource file. It also adds certian action listeners to
        the tool buttons.

        Pre : given the action listeners for the tool bar items
              and a resoucre with the tools bar items

        Post: the tool bar is created
    */

    super();    // call to ToolBar constructor

    // intialize fields
    this.actions = actions;
    this.resources = resources;
    this.icons = icons;
                 
    // disable floatable
    setFloatable(false);

    // set the layout to a box vertical box layout
    setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));

    // create string tokenizer to help build the buttons
    StringTokenizer tk = new StringTokenizer(resources.getString("Toolbar"));

    // build the tools bar buttons and add them to the tool bar
    while (tk.hasMoreTokens()) 
      add(buildButton(tk.nextToken()));    
  }


//------------------------------METHODS-------------------------------


//=============================BUILDBUTTON==============================
                        
  public JButton buildButton(String name)  {
    /* This method build buttons for the tool bar.

       Pre : given the name of the button
                
       Post: the button is built
    */

    // create button
    JButton button = new JButton();

    // set the button icon and add the action listener and add the tool tip
    button.setIcon(new ToolbarIcon((ProjectIcon) icons.get(name)));
    button.addActionListener((GUIAction) actions.getAction(name));
    button.setToolTipText(resources.getString(name + "Tooltip"));

    return button;
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the toolbar.

        Pre : none

        Post: the string representation is returned
    */
                                                
    String s = "Tool Bar : \n";

    s += super.toString();

    return s;
  }

}  // end class Toolbar
