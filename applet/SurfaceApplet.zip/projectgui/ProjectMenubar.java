package projectgui;       // class is part of the graphical user interface 
                          // package for the potential surface project

import java.awt.*;
import java.util.*;
import actions.*;


/*  Jeremy Becnel             Applet Contest                12/8/98

    This class defines a menubar that holds menus with menu items for
    the potential surface project.
*/

                                       
public class ProjectMenubar extends MenuBar {


//--------------------------------FIELDS---------------------------------

  private Actions actions;              // actions for the menu items
  private PropertyResourceBundle resources;
                        // holds the resources from the resource file


//-----------------------------CONSTRUCTORS------------------------------

  public ProjectMenubar (Actions actions, PropertyResourceBundle resources)  {
    /*  This constructor creates a menu bar with items received from
        a resource file. It also adds certian action listeners to
        the menu items.

        Pre : given the action listener's for the menu items
              and a resoucre with the menu's and menu items

        Post: the menu bar is created
    */

    super();    // call to MenuBar constructor

    // intialize fields
    this.actions = actions;
    this.resources = resources;

    // create string tokenizer to help build the menu
    StringTokenizer tk = new StringTokenizer(resources.getString("Menubar"));

    // build the menus and add them to the menu bar
    while (tk.hasMoreTokens())         
      add(buildMenu(tk.nextToken()));    
  }


//------------------------------METHODS-------------------------------


//=============================BUILDMENU==============================

  public Menu buildMenu(String name)  {
    /* This method build a menu for the menu bar.

       Pre : given the name of the menu

       Post: the menu is built
    */

    // create menu
    Menu menu = new Menu(name);

    StringTokenizer tk = new StringTokenizer(resources.getString(name));
    
    // add the menu items
    while (tk.hasMoreTokens())  
      menu.add(buildMenuItem(tk.nextToken()));    

    return menu;
  }


//==============================INSERTSPACE==============================

  private static String insertSpace(String name, int position ) {
    /*  This method inserts a space into a string at the given position.

        Pre : given the string and the position to insert the space

        Post: the space is inserted at the given position and the
              string is returned
    */

    StringBuffer buffer = new StringBuffer(name);
    buffer = buffer.insert(name.length() - position, ' ');
    return buffer.toString();
  }

//=============================BUILDMENUITEM=============================

  public MenuItem buildMenuItem(String name)  {
    /* This method builds a menu item and adds an action listener to it.

       Pre : given the name of the menu item

       Post: the menu item is created
    */

    String menuName = new String(name);

    // insert a space if neccessary
    if (name.endsWith("Color") || name.endsWith("Locus"))  
      menuName = insertSpace(name, 5);
    else if (name.startsWith("Field"))
      menuName = insertSpace(name, name.length() - 5);
    else if (name.endsWith("At"))    {
      menuName = menuName.substring(0, menuName.length() - 2);
      if (menuName.endsWith("Particle"))
        menuName = insertSpace(menuName, 8);
    }
    

    // create the menu item and add the appropriate action listener
    MenuItem menuItem = new MenuItem(menuName);
    menuItem.addActionListener((GUIAction) actions.getAction(name));

    return menuItem;
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the ProjectMenuBar.

        Pre : none
                              
        Post: the string representation is returned
    */
                                                
    String s = "Project Menubar : \n";

    s += super.toString();

    return s;
  }
   
}  // end class ProjectMenubar
