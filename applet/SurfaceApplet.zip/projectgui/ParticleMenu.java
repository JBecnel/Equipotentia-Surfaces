package projectgui;       // class is part of the graphical user interface 
                          // package for the potential surface project

import java.awt.*;
import java.util.*;
import actions.*;


/*  Jeremy Becnel             Applet Contest                12/10/98

    This class defines a pop up menu with choices to manipulate the
    particle.
*/

                                       
public class ParticleMenu extends PopupMenu {


//--------------------------------FIELDS---------------------------------

  private Actions actions;              // actions for the menu items
  private PropertyResourceBundle resources;
                        // holds the resources from the resource file


//-----------------------------CONSTRUCTORS------------------------------

  public ParticleMenu (PropertyResourceBundle resources, Actions actions)  {
    /*  This constructor creates a pop up menu for a particle
        with items received from a resource file. It also adds
        certian action listeners to the menu items.

        Pre : given the action listener's for the menu items
              and a resource file with the menu items

        Post: the pop up menu is created
    */

    super();    // call to PopupMenu constructor

    // set fields
    this.actions = actions;
    this.resources = resources;

    // create string tokenizer to help build the popup menu
    StringTokenizer tk =
                new StringTokenizer(resources.getString("ParticleMenu"));

    // build the menuItems and add them to the popup menu 
    while (tk.hasMoreTokens())
      add(buildMenuItem(tk.nextToken()));    
  }


//------------------------------METHODS-------------------------------


//===========================BUILDMENUITEM=============================

  public MenuItem buildMenuItem(String name)  {
    /* This method builds a menu item and adds an action listener to it.

       Pre : given the name of the menu item

       Post: the menu item is created
    */

    // create the menu item and add the appropriate action listener
    MenuItem menuItem = new MenuItem(name);
    menuItem.addActionListener((GUIAction) actions.getAction(name));

    return menuItem;
  }


//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none

        Post: the string representation is returned
    */
                                                
    String s = "PatricleMenu  : \n";

    s += super.toString();

    return s;
  }
   
}  // end class ParrticleMenu
