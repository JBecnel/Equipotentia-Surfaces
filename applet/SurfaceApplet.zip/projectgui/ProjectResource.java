package projectgui;                  // class is part of the gui package

import java.util.*;


/*  Jeremy Becnel             Applet Contest                   12/12/98

    This class defines a ProjectRecource object that pulls up
    the resources from a properties file.
*/
                                                                        

public class ProjectResource    {


//----------------------------FIELD-----------------------------

  private ResourceBundle resource;
                // holds the resource recieved from the properties file


//-------------------------CONSTRUCTOR--------------------------
                        
  public ProjectResource (String title)  {
    /* This class creates an object and intializes the resource field.

       Pre : the title of the properties file

       Post: the resource field is intialized and the object is created
    */                                   

    try {                                                                                
      resource = (ResourceBundle)  
      ResourceBundle.getBundle(title, Locale.getDefault());
    }
    catch (Exception e) {                
      System.out.println ("ProjectResources Exception : " + e);
      e.printStackTrace();
    }
  }


//---------------------------METHODS------------------------------


//=========================GETRESOURCES===========================

  public PropertyResourceBundle getResources()  {
    /* This method returns the resource field of the class.

       Pre : none

       Post: the field is returned
    */

    return (PropertyResourceBundle)resource;
  }



//=============================TOSTRING===========================

  public String toString()  {
    /*  This method returns the string representation of the class.

        Pre : none

        Post: the string representation is returned
    */
                                                
    String s = "Project Resource : \n";

    s += resource.toString();

    return s;
  }

} // end class Project Resources
